import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.pacer_import_case import PACERImportCase
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.pacer_case_import_api import PACERCaseImportApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class PACERCaseImport:

    @staticmethod
    def import_pacer_case_by_court_using_case_number(
        pacer_user_id: Annotated[str, Field(min_length=6, strict=True, max_length=20, description="The PACER username of the PACER account under which the case should be imported.")],
        case_number: Annotated[str, Field(min_length=1, strict=True, max_length=50, description="The case number of the case to be imported.")],
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the court from which the case is to be imported.")],
        pacer_client_code: Annotated[Optional[Annotated[str, Field(min_length=0, strict=True, max_length=32)]], Field(description="This is mandatory if your setting in PACER website is set to Yes for the flag `Require Client Code?` under `Set PACER Billing Preferences` page. The client code is a text field entered by users upon login that can be used to track usage by person, client matter number, or other meaningful entry up to 32 characters, comprising the following:    Alphabetic characters (A-Z or a-z)    Numeric digits (0-9)   Period (.)    Underscore (_)    Hyphen (-)    Slash (/)")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[PACERImportCase]:

        """Find PACER Case for a requested Case Number and Court.

        Import the specified case from PACER.    Workflow:     1.This API will return the Find Case results from the court site in a form of array of UniCourt Case Objects. These case objects will consists only Meta information of the case if not already present in the UniCourt Database.     2.To get the full updated case information one will have to request the caseUpdate API by passing the caseId.    Note:     1.Charges for Find Case in District, Bankruptcy and National Courts is free. Find case for Appeal Courts will be charged at minimum rate of $0.1. The fee charged by the court for find case can be found in the response of this API in the field courtFee.     2.The results of the search has less Meta information in case objects compared to the Meta information of cases found using the PCL search APIs.

        :param pacer_user_id: The PACER username of the PACER account under which the case should be imported. (required)
        :type pacer_user_id: str
        :param case_number: The case number of the case to be imported. (required)
        :type case_number: str
        :param court_id: The courtId value of the court from which the case is to be imported. (required)
        :type court_id: str
        :param pacer_client_code: This is mandatory if your setting in PACER website is set to Yes for the flag `Require Client Code?` under `Set PACER Billing Preferences` page. The client code is a text field entered by users upon login that can be used to track usage by person, client matter number, or other meaningful entry up to 32 characters, comprising the following:    Alphabetic characters (A-Z or a-z)    Numeric digits (0-9)   Period (.)    Underscore (_)    Hyphen (-)    Slash (/)
        :type pacer_client_code: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = PACERCaseImportApi(api_client).import_pacer_case_by_court_using_case_number_with_http_info(pacer_user_id = pacer_user_id, case_number = case_number, court_id = court_id, workspace_id = unicourt.WORKSPACE_ID, pacer_client_code = pacer_client_code, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def import_pacer_case_by_court_using_case_number_with_http_info(
        pacer_user_id: Annotated[str, Field(min_length=6, strict=True, max_length=20, description="The PACER username of the PACER account under which the case should be imported.")],
        case_number: Annotated[str, Field(min_length=1, strict=True, max_length=50, description="The case number of the case to be imported.")],
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the court from which the case is to be imported.")],
        pacer_client_code: Annotated[Optional[Annotated[str, Field(min_length=0, strict=True, max_length=32)]], Field(description="This is mandatory if your setting in PACER website is set to Yes for the flag `Require Client Code?` under `Set PACER Billing Preferences` page. The client code is a text field entered by users upon login that can be used to track usage by person, client matter number, or other meaningful entry up to 32 characters, comprising the following:    Alphabetic characters (A-Z or a-z)    Numeric digits (0-9)   Period (.)    Underscore (_)    Hyphen (-)    Slash (/)")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[PACERImportCase]:

        """Find PACER Case for a requested Case Number and Court.

        Import the specified case from PACER.    Workflow:     1.This API will return the Find Case results from the court site in a form of array of UniCourt Case Objects. These case objects will consists only Meta information of the case if not already present in the UniCourt Database.     2.To get the full updated case information one will have to request the caseUpdate API by passing the caseId.    Note:     1.Charges for Find Case in District, Bankruptcy and National Courts is free. Find case for Appeal Courts will be charged at minimum rate of $0.1. The fee charged by the court for find case can be found in the response of this API in the field courtFee.     2.The results of the search has less Meta information in case objects compared to the Meta information of cases found using the PCL search APIs.

        :param pacer_user_id: The PACER username of the PACER account under which the case should be imported. (required)
        :type pacer_user_id: str
        :param case_number: The case number of the case to be imported. (required)
        :type case_number: str
        :param court_id: The courtId value of the court from which the case is to be imported. (required)
        :type court_id: str
        :param pacer_client_code: This is mandatory if your setting in PACER website is set to Yes for the flag `Require Client Code?` under `Set PACER Billing Preferences` page. The client code is a text field entered by users upon login that can be used to track usage by person, client matter number, or other meaningful entry up to 32 characters, comprising the following:    Alphabetic characters (A-Z or a-z)    Numeric digits (0-9)   Period (.)    Underscore (_)    Hyphen (-)    Slash (/)
        :type pacer_client_code: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return PACERCaseImportApi(api_client).import_pacer_case_by_court_using_case_number_with_http_info(pacer_user_id = pacer_user_id, case_number = case_number, court_id = court_id, workspace_id = unicourt.WORKSPACE_ID, pacer_client_code = pacer_client_code, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def import_pacer_case_by_court_using_case_number_without_preload_content(
        pacer_user_id: Annotated[str, Field(min_length=6, strict=True, max_length=20, description="The PACER username of the PACER account under which the case should be imported.")],
        case_number: Annotated[str, Field(min_length=1, strict=True, max_length=50, description="The case number of the case to be imported.")],
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the court from which the case is to be imported.")],
        pacer_client_code: Annotated[Optional[Annotated[str, Field(min_length=0, strict=True, max_length=32)]], Field(description="This is mandatory if your setting in PACER website is set to Yes for the flag `Require Client Code?` under `Set PACER Billing Preferences` page. The client code is a text field entered by users upon login that can be used to track usage by person, client matter number, or other meaningful entry up to 32 characters, comprising the following:    Alphabetic characters (A-Z or a-z)    Numeric digits (0-9)   Period (.)    Underscore (_)    Hyphen (-)    Slash (/)")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Find PACER Case for a requested Case Number and Court.

        Import the specified case from PACER.    Workflow:     1.This API will return the Find Case results from the court site in a form of array of UniCourt Case Objects. These case objects will consists only Meta information of the case if not already present in the UniCourt Database.     2.To get the full updated case information one will have to request the caseUpdate API by passing the caseId.    Note:     1.Charges for Find Case in District, Bankruptcy and National Courts is free. Find case for Appeal Courts will be charged at minimum rate of $0.1. The fee charged by the court for find case can be found in the response of this API in the field courtFee.     2.The results of the search has less Meta information in case objects compared to the Meta information of cases found using the PCL search APIs.

        :param pacer_user_id: The PACER username of the PACER account under which the case should be imported. (required)
        :type pacer_user_id: str
        :param case_number: The case number of the case to be imported. (required)
        :type case_number: str
        :param court_id: The courtId value of the court from which the case is to be imported. (required)
        :type court_id: str
        :param pacer_client_code: This is mandatory if your setting in PACER website is set to Yes for the flag `Require Client Code?` under `Set PACER Billing Preferences` page. The client code is a text field entered by users upon login that can be used to track usage by person, client matter number, or other meaningful entry up to 32 characters, comprising the following:    Alphabetic characters (A-Z or a-z)    Numeric digits (0-9)   Period (.)    Underscore (_)    Hyphen (-)    Slash (/)
        :type pacer_client_code: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = PACERCaseImportApi(api_client).import_pacer_case_by_court_using_case_number_without_preload_content_with_http_info(pacer_user_id = pacer_user_id, case_number = case_number, court_id = court_id, workspace_id = unicourt.WORKSPACE_ID, pacer_client_code = pacer_client_code, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
