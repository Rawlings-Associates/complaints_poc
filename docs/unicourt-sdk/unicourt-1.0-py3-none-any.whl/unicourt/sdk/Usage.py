import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from datetime import date
from pydantic import Field, StrictStr, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.daily_usage_response import DailyUsageResponse
from unicourt.model.monthly_usage_response import MonthlyUsageResponse
from unicourt.model.workspace_daily_usage_response import WorkspaceDailyUsageResponse
from unicourt.model.workspace_monthly_usage_response import WorkspaceMonthlyUsageResponse
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.usage_api import UsageApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class Usage:

    @staticmethod
    def get_account_daily_usage_by_date(
        date: Annotated[date, Field(description="The specific date for which you wish to obtain information on Billing Activity Usage for the account.")],
        product: Annotated[Optional[StrictStr], Field(description="Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[DailyUsageResponse]:

        """Get Billing Activity Usage for a requested Date for the account.

        An endpoint to obtain information on Billing Activity Usage for the account on a given day.

        :param date: The specific date for which you wish to obtain information on Billing Activity Usage for the account. (required)
        :type date: date
        :param product: Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.
        :type product: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = UsageApi(api_client).get_account_daily_usage_by_date_with_http_info(date = date, product = product, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_account_daily_usage_by_date_with_http_info(
        date: Annotated[date, Field(description="The specific date for which you wish to obtain information on Billing Activity Usage for the account.")],
        product: Annotated[Optional[StrictStr], Field(description="Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[DailyUsageResponse]:

        """Get Billing Activity Usage for a requested Date for the account.

        An endpoint to obtain information on Billing Activity Usage for the account on a given day.

        :param date: The specific date for which you wish to obtain information on Billing Activity Usage for the account. (required)
        :type date: date
        :param product: Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.
        :type product: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return UsageApi(api_client).get_account_daily_usage_by_date_with_http_info(date = date, product = product, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_account_daily_usage_by_date_without_preload_content(
        date: Annotated[date, Field(description="The specific date for which you wish to obtain information on Billing Activity Usage for the account.")],
        product: Annotated[Optional[StrictStr], Field(description="Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get Billing Activity Usage for a requested Date for the account.

        An endpoint to obtain information on Billing Activity Usage for the account on a given day.

        :param date: The specific date for which you wish to obtain information on Billing Activity Usage for the account. (required)
        :type date: date
        :param product: Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.
        :type product: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = UsageApi(api_client).get_account_daily_usage_by_date_without_preload_content_with_http_info(date = date, product = product, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_account_monthly_usage(
        month: Annotated[str, Field(min_length=7, strict=True, max_length=7, description="The month in YYYY-MM format for which you wish to obtain Billing Activity Usage information for the account.")],
        product: Annotated[Optional[StrictStr], Field(description="Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[MonthlyUsageResponse]:

        """Specify the month to know the Billing Activity usage for the account.

        An endpoint to obtain information on Billing Activity Usage for the account during a specified month.

        :param month: The month in YYYY-MM format for which you wish to obtain Billing Activity Usage information for the account. (required)
        :type month: str
        :param product: Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.
        :type product: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = UsageApi(api_client).get_account_monthly_usage_with_http_info(month = month, product = product, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_account_monthly_usage_with_http_info(
        month: Annotated[str, Field(min_length=7, strict=True, max_length=7, description="The month in YYYY-MM format for which you wish to obtain Billing Activity Usage information for the account.")],
        product: Annotated[Optional[StrictStr], Field(description="Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[MonthlyUsageResponse]:

        """Specify the month to know the Billing Activity usage for the account.

        An endpoint to obtain information on Billing Activity Usage for the account during a specified month.

        :param month: The month in YYYY-MM format for which you wish to obtain Billing Activity Usage information for the account. (required)
        :type month: str
        :param product: Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.
        :type product: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return UsageApi(api_client).get_account_monthly_usage_with_http_info(month = month, product = product, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_account_monthly_usage_without_preload_content(
        month: Annotated[str, Field(min_length=7, strict=True, max_length=7, description="The month in YYYY-MM format for which you wish to obtain Billing Activity Usage information for the account.")],
        product: Annotated[Optional[StrictStr], Field(description="Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Specify the month to know the Billing Activity usage for the account.

        An endpoint to obtain information on Billing Activity Usage for the account during a specified month.

        :param month: The month in YYYY-MM format for which you wish to obtain Billing Activity Usage information for the account. (required)
        :type month: str
        :param product: Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.
        :type product: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = UsageApi(api_client).get_account_monthly_usage_without_preload_content_with_http_info(month = month, product = product, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_workspace_daily_usage_by_date(
        date: Annotated[date, Field(description="The specific date for which you wish to obtain information on Billing Activity Usage for a specific workspace.")],
        product: Annotated[Optional[StrictStr], Field(description="Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[WorkspaceDailyUsageResponse]:

        """Get Billing Activity Usage for a requested Date for a workspace.

        An endpoint to obtain information on Billing Activity Usage for a specific workspace on a given day.
        :param date: The specific date for which you wish to obtain information on Billing Activity Usage for a specific workspace. (required)
        :type date: date
        :param product: Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.
        :type product: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = UsageApi(api_client).get_workspace_daily_usage_by_date_with_http_info(workspace_id = unicourt.WORKSPACE_ID, date = date, product = product, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_workspace_daily_usage_by_date_with_http_info(
        date: Annotated[date, Field(description="The specific date for which you wish to obtain information on Billing Activity Usage for a specific workspace.")],
        product: Annotated[Optional[StrictStr], Field(description="Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[WorkspaceDailyUsageResponse]:

        """Get Billing Activity Usage for a requested Date for a workspace.

        An endpoint to obtain information on Billing Activity Usage for a specific workspace on a given day.
        :param date: The specific date for which you wish to obtain information on Billing Activity Usage for a specific workspace. (required)
        :type date: date
        :param product: Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.
        :type product: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return UsageApi(api_client).get_workspace_daily_usage_by_date_with_http_info(workspace_id = unicourt.WORKSPACE_ID, date = date, product = product, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_workspace_daily_usage_by_date_without_preload_content(
        date: Annotated[date, Field(description="The specific date for which you wish to obtain information on Billing Activity Usage for a specific workspace.")],
        product: Annotated[Optional[StrictStr], Field(description="Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get Billing Activity Usage for a requested Date for a workspace.

        An endpoint to obtain information on Billing Activity Usage for a specific workspace on a given day.
        :param date: The specific date for which you wish to obtain information on Billing Activity Usage for a specific workspace. (required)
        :type date: date
        :param product: Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.
        :type product: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = UsageApi(api_client).get_workspace_daily_usage_by_date_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, date = date, product = product, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_workspace_monthly_usage(
        month: Annotated[str, Field(min_length=7, strict=True, max_length=7, description="The month in YYYY-MM format for which you wish to obtain Billing Activity Usage information for the workspace.")],
        product: Annotated[Optional[StrictStr], Field(description="Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[WorkspaceMonthlyUsageResponse]:

        """Specify the workspaceId and month to know the Billing Activity usage for a workspace.

        An endpoint to obtain information on Billing Activity Usage for a specific workspace during a specified month.
        :param month: The month in YYYY-MM format for which you wish to obtain Billing Activity Usage information for the workspace. (required)
        :type month: str
        :param product: Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.
        :type product: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = UsageApi(api_client).get_workspace_monthly_usage_with_http_info(workspace_id = unicourt.WORKSPACE_ID, month = month, product = product, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_workspace_monthly_usage_with_http_info(
        month: Annotated[str, Field(min_length=7, strict=True, max_length=7, description="The month in YYYY-MM format for which you wish to obtain Billing Activity Usage information for the workspace.")],
        product: Annotated[Optional[StrictStr], Field(description="Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[WorkspaceMonthlyUsageResponse]:

        """Specify the workspaceId and month to know the Billing Activity usage for a workspace.

        An endpoint to obtain information on Billing Activity Usage for a specific workspace during a specified month.
        :param month: The month in YYYY-MM format for which you wish to obtain Billing Activity Usage information for the workspace. (required)
        :type month: str
        :param product: Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.
        :type product: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return UsageApi(api_client).get_workspace_monthly_usage_with_http_info(workspace_id = unicourt.WORKSPACE_ID, month = month, product = product, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_workspace_monthly_usage_without_preload_content(
        month: Annotated[str, Field(min_length=7, strict=True, max_length=7, description="The month in YYYY-MM format for which you wish to obtain Billing Activity Usage information for the workspace.")],
        product: Annotated[Optional[StrictStr], Field(description="Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Specify the workspaceId and month to know the Billing Activity usage for a workspace.

        An endpoint to obtain information on Billing Activity Usage for a specific workspace during a specified month.
        :param month: The month in YYYY-MM format for which you wish to obtain Billing Activity Usage information for the workspace. (required)
        :type month: str
        :param product: Product to filter billing activity usage. Valid values are DART, DEEP, and WIDGET.
        :type product: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = UsageApi(api_client).get_workspace_monthly_usage_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, month = month, product = product, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
