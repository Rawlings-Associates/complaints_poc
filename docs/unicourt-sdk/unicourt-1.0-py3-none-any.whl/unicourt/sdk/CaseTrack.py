import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from datetime import datetime
from pydantic import Field
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.case_track import CaseTrack
from unicourt.model.case_track_request import CaseTrackRequest
from unicourt.model.case_track_response import CaseTrackResponse
from unicourt.model.case_tracks_response import CaseTracksResponse
from unicourt.model.success import Success
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.case_track_api import CaseTrackApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class CaseTrack:

    @staticmethod
    def get_case_track_by_id(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseId for which case tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseTrack]:

        """Get the case object for a specific case with the tracking information.

        Retrieve comprehensive tracking information for a specific case including current status, schedule configuration, tracking history, and next refresh window. Returns detailed case data with monitoring progress and estimated track counts. The caseId parameter specifies the case for which tracking information is to be retrieved.
        :param case_id: The caseId for which case tracking operations are performed. (required)
        :type case_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseTrackApi(api_client).get_case_track_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_track_by_id_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseId for which case tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseTrack]:

        """Get the case object for a specific case with the tracking information.

        Retrieve comprehensive tracking information for a specific case including current status, schedule configuration, tracking history, and next refresh window. Returns detailed case data with monitoring progress and estimated track counts. The caseId parameter specifies the case for which tracking information is to be retrieved.
        :param case_id: The caseId for which case tracking operations are performed. (required)
        :type case_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseTrackApi(api_client).get_case_track_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_track_by_id_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseId for which case tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get the case object for a specific case with the tracking information.

        Retrieve comprehensive tracking information for a specific case including current status, schedule configuration, tracking history, and next refresh window. Returns detailed case data with monitoring progress and estimated track counts. The caseId parameter specifies the case for which tracking information is to be retrieved.
        :param case_id: The caseId for which case tracking operations are performed. (required)
        :type case_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseTrackApi(api_client).get_case_track_by_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_tracks(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the case was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked cases regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the case information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked cases, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseTracksResponse]:

        """Get Case Track list with date-based filtering on updates.

        Fetch paginated list of tracked cases with optional filtering by lastFetchDate (when case was fetched) or lastFetchDateWithUpdates (when changes were found). Response includes case tracking previews, schedule options, refresh windows, estimated monthly track counts and current server time.
        :param last_fetch_date: Specifies the timestamp of the last time the case was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked cases regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the case information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked cases, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseTrackApi(api_client).get_case_tracks_with_http_info(workspace_id = unicourt.WORKSPACE_ID, last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_tracks_with_http_info(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the case was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked cases regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the case information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked cases, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseTracksResponse]:

        """Get Case Track list with date-based filtering on updates.

        Fetch paginated list of tracked cases with optional filtering by lastFetchDate (when case was fetched) or lastFetchDateWithUpdates (when changes were found). Response includes case tracking previews, schedule options, refresh windows, estimated monthly track counts and current server time.
        :param last_fetch_date: Specifies the timestamp of the last time the case was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked cases regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the case information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked cases, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseTrackApi(api_client).get_case_tracks_with_http_info(workspace_id = unicourt.WORKSPACE_ID, last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_tracks_without_preload_content(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the case was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked cases regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the case information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked cases, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get Case Track list with date-based filtering on updates.

        Fetch paginated list of tracked cases with optional filtering by lastFetchDate (when case was fetched) or lastFetchDateWithUpdates (when changes were found). Response includes case tracking previews, schedule options, refresh windows, estimated monthly track counts and current server time.
        :param last_fetch_date: Specifies the timestamp of the last time the case was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked cases regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the case information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked cases, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseTrackApi(api_client).get_case_tracks_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_tracks_root(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the case was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked cases regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the case information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked cases, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseTracksResponse]:

        """Get Case Track list with date-based filtering on updates.

        Fetch paginated list of tracked cases with optional filtering by lastFetchDate (when case was fetched) or lastFetchDateWithUpdates (when changes were found). Response includes case tracking previews, schedule options, refresh windows, estimated monthly track counts and current server time.

        :param last_fetch_date: Specifies the timestamp of the last time the case was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked cases regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the case information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked cases, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseTrackApi(api_client).get_case_tracks_root_with_http_info(last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_tracks_root_with_http_info(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the case was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked cases regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the case information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked cases, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseTracksResponse]:

        """Get Case Track list with date-based filtering on updates.

        Fetch paginated list of tracked cases with optional filtering by lastFetchDate (when case was fetched) or lastFetchDateWithUpdates (when changes were found). Response includes case tracking previews, schedule options, refresh windows, estimated monthly track counts and current server time.

        :param last_fetch_date: Specifies the timestamp of the last time the case was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked cases regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the case information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked cases, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseTrackApi(api_client).get_case_tracks_root_with_http_info(last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_tracks_root_without_preload_content(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the case was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked cases regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the case information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked cases, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get Case Track list with date-based filtering on updates.

        Fetch paginated list of tracked cases with optional filtering by lastFetchDate (when case was fetched) or lastFetchDateWithUpdates (when changes were found). Response includes case tracking previews, schedule options, refresh windows, estimated monthly track counts and current server time.

        :param last_fetch_date: Specifies the timestamp of the last time the case was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked cases regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the case information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked cases, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseTrackApi(api_client).get_case_tracks_root_without_preload_content_with_http_info(last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def remove_case_track_by_id(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseId for which case tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[Success]:

        """Remove Case Track for a specific Case Id.

        Delete the tracking configuration for the specified case ID, stopping all automated monitoring activities including scheduled refreshes and court data fetching. This action is permanent and removes the case from your tracking system. The caseId parameter specifies the case for which tracking is to be deleted.
        :param case_id: The caseId for which case tracking operations are performed. (required)
        :type case_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseTrackApi(api_client).remove_case_track_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def remove_case_track_by_id_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseId for which case tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[Success]:

        """Remove Case Track for a specific Case Id.

        Delete the tracking configuration for the specified case ID, stopping all automated monitoring activities including scheduled refreshes and court data fetching. This action is permanent and removes the case from your tracking system. The caseId parameter specifies the case for which tracking is to be deleted.
        :param case_id: The caseId for which case tracking operations are performed. (required)
        :type case_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseTrackApi(api_client).remove_case_track_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def remove_case_track_by_id_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseId for which case tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Remove Case Track for a specific Case Id.

        Delete the tracking configuration for the specified case ID, stopping all automated monitoring activities including scheduled refreshes and court data fetching. This action is permanent and removes the case from your tracking system. The caseId parameter specifies the case for which tracking is to be deleted.
        :param case_id: The caseId for which case tracking operations are performed. (required)
        :type case_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseTrackApi(api_client).remove_case_track_by_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def track_case(
        case_track_request: Optional[CaseTrackRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseTrackResponse]:

        """Add Case Track for the requested Case ID with a set refresh window for automated updates.

        Track the specified case with a refresh window set. The `start date` must be today's date or a future date according to the court's timezone. Supported schedules include `hourly`, `daily`, `weekly` and `monthly` options . When `refreshWindow` is `1d/1D` or less than 1 day (hourly windows), the `daysOfWeekArray` field can be used to specify which days of the week to track. The progress of this Case Track request will soon be available via web socket messages. In the meantime, you can use /caseTracks or /caseTrack/{caseId} to view tracking information. For detailed information on Court Optimal Hour scheduling and refresh windows, refer to the <a href=\"https://docs.unicourt.com/knowledge-base/case-track\"> Case Track Documentation </a><br>  **Status Progression:**    - **IN_PROGRESS**: The request is being processed, from the start until the defined timeout is reached.   - **DELAYED**: An intermittent source or internal issue has slowed down the process.   - **FAILURE**: The request could not be completed within the timeout period, or the process encountered an error due to source or internal issues.   - **COMPLETE**: The process was successfully completed. 
        :param case_track_request:
        :type case_track_request: CaseTrackRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseTrackApi(api_client).track_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_track_request = case_track_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def track_case_with_http_info(
        case_track_request: Optional[CaseTrackRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseTrackResponse]:

        """Add Case Track for the requested Case ID with a set refresh window for automated updates.

        Track the specified case with a refresh window set. The `start date` must be today's date or a future date according to the court's timezone. Supported schedules include `hourly`, `daily`, `weekly` and `monthly` options . When `refreshWindow` is `1d/1D` or less than 1 day (hourly windows), the `daysOfWeekArray` field can be used to specify which days of the week to track. The progress of this Case Track request will soon be available via web socket messages. In the meantime, you can use /caseTracks or /caseTrack/{caseId} to view tracking information. For detailed information on Court Optimal Hour scheduling and refresh windows, refer to the <a href=\"https://docs.unicourt.com/knowledge-base/case-track\"> Case Track Documentation </a><br>  **Status Progression:**    - **IN_PROGRESS**: The request is being processed, from the start until the defined timeout is reached.   - **DELAYED**: An intermittent source or internal issue has slowed down the process.   - **FAILURE**: The request could not be completed within the timeout period, or the process encountered an error due to source or internal issues.   - **COMPLETE**: The process was successfully completed. 
        :param case_track_request:
        :type case_track_request: CaseTrackRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseTrackApi(api_client).track_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_track_request = case_track_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def track_case_without_preload_content(
        case_track_request: Optional[CaseTrackRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Add Case Track for the requested Case ID with a set refresh window for automated updates.

        Track the specified case with a refresh window set. The `start date` must be today's date or a future date according to the court's timezone. Supported schedules include `hourly`, `daily`, `weekly` and `monthly` options . When `refreshWindow` is `1d/1D` or less than 1 day (hourly windows), the `daysOfWeekArray` field can be used to specify which days of the week to track. The progress of this Case Track request will soon be available via web socket messages. In the meantime, you can use /caseTracks or /caseTrack/{caseId} to view tracking information. For detailed information on Court Optimal Hour scheduling and refresh windows, refer to the <a href=\"https://docs.unicourt.com/knowledge-base/case-track\"> Case Track Documentation </a><br>  **Status Progression:**    - **IN_PROGRESS**: The request is being processed, from the start until the defined timeout is reached.   - **DELAYED**: An intermittent source or internal issue has slowed down the process.   - **FAILURE**: The request could not be completed within the timeout period, or the process encountered an error due to source or internal issues.   - **COMPLETE**: The process was successfully completed. 
        :param case_track_request:
        :type case_track_request: CaseTrackRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseTrackApi(api_client).track_case_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_track_request = case_track_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
