import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.norm_attorney_update import NormAttorneyUpdate
from unicourt.model.norm_attorney_update_request import NormAttorneyUpdateRequest
from unicourt.model.norm_attorney_updates_response import NormAttorneyUpdatesResponse
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.attorney_update_api import AttorneyUpdateApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class AttorneyUpdate:

    @staticmethod
    def get_norm_attorney_update_by_norm_attorney_id(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of Attorney.    - minimum: 18   - maximum: 18 ")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormAttorneyUpdate]:

        """Get norm Attorney updates for a requested normAttorneyId

        Retrieve norm Attorney updates for the specified normAttorney object
        :param norm_attorney_id: Norm ID of Attorney.    - minimum: 18   - maximum: 18  (required)
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyUpdateApi(api_client).get_norm_attorney_update_by_norm_attorney_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_norm_attorney_update_by_norm_attorney_id_with_http_info(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of Attorney.    - minimum: 18   - maximum: 18 ")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormAttorneyUpdate]:

        """Get norm Attorney updates for a requested normAttorneyId

        Retrieve norm Attorney updates for the specified normAttorney object
        :param norm_attorney_id: Norm ID of Attorney.    - minimum: 18   - maximum: 18  (required)
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneyUpdateApi(api_client).get_norm_attorney_update_by_norm_attorney_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_norm_attorney_update_by_norm_attorney_id_without_preload_content(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of Attorney.    - minimum: 18   - maximum: 18 ")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get norm Attorney updates for a requested normAttorneyId

        Retrieve norm Attorney updates for the specified normAttorney object
        :param norm_attorney_id: Norm ID of Attorney.    - minimum: 18   - maximum: 18  (required)
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyUpdateApi(api_client).get_norm_attorney_update_by_norm_attorney_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_norm_attorney_updates(
        norm_attorney_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="The normAttorneyId for which updates should be retrieved")] = None,
        last_n_days: Annotated[Optional[Annotated[int, Field(le=30, strict=True, ge=1)]], Field(description="Number of days to look back for Attorney Update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a attorney was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of the norm Attorney updates to be retrieved. By default, it returns all updates with statuses of `COMPLETE` and `FAILURE`.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the desired page of results.   - minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormAttorneyUpdatesResponse]:

        """Get Norm Attorney Update list for a requested time range.

        Retrieve attorney update requests that have been submitted within a specified time period. This endpoint returns a paginated list of attorney update statuses, allowing you to monitor the progress of your update requests. You can filter results by specific attorney ID, request status (IN_PROGRESS, COMPLETE, FAILURE, DELAYED), and time range (up to 30 days). Each response includes detailed status information, timestamps, and links to the associated case data. Use this endpoint to track bulk operations and ensure your attorney updates are proceeding as expected.
        :param norm_attorney_id: The normAttorneyId for which updates should be retrieved
        :type norm_attorney_id: str
        :param last_n_days: Number of days to look back for Attorney Update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a attorney was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.
        :type last_n_days: int
        :param status: Status of the norm Attorney updates to be retrieved. By default, it returns all updates with statuses of `COMPLETE` and `FAILURE`.
        :type status: str
        :param page_number: The page number of the desired page of results.   - minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyUpdateApi(api_client).get_norm_attorney_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_id = norm_attorney_id, last_n_days = last_n_days, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_norm_attorney_updates_with_http_info(
        norm_attorney_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="The normAttorneyId for which updates should be retrieved")] = None,
        last_n_days: Annotated[Optional[Annotated[int, Field(le=30, strict=True, ge=1)]], Field(description="Number of days to look back for Attorney Update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a attorney was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of the norm Attorney updates to be retrieved. By default, it returns all updates with statuses of `COMPLETE` and `FAILURE`.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the desired page of results.   - minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormAttorneyUpdatesResponse]:

        """Get Norm Attorney Update list for a requested time range.

        Retrieve attorney update requests that have been submitted within a specified time period. This endpoint returns a paginated list of attorney update statuses, allowing you to monitor the progress of your update requests. You can filter results by specific attorney ID, request status (IN_PROGRESS, COMPLETE, FAILURE, DELAYED), and time range (up to 30 days). Each response includes detailed status information, timestamps, and links to the associated case data. Use this endpoint to track bulk operations and ensure your attorney updates are proceeding as expected.
        :param norm_attorney_id: The normAttorneyId for which updates should be retrieved
        :type norm_attorney_id: str
        :param last_n_days: Number of days to look back for Attorney Update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a attorney was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.
        :type last_n_days: int
        :param status: Status of the norm Attorney updates to be retrieved. By default, it returns all updates with statuses of `COMPLETE` and `FAILURE`.
        :type status: str
        :param page_number: The page number of the desired page of results.   - minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneyUpdateApi(api_client).get_norm_attorney_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_id = norm_attorney_id, last_n_days = last_n_days, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_norm_attorney_updates_without_preload_content(
        norm_attorney_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="The normAttorneyId for which updates should be retrieved")] = None,
        last_n_days: Annotated[Optional[Annotated[int, Field(le=30, strict=True, ge=1)]], Field(description="Number of days to look back for Attorney Update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a attorney was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of the norm Attorney updates to be retrieved. By default, it returns all updates with statuses of `COMPLETE` and `FAILURE`.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the desired page of results.   - minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get Norm Attorney Update list for a requested time range.

        Retrieve attorney update requests that have been submitted within a specified time period. This endpoint returns a paginated list of attorney update statuses, allowing you to monitor the progress of your update requests. You can filter results by specific attorney ID, request status (IN_PROGRESS, COMPLETE, FAILURE, DELAYED), and time range (up to 30 days). Each response includes detailed status information, timestamps, and links to the associated case data. Use this endpoint to track bulk operations and ensure your attorney updates are proceeding as expected.
        :param norm_attorney_id: The normAttorneyId for which updates should be retrieved
        :type norm_attorney_id: str
        :param last_n_days: Number of days to look back for Attorney Update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a attorney was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.
        :type last_n_days: int
        :param status: Status of the norm Attorney updates to be retrieved. By default, it returns all updates with statuses of `COMPLETE` and `FAILURE`.
        :type status: str
        :param page_number: The page number of the desired page of results.   - minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyUpdateApi(api_client).get_norm_attorney_updates_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_id = norm_attorney_id, last_n_days = last_n_days, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def put_norm_attorney_update(
        norm_attorney_update_request: Annotated[Optional[NormAttorneyUpdateRequest], Field(description="The endpoint accepts attorney input.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormAttorneyUpdate]:

        """Add Attorney Update for requested normAttorneyId

        Request Attorney Update for the specified normAttorneyId. Once a request is made, the status will be marked as IN_PROGRESS. If the request is not completed within the expected timeframe or if there are any issues with the extraction process, it will be recorded as FAILURE.  Status Progression Based on Time Intervals:  - **IN_PROGRESS**: From the start of the request until the timeouts are reached. - **FAILURE**: If the request remains incomplete beyond the timeout period or if there are any issues with the extraction process.  **Note**: The `notifyOnDelay` feature is not currently supported. Even if `notifyOnDelay` is passed as true, the request will return a 400 Bad Request error.  The progress of this Attorney Update request is available via web socket messages documented on <a href=\"/developers/enterpriseapi/api-alpha/async/UniCourt-Enterprise-Callback-Async-Alpha-API-Spec\">Alpha WebSocket Callbacks Documentation</a>. 
        :param norm_attorney_update_request: The endpoint accepts attorney input.
        :type norm_attorney_update_request: NormAttorneyUpdateRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyUpdateApi(api_client).put_norm_attorney_update_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_update_request = norm_attorney_update_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def put_norm_attorney_update_with_http_info(
        norm_attorney_update_request: Annotated[Optional[NormAttorneyUpdateRequest], Field(description="The endpoint accepts attorney input.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormAttorneyUpdate]:

        """Add Attorney Update for requested normAttorneyId

        Request Attorney Update for the specified normAttorneyId. Once a request is made, the status will be marked as IN_PROGRESS. If the request is not completed within the expected timeframe or if there are any issues with the extraction process, it will be recorded as FAILURE.  Status Progression Based on Time Intervals:  - **IN_PROGRESS**: From the start of the request until the timeouts are reached. - **FAILURE**: If the request remains incomplete beyond the timeout period or if there are any issues with the extraction process.  **Note**: The `notifyOnDelay` feature is not currently supported. Even if `notifyOnDelay` is passed as true, the request will return a 400 Bad Request error.  The progress of this Attorney Update request is available via web socket messages documented on <a href=\"/developers/enterpriseapi/api-alpha/async/UniCourt-Enterprise-Callback-Async-Alpha-API-Spec\">Alpha WebSocket Callbacks Documentation</a>. 
        :param norm_attorney_update_request: The endpoint accepts attorney input.
        :type norm_attorney_update_request: NormAttorneyUpdateRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneyUpdateApi(api_client).put_norm_attorney_update_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_update_request = norm_attorney_update_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def put_norm_attorney_update_without_preload_content(
        norm_attorney_update_request: Annotated[Optional[NormAttorneyUpdateRequest], Field(description="The endpoint accepts attorney input.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Add Attorney Update for requested normAttorneyId

        Request Attorney Update for the specified normAttorneyId. Once a request is made, the status will be marked as IN_PROGRESS. If the request is not completed within the expected timeframe or if there are any issues with the extraction process, it will be recorded as FAILURE.  Status Progression Based on Time Intervals:  - **IN_PROGRESS**: From the start of the request until the timeouts are reached. - **FAILURE**: If the request remains incomplete beyond the timeout period or if there are any issues with the extraction process.  **Note**: The `notifyOnDelay` feature is not currently supported. Even if `notifyOnDelay` is passed as true, the request will return a 400 Bad Request error.  The progress of this Attorney Update request is available via web socket messages documented on <a href=\"/developers/enterpriseapi/api-alpha/async/UniCourt-Enterprise-Callback-Async-Alpha-API-Spec\">Alpha WebSocket Callbacks Documentation</a>. 
        :param norm_attorney_update_request: The endpoint accepts attorney input.
        :type norm_attorney_update_request: NormAttorneyUpdateRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyUpdateApi(api_client).put_norm_attorney_update_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_update_request = norm_attorney_update_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
