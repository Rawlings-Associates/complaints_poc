import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.court_service_status_response import CourtServiceStatusResponse
from unicourt.model.court_source_service_status_response import CourtSourceServiceStatusResponse
from unicourt.model.court_system_service_status_response import CourtSystemServiceStatusResponse
from unicourt.model.tentative_ruling_source import TentativeRulingSource
from unicourt.model.tentative_ruling_source_response import TentativeRulingSourceResponse
from unicourt.model.tentative_ruling_source_service_status_response import TentativeRulingSourceServiceStatusResponse
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.court_service_status_api import CourtServiceStatusApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class CourtServiceStatus:

    @staticmethod
    def get_court_source_service_status(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSourceServiceStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtSourceServiceStatusResponse]:

        """Court Source Service Status Objects

        Fetch the list of court source service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Charlotte County Court) AND courtId:\"CORThSxcef8eGUSkuC\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Charlotte County Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Charlotte County Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Charlotte County Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Charlotte County Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORThSxcef8eGUSkuC\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtSourceServiceStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSourceServiceStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtServiceStatusApi(api_client).get_court_source_service_status_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_source_service_status_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSourceServiceStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtSourceServiceStatusResponse]:

        """Court Source Service Status Objects

        Fetch the list of court source service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Charlotte County Court) AND courtId:\"CORThSxcef8eGUSkuC\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Charlotte County Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Charlotte County Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Charlotte County Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Charlotte County Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORThSxcef8eGUSkuC\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtSourceServiceStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSourceServiceStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtServiceStatusApi(api_client).get_court_source_service_status_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_court_source_service_status_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSourceServiceStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Court Source Service Status Objects

        Fetch the list of court source service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Charlotte County Court) AND courtId:\"CORThSxcef8eGUSkuC\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Charlotte County Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Charlotte County Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Charlotte County Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Charlotte County Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORThSxcef8eGUSkuC\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtSourceServiceStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSourceServiceStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtServiceStatusApi(api_client).get_court_source_service_status_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_system_service_status(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSystemServiceStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtSystemServiceStatusResponse]:

        """Court System Service Status Objects

        Fetch the list of court system service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(CourtSystem:(name:(California Superior Courts) AND courtSystemId:\"COSYACHBdMewtaG5DY\"))** | | **OR** | Returns results matching any specified condition. | **(CourtSystem:(name:(California Superior Courts) OR courtSystemId:\"COSYACHBdMewtaG5DY\"))** | | **NOT** | Excludes results matching the specified condition. | **(CourtSystem:(name:(California) NOT courtSystemId:\"COSYACHBdMewtaG5DY\"))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(CourtSystem:(name:\"California Superior Courts\"))** | | **( ... )** | Groups multiple conditions together. | **(CourtSystem:(name:(California Superior Courts) OR courtType:State)) AND (CourtSystem:(courtSystemId:\"COSYACHBdMewtaG5DY\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtSystemServiceStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSystemServiceStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtServiceStatusApi(api_client).get_court_system_service_status_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_system_service_status_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSystemServiceStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtSystemServiceStatusResponse]:

        """Court System Service Status Objects

        Fetch the list of court system service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(CourtSystem:(name:(California Superior Courts) AND courtSystemId:\"COSYACHBdMewtaG5DY\"))** | | **OR** | Returns results matching any specified condition. | **(CourtSystem:(name:(California Superior Courts) OR courtSystemId:\"COSYACHBdMewtaG5DY\"))** | | **NOT** | Excludes results matching the specified condition. | **(CourtSystem:(name:(California) NOT courtSystemId:\"COSYACHBdMewtaG5DY\"))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(CourtSystem:(name:\"California Superior Courts\"))** | | **( ... )** | Groups multiple conditions together. | **(CourtSystem:(name:(California Superior Courts) OR courtType:State)) AND (CourtSystem:(courtSystemId:\"COSYACHBdMewtaG5DY\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtSystemServiceStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSystemServiceStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtServiceStatusApi(api_client).get_court_system_service_status_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_court_system_service_status_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSystemServiceStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Court System Service Status Objects

        Fetch the list of court system service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(CourtSystem:(name:(California Superior Courts) AND courtSystemId:\"COSYACHBdMewtaG5DY\"))** | | **OR** | Returns results matching any specified condition. | **(CourtSystem:(name:(California Superior Courts) OR courtSystemId:\"COSYACHBdMewtaG5DY\"))** | | **NOT** | Excludes results matching the specified condition. | **(CourtSystem:(name:(California) NOT courtSystemId:\"COSYACHBdMewtaG5DY\"))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(CourtSystem:(name:\"California Superior Courts\"))** | | **( ... )** | Groups multiple conditions together. | **(CourtSystem:(name:(California Superior Courts) OR courtType:State)) AND (CourtSystem:(courtSystemId:\"COSYACHBdMewtaG5DY\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtSystemServiceStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSystemServiceStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtServiceStatusApi(api_client).get_court_system_service_status_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_courts_service_status(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtServiceStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtServiceStatusResponse]:

        """Court Service Status Objects

        Fetch the list of court service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Charlotte County Court) AND courtId:\"CORThSxcef8eGUSkuC\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Charlotte County Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Charlotte County Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Charlotte County Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Charlotte County Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORThSxcef8eGUSkuC\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtServiceStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtServiceStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtServiceStatusApi(api_client).get_courts_service_status_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_courts_service_status_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtServiceStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtServiceStatusResponse]:

        """Court Service Status Objects

        Fetch the list of court service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Charlotte County Court) AND courtId:\"CORThSxcef8eGUSkuC\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Charlotte County Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Charlotte County Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Charlotte County Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Charlotte County Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORThSxcef8eGUSkuC\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtServiceStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtServiceStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtServiceStatusApi(api_client).get_courts_service_status_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_courts_service_status_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtServiceStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Court Service Status Objects

        Fetch the list of court service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Charlotte County Court) AND courtId:\"CORThSxcef8eGUSkuC\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Charlotte County Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Charlotte County Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Charlotte County Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Charlotte County Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORThSxcef8eGUSkuC\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtServiceStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtServiceStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtServiceStatusApi(api_client).get_courts_service_status_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_tentative_ruling_source_by_id(
        tentative_ruling_source_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The tentativeRulingSourceId of the tentative ruling source to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[TentativeRulingSource]:

        """Tentative Ruling Source details for the provided tentativeRulingSourceId.

        Fetch the details of the specific tentative ruling source. 
        :param tentative_ruling_source_id: The tentativeRulingSourceId of the tentative ruling source to be retrieved. (required)
        :type tentative_ruling_source_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtServiceStatusApi(api_client).get_tentative_ruling_source_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, tentative_ruling_source_id = tentative_ruling_source_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_tentative_ruling_source_by_id_with_http_info(
        tentative_ruling_source_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The tentativeRulingSourceId of the tentative ruling source to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[TentativeRulingSource]:

        """Tentative Ruling Source details for the provided tentativeRulingSourceId.

        Fetch the details of the specific tentative ruling source. 
        :param tentative_ruling_source_id: The tentativeRulingSourceId of the tentative ruling source to be retrieved. (required)
        :type tentative_ruling_source_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtServiceStatusApi(api_client).get_tentative_ruling_source_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, tentative_ruling_source_id = tentative_ruling_source_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_tentative_ruling_source_by_id_without_preload_content(
        tentative_ruling_source_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The tentativeRulingSourceId of the tentative ruling source to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Tentative Ruling Source details for the provided tentativeRulingSourceId.

        Fetch the details of the specific tentative ruling source. 
        :param tentative_ruling_source_id: The tentativeRulingSourceId of the tentative ruling source to be retrieved. (required)
        :type tentative_ruling_source_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtServiceStatusApi(api_client).get_tentative_ruling_source_by_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, tentative_ruling_source_id = tentative_ruling_source_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_tentative_ruling_source_service_status(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `tentativeRulingSourceServiceStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[TentativeRulingSourceServiceStatusResponse]:

        """Tentative Ruling Service Status Object.

        Fetch the list of tentative ruling service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Ventura County Superior Court) AND courtId:\"CORTLmr3s9mbzktTZ7\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Ventura County Superior Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Ventura County Superior Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Ventura County Superior Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Ventura County Superior Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORTLmr3s9mbzktTZ7\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> tentativeRulingSourceServiceStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `tentativeRulingSourceServiceStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtServiceStatusApi(api_client).get_tentative_ruling_source_service_status_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_tentative_ruling_source_service_status_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `tentativeRulingSourceServiceStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[TentativeRulingSourceServiceStatusResponse]:

        """Tentative Ruling Service Status Object.

        Fetch the list of tentative ruling service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Ventura County Superior Court) AND courtId:\"CORTLmr3s9mbzktTZ7\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Ventura County Superior Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Ventura County Superior Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Ventura County Superior Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Ventura County Superior Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORTLmr3s9mbzktTZ7\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> tentativeRulingSourceServiceStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `tentativeRulingSourceServiceStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtServiceStatusApi(api_client).get_tentative_ruling_source_service_status_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_tentative_ruling_source_service_status_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `tentativeRulingSourceServiceStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Tentative Ruling Service Status Object.

        Fetch the list of tentative ruling service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Ventura County Superior Court) AND courtId:\"CORTLmr3s9mbzktTZ7\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Ventura County Superior Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Ventura County Superior Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Ventura County Superior Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Ventura County Superior Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORTLmr3s9mbzktTZ7\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> tentativeRulingSourceServiceStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `tentativeRulingSourceServiceStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtServiceStatusApi(api_client).get_tentative_ruling_source_service_status_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def gettentative_ruling_source(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `tentativeRulingSourceQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[TentativeRulingSourceResponse]:

        """Tentative Ruling Service Status Object.

        Fetch the list of tentative ruling service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Ventura County Superior Court) AND courtId:\"CORTLmr3s9mbzktTZ7\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Ventura County Superior Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Ventura County Superior Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Ventura County Superior Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Ventura County Superior Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORTLmr3s9mbzktTZ7\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> tentativeRulingSourceQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `tentativeRulingSourceQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtServiceStatusApi(api_client).gettentative_ruling_source_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def gettentative_ruling_source_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `tentativeRulingSourceQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[TentativeRulingSourceResponse]:

        """Tentative Ruling Service Status Object.

        Fetch the list of tentative ruling service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Ventura County Superior Court) AND courtId:\"CORTLmr3s9mbzktTZ7\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Ventura County Superior Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Ventura County Superior Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Ventura County Superior Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Ventura County Superior Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORTLmr3s9mbzktTZ7\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> tentativeRulingSourceQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `tentativeRulingSourceQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtServiceStatusApi(api_client).gettentative_ruling_source_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def gettentative_ruling_source_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `tentativeRulingSourceQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Tentative Ruling Service Status Object.

        Fetch the list of tentative ruling service status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Ventura County Superior Court) AND courtId:\"CORTLmr3s9mbzktTZ7\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Ventura County Superior Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Ventura County Superior Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Ventura County Superior Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Ventura County Superior Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORTLmr3s9mbzktTZ7\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> tentativeRulingSourceQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `tentativeRulingSourceQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtServiceStatusApi(api_client).gettentative_ruling_source_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
