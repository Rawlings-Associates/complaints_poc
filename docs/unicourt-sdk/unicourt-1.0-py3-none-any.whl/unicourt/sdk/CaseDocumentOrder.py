import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from datetime import datetime
from pydantic import Field, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.case_document_order_callback import CaseDocumentOrderCallback
from unicourt.model.case_document_order_callbacks_response import CaseDocumentOrderCallbacksResponse
from unicourt.model.case_document_order_request import CaseDocumentOrderRequest
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.case_document_order_api import CaseDocumentOrderApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class CaseDocumentOrder:

    @staticmethod
    def get_case_document_order_callback_by_id(
        case_document_order_callback_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Unique Id for the Case Document Order Callback.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseDocumentOrderCallback]:

        """Get Case Document Order Callback for a requested Case Document Order Callback Id.

        Get Case Document Order Callback for a requested Case Document Order Callback Id.
        :param case_document_order_callback_id: Unique Id for the Case Document Order Callback. (required)
        :type case_document_order_callback_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseDocumentOrderApi(api_client).get_case_document_order_callback_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_document_order_callback_id = case_document_order_callback_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_document_order_callback_by_id_with_http_info(
        case_document_order_callback_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Unique Id for the Case Document Order Callback.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseDocumentOrderCallback]:

        """Get Case Document Order Callback for a requested Case Document Order Callback Id.

        Get Case Document Order Callback for a requested Case Document Order Callback Id.
        :param case_document_order_callback_id: Unique Id for the Case Document Order Callback. (required)
        :type case_document_order_callback_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseDocumentOrderApi(api_client).get_case_document_order_callback_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_document_order_callback_id = case_document_order_callback_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_document_order_callback_by_id_without_preload_content(
        case_document_order_callback_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Unique Id for the Case Document Order Callback.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get Case Document Order Callback for a requested Case Document Order Callback Id.

        Get Case Document Order Callback for a requested Case Document Order Callback Id.
        :param case_document_order_callback_id: Unique Id for the Case Document Order Callback. (required)
        :type case_document_order_callback_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseDocumentOrderApi(api_client).get_case_document_order_callback_by_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_document_order_callback_id = case_document_order_callback_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_document_order_callbacks(
        callback_generated_date: Annotated[Optional[datetime], Field(description="Timestamp of when the document was fetched based on the callbackGeneratedDate, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests where callback was received from 05:00:00 to current date-time)")] = None,
        start_date: Annotated[Optional[datetime], Field(description="Timestamp of when the API was requested, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests from 05:00:00 to current date-time)")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of Document Order callbacks. Default status will fetch all callbacks.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="Page to fetch the Case Document Order Callback list.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseDocumentOrderCallbacksResponse]:

        """Get Case Document Order Callback list for a callback generated date.

        GET /caseDocumentOrder/callbacks fetches Case Document Order callbacks for a specified date and time range to track document processing results. You can filter results by processing status and paginate through large result sets using the pageNumber parameter. Successful responses contain file download URLs, while failed requests include detailed exception information for troubleshooting.
        :param callback_generated_date: Timestamp of when the document was fetched based on the callbackGeneratedDate, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests where callback was received from 05:00:00 to current date-time)
        :type callback_generated_date: datetime
        :param start_date: Timestamp of when the API was requested, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests from 05:00:00 to current date-time)
        :type start_date: datetime
        :param status: Status of Document Order callbacks. Default status will fetch all callbacks.
        :type status: str
        :param page_number: Page to fetch the Case Document Order Callback list.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseDocumentOrderApi(api_client).get_case_document_order_callbacks_with_http_info(workspace_id = unicourt.WORKSPACE_ID, callback_generated_date = callback_generated_date, start_date = start_date, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_document_order_callbacks_with_http_info(
        callback_generated_date: Annotated[Optional[datetime], Field(description="Timestamp of when the document was fetched based on the callbackGeneratedDate, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests where callback was received from 05:00:00 to current date-time)")] = None,
        start_date: Annotated[Optional[datetime], Field(description="Timestamp of when the API was requested, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests from 05:00:00 to current date-time)")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of Document Order callbacks. Default status will fetch all callbacks.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="Page to fetch the Case Document Order Callback list.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseDocumentOrderCallbacksResponse]:

        """Get Case Document Order Callback list for a callback generated date.

        GET /caseDocumentOrder/callbacks fetches Case Document Order callbacks for a specified date and time range to track document processing results. You can filter results by processing status and paginate through large result sets using the pageNumber parameter. Successful responses contain file download URLs, while failed requests include detailed exception information for troubleshooting.
        :param callback_generated_date: Timestamp of when the document was fetched based on the callbackGeneratedDate, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests where callback was received from 05:00:00 to current date-time)
        :type callback_generated_date: datetime
        :param start_date: Timestamp of when the API was requested, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests from 05:00:00 to current date-time)
        :type start_date: datetime
        :param status: Status of Document Order callbacks. Default status will fetch all callbacks.
        :type status: str
        :param page_number: Page to fetch the Case Document Order Callback list.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseDocumentOrderApi(api_client).get_case_document_order_callbacks_with_http_info(workspace_id = unicourt.WORKSPACE_ID, callback_generated_date = callback_generated_date, start_date = start_date, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_document_order_callbacks_without_preload_content(
        callback_generated_date: Annotated[Optional[datetime], Field(description="Timestamp of when the document was fetched based on the callbackGeneratedDate, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests where callback was received from 05:00:00 to current date-time)")] = None,
        start_date: Annotated[Optional[datetime], Field(description="Timestamp of when the API was requested, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests from 05:00:00 to current date-time)")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of Document Order callbacks. Default status will fetch all callbacks.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="Page to fetch the Case Document Order Callback list.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get Case Document Order Callback list for a callback generated date.

        GET /caseDocumentOrder/callbacks fetches Case Document Order callbacks for a specified date and time range to track document processing results. You can filter results by processing status and paginate through large result sets using the pageNumber parameter. Successful responses contain file download URLs, while failed requests include detailed exception information for troubleshooting.
        :param callback_generated_date: Timestamp of when the document was fetched based on the callbackGeneratedDate, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests where callback was received from 05:00:00 to current date-time)
        :type callback_generated_date: datetime
        :param start_date: Timestamp of when the API was requested, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests from 05:00:00 to current date-time)
        :type start_date: datetime
        :param status: Status of Document Order callbacks. Default status will fetch all callbacks.
        :type status: str
        :param page_number: Page to fetch the Case Document Order Callback list.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseDocumentOrderApi(api_client).get_case_document_order_callbacks_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, callback_generated_date = callback_generated_date, start_date = start_date, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def order_case_document(
        case_document_order_request: Optional[CaseDocumentOrderRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseDocumentOrderCallback]:

        """Add Case Document Order for requested Document Ids.

        Add Case Document Order for requested Document Ids. Once a request is made, the status will be marked as `IN_PROGRESS`.  If the request is not completed within the expected timeframe, it will be recorded as `FAILURE`.   **Status Progression Based on Time Intervals:**     **`IN_PROGRESS`**: From the start of the request until the timeouts are reached.<br>  **`DELAYED`**: If there was any intermittent or internal issue with the extraction process.<br>  **`FAILURE`**: If the request remains incomplete beyond the timeout period or if there are any issues with the extraction process.<br>  The progress of this Case DocumentOrder request is available via web socket messages documented on   <a href=\"/developers/enterpriseapi/api-alpha/async/UniCourt-Enterprise-Callback-Async-Alpha-API-Spec\">Alpha WebSocket Callbacks Documentation</a>. 
        :param case_document_order_request:
        :type case_document_order_request: CaseDocumentOrderRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseDocumentOrderApi(api_client).order_case_document_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_document_order_request = case_document_order_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def order_case_document_with_http_info(
        case_document_order_request: Optional[CaseDocumentOrderRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseDocumentOrderCallback]:

        """Add Case Document Order for requested Document Ids.

        Add Case Document Order for requested Document Ids. Once a request is made, the status will be marked as `IN_PROGRESS`.  If the request is not completed within the expected timeframe, it will be recorded as `FAILURE`.   **Status Progression Based on Time Intervals:**     **`IN_PROGRESS`**: From the start of the request until the timeouts are reached.<br>  **`DELAYED`**: If there was any intermittent or internal issue with the extraction process.<br>  **`FAILURE`**: If the request remains incomplete beyond the timeout period or if there are any issues with the extraction process.<br>  The progress of this Case DocumentOrder request is available via web socket messages documented on   <a href=\"/developers/enterpriseapi/api-alpha/async/UniCourt-Enterprise-Callback-Async-Alpha-API-Spec\">Alpha WebSocket Callbacks Documentation</a>. 
        :param case_document_order_request:
        :type case_document_order_request: CaseDocumentOrderRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseDocumentOrderApi(api_client).order_case_document_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_document_order_request = case_document_order_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def order_case_document_without_preload_content(
        case_document_order_request: Optional[CaseDocumentOrderRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Add Case Document Order for requested Document Ids.

        Add Case Document Order for requested Document Ids. Once a request is made, the status will be marked as `IN_PROGRESS`.  If the request is not completed within the expected timeframe, it will be recorded as `FAILURE`.   **Status Progression Based on Time Intervals:**     **`IN_PROGRESS`**: From the start of the request until the timeouts are reached.<br>  **`DELAYED`**: If there was any intermittent or internal issue with the extraction process.<br>  **`FAILURE`**: If the request remains incomplete beyond the timeout period or if there are any issues with the extraction process.<br>  The progress of this Case DocumentOrder request is available via web socket messages documented on   <a href=\"/developers/enterpriseapi/api-alpha/async/UniCourt-Enterprise-Callback-Async-Alpha-API-Spec\">Alpha WebSocket Callbacks Documentation</a>. 
        :param case_document_order_request:
        :type case_document_order_request: CaseDocumentOrderRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseDocumentOrderApi(api_client).order_case_document_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_document_order_request = case_document_order_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
