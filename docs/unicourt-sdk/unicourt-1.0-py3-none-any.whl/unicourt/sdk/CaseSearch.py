import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.case_search_response import CaseSearchResponse
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.case_search_api import CaseSearchApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class CaseSearch:

    @staticmethod
    def search_cases(
        q: Annotated[str, Field(min_length=3, strict=True, max_length=2000, description="Query parameter must follow the logical operator rules described above and use only fields supported by the `CaseSearchQueryObject` schema. ")],
        page_number: Annotated[Optional[Annotated[int, Field(le=1000, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=9, strict=True, max_length=9)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseSearchResponse]:

        """Case search.

        This endpoint retrieves cases according to keyword expressions you provide. <br> Keyword expressions are constructed according to the rules described below. <br><br> This API supports multiple use cases:   - Search for multiple keywords  `Google OR Facebook`.   - Search within particular attributes.   - Relational search using terms and connectors.   - And much more. ----  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** |Find cases containing each of the terms joined by AND connectors.|**caseName:(cavalry) AND (CaseStatus:(caseClass:civil))**| | **OR**  |Find cases containing any of the terms joined by OR connectors.|**caseName:(cavalry) OR (Party:(name:(john)))**| | **NOT** |Find cases that do not contain the specified term.|**caseName:(cavalry) NOT (Party:(name:(john)))**| | **“[phrase]”** |Find the exact phrase placed between the quotation marks.|**caseName:\"cavalry\"**| | **~**  |Find cases in which the specified words appear near each other. For example, \"personal injury\" ~ 5 targets cases in which the word \"personal\" appears within 5 words of the word \"injury\".|**\"personal injury\" ~ 5**| | **( … )** |Specifies the order in which connectors are to be applied in a keyword expression.| **caseName:(cavalry) AND ((Party:(name:(john))) OR (Counsel:(name:(john))))**|  <br><br> ## Fields and Connectors Searching | Field | Description  | Example | | ------| ------|------| |**caseNumber** |Find cases with the specified case number (i.e., docket number).| **caseNumber:\"2020-L-007212\"**| |**caseName** |Find cases with the specified case title.| **caseName:\"Cavalry Portfolio Services\"**| |**Court**|Find cases in the specified court.|**(Court:(name:(New York)))**<br>| |**CaseStatus**|Find cases with the specified case status.|**(CaseStatus:(name:Open))**| |**CaseType**|Find cases of the specified case type. | **(CaseType:(name:Property))**| |**Party** | Find cases involving the specified party.| **(Party:(name:Apple))**| |**partyId**|Find cases involving a party with the specified partyId value.|**(Party:(partyId:\"PRTYgk92e279ef3980\"))**| |**PartyRole** | Find cases in which at least one party has the specified party role. | **(Party:((PartyRole:(name:\"plaintiff\"))))**| |**Counsel** | Find cases involving the specified counsel. | **(Counsel:(name:\"BAILEY\"))**| |**CounselRole**|Find cases involving at least one counsel of the specified counsel role.|**(Counsel:((CounselRole:(name:\"Lead Counsel\"))))**| |**Judge** |Find cases involving the specified judge. | **(Judge:(name:\"John\"))** | |**JudgeRole**|Find cases involving at least one judge of the specified judge type.|**(Judge:(JudgeRole:(name:\"Magistrate\")))**| |**CaseStats**|Find cases with the specified case statistics.|**(CaseStats:(partyCount:[10 TO 100]))**| |**filedDate** | Find cases that were filed on the specified date or within the specified date range. | **filedDate:[2020-03-15T00:00:00 TO 2021-12-01T00:00:00]**| |**lastFetchDate**| Find cases in which UniCourt last checked for updates on the specified date or within the specified date range. |**(lastFetchDate:[now-60d TO \\*\\])**| |**lastFetchDateWithUpdates**|Find cases in which UniCourt last detected an update on the specified date or within the specified date range.|**(lastFetchDateWithUpdates:[now-6d TO \\*\\])**| |**participantsLastFetchDate**|Find cases in which information concerning participants was last updated on the specified date or within the specified date range.|**(participantsLastFetchDate:[now-6d TO \\*\\])**| |**DocketEntry**|Find cases in which at least one docket entry contains the specified text.|**(DocketEntry:(text:(Motion to Compel Responses) AND docketEntryDate:[2020-01-01T00:00:00 TO 2020-05-01T00:00:00]))**| |**docketEntryDate**|Find cases in which at least one docket entry was made on the specified date or within the specified date range.|**(DocketEntry:(docketEntryDate:[2020-01-01T00:00:00 TO 2020-05-01T00:00:00])) AND (CaseStats:(allCaseDocumentCount:[0 TO 10]))**| |**HearingDate**| Find cases with at least one hearing scheduled for the specified date or within the specified date range.|**(Hearing:(hearingDate:[now TO now+10d]))**| |**HearingDate**| Search for cases where hearing is going to happen in 10 to 20days.|**(Hearing:(hearingDate:[now+10d TO now+20d]))**| |**JurisdictionGeo**|Find cases in which the law of the specified state governs.|**(JurisdictionGeo:(state:\"New York\"))**| |**Document**|Find cases with specific document name and preview is available for the document.|**(CaseDocument:(name:\"civil case cover sheet\" AND isPreviewAvailable:true))**| |**Document**| Find cases in which document text contains the specified text.|**(CaseDocument:(text:(PETITION FOR REMOVAL FROM FIRST)))**   <br><br> --- ## Party Sub Filter Examples |Example |Explanation | |---|---| |**(Party:(name:google AND (PartyRole:(name:\"plaintiff\"))))**|Find cases involving at least one plaintiff whose name contains the term \"Google\".|  --- ### All query parameters supported for this API can be found in below schema section. Schema -->  CaseSearchQueryObject 

        :param q: Query parameter must follow the logical operator rules described above and use only fields supported by the `CaseSearchQueryObject` schema.  (required)
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseSearchApi(api_client).search_cases_with_http_info(q = q, workspace_id = unicourt.WORKSPACE_ID, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def search_cases_with_http_info(
        q: Annotated[str, Field(min_length=3, strict=True, max_length=2000, description="Query parameter must follow the logical operator rules described above and use only fields supported by the `CaseSearchQueryObject` schema. ")],
        page_number: Annotated[Optional[Annotated[int, Field(le=1000, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=9, strict=True, max_length=9)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseSearchResponse]:

        """Case search.

        This endpoint retrieves cases according to keyword expressions you provide. <br> Keyword expressions are constructed according to the rules described below. <br><br> This API supports multiple use cases:   - Search for multiple keywords  `Google OR Facebook`.   - Search within particular attributes.   - Relational search using terms and connectors.   - And much more. ----  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** |Find cases containing each of the terms joined by AND connectors.|**caseName:(cavalry) AND (CaseStatus:(caseClass:civil))**| | **OR**  |Find cases containing any of the terms joined by OR connectors.|**caseName:(cavalry) OR (Party:(name:(john)))**| | **NOT** |Find cases that do not contain the specified term.|**caseName:(cavalry) NOT (Party:(name:(john)))**| | **“[phrase]”** |Find the exact phrase placed between the quotation marks.|**caseName:\"cavalry\"**| | **~**  |Find cases in which the specified words appear near each other. For example, \"personal injury\" ~ 5 targets cases in which the word \"personal\" appears within 5 words of the word \"injury\".|**\"personal injury\" ~ 5**| | **( … )** |Specifies the order in which connectors are to be applied in a keyword expression.| **caseName:(cavalry) AND ((Party:(name:(john))) OR (Counsel:(name:(john))))**|  <br><br> ## Fields and Connectors Searching | Field | Description  | Example | | ------| ------|------| |**caseNumber** |Find cases with the specified case number (i.e., docket number).| **caseNumber:\"2020-L-007212\"**| |**caseName** |Find cases with the specified case title.| **caseName:\"Cavalry Portfolio Services\"**| |**Court**|Find cases in the specified court.|**(Court:(name:(New York)))**<br>| |**CaseStatus**|Find cases with the specified case status.|**(CaseStatus:(name:Open))**| |**CaseType**|Find cases of the specified case type. | **(CaseType:(name:Property))**| |**Party** | Find cases involving the specified party.| **(Party:(name:Apple))**| |**partyId**|Find cases involving a party with the specified partyId value.|**(Party:(partyId:\"PRTYgk92e279ef3980\"))**| |**PartyRole** | Find cases in which at least one party has the specified party role. | **(Party:((PartyRole:(name:\"plaintiff\"))))**| |**Counsel** | Find cases involving the specified counsel. | **(Counsel:(name:\"BAILEY\"))**| |**CounselRole**|Find cases involving at least one counsel of the specified counsel role.|**(Counsel:((CounselRole:(name:\"Lead Counsel\"))))**| |**Judge** |Find cases involving the specified judge. | **(Judge:(name:\"John\"))** | |**JudgeRole**|Find cases involving at least one judge of the specified judge type.|**(Judge:(JudgeRole:(name:\"Magistrate\")))**| |**CaseStats**|Find cases with the specified case statistics.|**(CaseStats:(partyCount:[10 TO 100]))**| |**filedDate** | Find cases that were filed on the specified date or within the specified date range. | **filedDate:[2020-03-15T00:00:00 TO 2021-12-01T00:00:00]**| |**lastFetchDate**| Find cases in which UniCourt last checked for updates on the specified date or within the specified date range. |**(lastFetchDate:[now-60d TO \\*\\])**| |**lastFetchDateWithUpdates**|Find cases in which UniCourt last detected an update on the specified date or within the specified date range.|**(lastFetchDateWithUpdates:[now-6d TO \\*\\])**| |**participantsLastFetchDate**|Find cases in which information concerning participants was last updated on the specified date or within the specified date range.|**(participantsLastFetchDate:[now-6d TO \\*\\])**| |**DocketEntry**|Find cases in which at least one docket entry contains the specified text.|**(DocketEntry:(text:(Motion to Compel Responses) AND docketEntryDate:[2020-01-01T00:00:00 TO 2020-05-01T00:00:00]))**| |**docketEntryDate**|Find cases in which at least one docket entry was made on the specified date or within the specified date range.|**(DocketEntry:(docketEntryDate:[2020-01-01T00:00:00 TO 2020-05-01T00:00:00])) AND (CaseStats:(allCaseDocumentCount:[0 TO 10]))**| |**HearingDate**| Find cases with at least one hearing scheduled for the specified date or within the specified date range.|**(Hearing:(hearingDate:[now TO now+10d]))**| |**HearingDate**| Search for cases where hearing is going to happen in 10 to 20days.|**(Hearing:(hearingDate:[now+10d TO now+20d]))**| |**JurisdictionGeo**|Find cases in which the law of the specified state governs.|**(JurisdictionGeo:(state:\"New York\"))**| |**Document**|Find cases with specific document name and preview is available for the document.|**(CaseDocument:(name:\"civil case cover sheet\" AND isPreviewAvailable:true))**| |**Document**| Find cases in which document text contains the specified text.|**(CaseDocument:(text:(PETITION FOR REMOVAL FROM FIRST)))**   <br><br> --- ## Party Sub Filter Examples |Example |Explanation | |---|---| |**(Party:(name:google AND (PartyRole:(name:\"plaintiff\"))))**|Find cases involving at least one plaintiff whose name contains the term \"Google\".|  --- ### All query parameters supported for this API can be found in below schema section. Schema -->  CaseSearchQueryObject 

        :param q: Query parameter must follow the logical operator rules described above and use only fields supported by the `CaseSearchQueryObject` schema.  (required)
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseSearchApi(api_client).search_cases_with_http_info(q = q, workspace_id = unicourt.WORKSPACE_ID, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def search_cases_without_preload_content(
        q: Annotated[str, Field(min_length=3, strict=True, max_length=2000, description="Query parameter must follow the logical operator rules described above and use only fields supported by the `CaseSearchQueryObject` schema. ")],
        page_number: Annotated[Optional[Annotated[int, Field(le=1000, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=9, strict=True, max_length=9)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case search.

        This endpoint retrieves cases according to keyword expressions you provide. <br> Keyword expressions are constructed according to the rules described below. <br><br> This API supports multiple use cases:   - Search for multiple keywords  `Google OR Facebook`.   - Search within particular attributes.   - Relational search using terms and connectors.   - And much more. ----  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** |Find cases containing each of the terms joined by AND connectors.|**caseName:(cavalry) AND (CaseStatus:(caseClass:civil))**| | **OR**  |Find cases containing any of the terms joined by OR connectors.|**caseName:(cavalry) OR (Party:(name:(john)))**| | **NOT** |Find cases that do not contain the specified term.|**caseName:(cavalry) NOT (Party:(name:(john)))**| | **“[phrase]”** |Find the exact phrase placed between the quotation marks.|**caseName:\"cavalry\"**| | **~**  |Find cases in which the specified words appear near each other. For example, \"personal injury\" ~ 5 targets cases in which the word \"personal\" appears within 5 words of the word \"injury\".|**\"personal injury\" ~ 5**| | **( … )** |Specifies the order in which connectors are to be applied in a keyword expression.| **caseName:(cavalry) AND ((Party:(name:(john))) OR (Counsel:(name:(john))))**|  <br><br> ## Fields and Connectors Searching | Field | Description  | Example | | ------| ------|------| |**caseNumber** |Find cases with the specified case number (i.e., docket number).| **caseNumber:\"2020-L-007212\"**| |**caseName** |Find cases with the specified case title.| **caseName:\"Cavalry Portfolio Services\"**| |**Court**|Find cases in the specified court.|**(Court:(name:(New York)))**<br>| |**CaseStatus**|Find cases with the specified case status.|**(CaseStatus:(name:Open))**| |**CaseType**|Find cases of the specified case type. | **(CaseType:(name:Property))**| |**Party** | Find cases involving the specified party.| **(Party:(name:Apple))**| |**partyId**|Find cases involving a party with the specified partyId value.|**(Party:(partyId:\"PRTYgk92e279ef3980\"))**| |**PartyRole** | Find cases in which at least one party has the specified party role. | **(Party:((PartyRole:(name:\"plaintiff\"))))**| |**Counsel** | Find cases involving the specified counsel. | **(Counsel:(name:\"BAILEY\"))**| |**CounselRole**|Find cases involving at least one counsel of the specified counsel role.|**(Counsel:((CounselRole:(name:\"Lead Counsel\"))))**| |**Judge** |Find cases involving the specified judge. | **(Judge:(name:\"John\"))** | |**JudgeRole**|Find cases involving at least one judge of the specified judge type.|**(Judge:(JudgeRole:(name:\"Magistrate\")))**| |**CaseStats**|Find cases with the specified case statistics.|**(CaseStats:(partyCount:[10 TO 100]))**| |**filedDate** | Find cases that were filed on the specified date or within the specified date range. | **filedDate:[2020-03-15T00:00:00 TO 2021-12-01T00:00:00]**| |**lastFetchDate**| Find cases in which UniCourt last checked for updates on the specified date or within the specified date range. |**(lastFetchDate:[now-60d TO \\*\\])**| |**lastFetchDateWithUpdates**|Find cases in which UniCourt last detected an update on the specified date or within the specified date range.|**(lastFetchDateWithUpdates:[now-6d TO \\*\\])**| |**participantsLastFetchDate**|Find cases in which information concerning participants was last updated on the specified date or within the specified date range.|**(participantsLastFetchDate:[now-6d TO \\*\\])**| |**DocketEntry**|Find cases in which at least one docket entry contains the specified text.|**(DocketEntry:(text:(Motion to Compel Responses) AND docketEntryDate:[2020-01-01T00:00:00 TO 2020-05-01T00:00:00]))**| |**docketEntryDate**|Find cases in which at least one docket entry was made on the specified date or within the specified date range.|**(DocketEntry:(docketEntryDate:[2020-01-01T00:00:00 TO 2020-05-01T00:00:00])) AND (CaseStats:(allCaseDocumentCount:[0 TO 10]))**| |**HearingDate**| Find cases with at least one hearing scheduled for the specified date or within the specified date range.|**(Hearing:(hearingDate:[now TO now+10d]))**| |**HearingDate**| Search for cases where hearing is going to happen in 10 to 20days.|**(Hearing:(hearingDate:[now+10d TO now+20d]))**| |**JurisdictionGeo**|Find cases in which the law of the specified state governs.|**(JurisdictionGeo:(state:\"New York\"))**| |**Document**|Find cases with specific document name and preview is available for the document.|**(CaseDocument:(name:\"civil case cover sheet\" AND isPreviewAvailable:true))**| |**Document**| Find cases in which document text contains the specified text.|**(CaseDocument:(text:(PETITION FOR REMOVAL FROM FIRST)))**   <br><br> --- ## Party Sub Filter Examples |Example |Explanation | |---|---| |**(Party:(name:google AND (PartyRole:(name:\"plaintiff\"))))**|Find cases involving at least one plaintiff whose name contains the term \"Google\".|  --- ### All query parameters supported for this API can be found in below schema section. Schema -->  CaseSearchQueryObject 

        :param q: Query parameter must follow the logical operator rules described above and use only fields supported by the `CaseSearchQueryObject` schema.  (required)
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseSearchApi(api_client).search_cases_without_preload_content_with_http_info(q = q, workspace_id = unicourt.WORKSPACE_ID, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def search_cases_by_id(
        case_search_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case Search information for the given caseSearchId.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=1000, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseSearchResponse]:

        """Case search results for a provided caseSearchId.

        Fetch the search results corresponding to the specified caseSearchId value. <br> <br> Note: Case Search ID will be automatically deprecated if it is not used within 3 consecutive days from the time of creation.  Once deprecated, the ID will no longer be valid. 
        :param case_search_id: Case Search information for the given caseSearchId. (required)
        :type case_search_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseSearchApi(api_client).search_cases_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_search_id = case_search_id, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def search_cases_by_id_with_http_info(
        case_search_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case Search information for the given caseSearchId.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=1000, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseSearchResponse]:

        """Case search results for a provided caseSearchId.

        Fetch the search results corresponding to the specified caseSearchId value. <br> <br> Note: Case Search ID will be automatically deprecated if it is not used within 3 consecutive days from the time of creation.  Once deprecated, the ID will no longer be valid. 
        :param case_search_id: Case Search information for the given caseSearchId. (required)
        :type case_search_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseSearchApi(api_client).search_cases_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_search_id = case_search_id, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def search_cases_by_id_without_preload_content(
        case_search_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case Search information for the given caseSearchId.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=1000, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case search results for a provided caseSearchId.

        Fetch the search results corresponding to the specified caseSearchId value. <br> <br> Note: Case Search ID will be automatically deprecated if it is not used within 3 consecutive days from the time of creation.  Once deprecated, the ID will no longer be valid. 
        :param case_search_id: Case Search information for the given caseSearchId. (required)
        :type case_search_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseSearchApi(api_client).search_cases_by_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_search_id = case_search_id, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
