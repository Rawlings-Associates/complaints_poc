import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.norm_attorney_search_response import NormAttorneySearchResponse
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.attorney_search_api import AttorneySearchApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class AttorneySearch:

    @staticmethod
    def search_normalized_attorneys(
        q: Annotated[str, Field(min_length=3, strict=True, max_length=2000, description="Query expressions must follow the logical operator rules described above and use only fields supported by the `NormAttorneySearchQueryObject` schema. ")],
        page_number: Annotated[Optional[Annotated[int, Field(le=1000, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormAttorneySearchResponse]:

        """Attorney search.

        Fetch the list of attorneys matching the search query. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **firstName:(WARREN) AND lastName:(OSGOOD)** | | **OR** | Returns results matching any specified condition. | **firstName:(WARREN) OR lastName:(OSGOOD)** | | **NOT** | Excludes results matching the specified condition. | **firstName:(WARREN) NOT lastName:(OSGOOD)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"WARREN CARPENTER OSGOOD\"** | | **( ... )** | Groups multiple conditions together. | **(firstName:(WARREN) OR lastName:(OSGOOD)) AND normAttorneyId:\"QATTM0VnRF4w4MBLEQ\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> NormAttorneySearchQueryObject 

        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `NormAttorneySearchQueryObject` schema.  (required)
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneySearchApi(api_client).search_normalized_attorneys_with_http_info(q = q, workspace_id = unicourt.WORKSPACE_ID, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def search_normalized_attorneys_with_http_info(
        q: Annotated[str, Field(min_length=3, strict=True, max_length=2000, description="Query expressions must follow the logical operator rules described above and use only fields supported by the `NormAttorneySearchQueryObject` schema. ")],
        page_number: Annotated[Optional[Annotated[int, Field(le=1000, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormAttorneySearchResponse]:

        """Attorney search.

        Fetch the list of attorneys matching the search query. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **firstName:(WARREN) AND lastName:(OSGOOD)** | | **OR** | Returns results matching any specified condition. | **firstName:(WARREN) OR lastName:(OSGOOD)** | | **NOT** | Excludes results matching the specified condition. | **firstName:(WARREN) NOT lastName:(OSGOOD)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"WARREN CARPENTER OSGOOD\"** | | **( ... )** | Groups multiple conditions together. | **(firstName:(WARREN) OR lastName:(OSGOOD)) AND normAttorneyId:\"QATTM0VnRF4w4MBLEQ\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> NormAttorneySearchQueryObject 

        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `NormAttorneySearchQueryObject` schema.  (required)
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneySearchApi(api_client).search_normalized_attorneys_with_http_info(q = q, workspace_id = unicourt.WORKSPACE_ID, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def search_normalized_attorneys_without_preload_content(
        q: Annotated[str, Field(min_length=3, strict=True, max_length=2000, description="Query expressions must follow the logical operator rules described above and use only fields supported by the `NormAttorneySearchQueryObject` schema. ")],
        page_number: Annotated[Optional[Annotated[int, Field(le=1000, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Attorney search.

        Fetch the list of attorneys matching the search query. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **firstName:(WARREN) AND lastName:(OSGOOD)** | | **OR** | Returns results matching any specified condition. | **firstName:(WARREN) OR lastName:(OSGOOD)** | | **NOT** | Excludes results matching the specified condition. | **firstName:(WARREN) NOT lastName:(OSGOOD)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"WARREN CARPENTER OSGOOD\"** | | **( ... )** | Groups multiple conditions together. | **(firstName:(WARREN) OR lastName:(OSGOOD)) AND normAttorneyId:\"QATTM0VnRF4w4MBLEQ\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> NormAttorneySearchQueryObject 

        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `NormAttorneySearchQueryObject` schema.  (required)
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneySearchApi(api_client).search_normalized_attorneys_without_preload_content_with_http_info(q = q, workspace_id = unicourt.WORKSPACE_ID, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def search_normalized_attorneys_by_id(
        norm_attorney_search_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm Attorney Search information for the provided normAttorneySearchId.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=1000, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormAttorneySearchResponse]:

        """Norm attorney search results for a provided normAttorneySearchId.

        Fetch the Norm Attorney Search information for the provided normAttorneySearchId. 
        :param norm_attorney_search_id: Norm Attorney Search information for the provided normAttorneySearchId. (required)
        :type norm_attorney_search_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneySearchApi(api_client).search_normalized_attorneys_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_search_id = norm_attorney_search_id, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def search_normalized_attorneys_by_id_with_http_info(
        norm_attorney_search_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm Attorney Search information for the provided normAttorneySearchId.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=1000, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormAttorneySearchResponse]:

        """Norm attorney search results for a provided normAttorneySearchId.

        Fetch the Norm Attorney Search information for the provided normAttorneySearchId. 
        :param norm_attorney_search_id: Norm Attorney Search information for the provided normAttorneySearchId. (required)
        :type norm_attorney_search_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneySearchApi(api_client).search_normalized_attorneys_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_search_id = norm_attorney_search_id, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def search_normalized_attorneys_by_id_without_preload_content(
        norm_attorney_search_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm Attorney Search information for the provided normAttorneySearchId.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=1000, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Norm attorney search results for a provided normAttorneySearchId.

        Fetch the Norm Attorney Search information for the provided normAttorneySearchId. 
        :param norm_attorney_search_id: Norm Attorney Search information for the provided normAttorneySearchId. (required)
        :type norm_attorney_search_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 1000 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneySearchApi(api_client).search_normalized_attorneys_by_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_search_id = norm_attorney_search_id, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
