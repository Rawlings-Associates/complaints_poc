import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.case_update import CaseUpdate
from unicourt.model.case_update_request import CaseUpdateRequest
from unicourt.model.case_updates_response import CaseUpdatesResponse
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.case_update_api import CaseUpdateApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class CaseUpdate:

    @staticmethod
    def get_case_update_by_case_id(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseId value of the case object for which updates are to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseUpdate]:

        """Get the CaseUpdate object for the specified caseId with status information.

        Retrieve comprehensive case update details for the specified case ID, including current processing status, timestamps, priority level, and complete case data when available. The response provides processing state (IN_PROGRESS, DELAYED, COMPLETE, FAILURE), timeline information, error diagnostics for failed requests, and PACER integration details for federal cases.
        :param case_id: The caseId value of the case object for which updates are to be retrieved. (required)
        :type case_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseUpdateApi(api_client).get_case_update_by_case_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_update_by_case_id_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseId value of the case object for which updates are to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseUpdate]:

        """Get the CaseUpdate object for the specified caseId with status information.

        Retrieve comprehensive case update details for the specified case ID, including current processing status, timestamps, priority level, and complete case data when available. The response provides processing state (IN_PROGRESS, DELAYED, COMPLETE, FAILURE), timeline information, error diagnostics for failed requests, and PACER integration details for federal cases.
        :param case_id: The caseId value of the case object for which updates are to be retrieved. (required)
        :type case_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseUpdateApi(api_client).get_case_update_by_case_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_update_by_case_id_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseId value of the case object for which updates are to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get the CaseUpdate object for the specified caseId with status information.

        Retrieve comprehensive case update details for the specified case ID, including current processing status, timestamps, priority level, and complete case data when available. The response provides processing state (IN_PROGRESS, DELAYED, COMPLETE, FAILURE), timeline information, error diagnostics for failed requests, and PACER integration details for federal cases.
        :param case_id: The caseId value of the case object for which updates are to be retrieved. (required)
        :type case_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseUpdateApi(api_client).get_case_update_by_case_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_updates(
        case_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="The caseId value of the case for which updates should be retrieved.")] = None,
        last_n_days: Annotated[Optional[Annotated[int, Field(le=30, strict=True, ge=1)]], Field(description="Number of days to look back for case update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a case was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.  ")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of the case updates to be retrieved.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the callbacks to be retrieved.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseUpdatesResponse]:

        """Get case update response details for requests submitted within a specified time period.

        Retrieve case update requests that have been submitted within a specified time period. This endpoint returns a paginated list of case update statuses, allowing you to monitor the progress of your update requests. You can filter results by specific case ID, request status (IN_PROGRESS, COMPLETE, FAILURE, DELAYED), and time range (up to 30 days). Each response includes detailed status information, timestamps, and links to the associated case data. Use this endpoint to track bulk operations and ensure your case updates are proceeding as expected.
        :param case_id: The caseId value of the case for which updates should be retrieved.
        :type case_id: str
        :param last_n_days: Number of days to look back for case update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a case was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.  
        :type last_n_days: int
        :param status: Status of the case updates to be retrieved.
        :type status: str
        :param page_number: The page number of the callbacks to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseUpdateApi(api_client).get_case_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_n_days = last_n_days, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_updates_with_http_info(
        case_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="The caseId value of the case for which updates should be retrieved.")] = None,
        last_n_days: Annotated[Optional[Annotated[int, Field(le=30, strict=True, ge=1)]], Field(description="Number of days to look back for case update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a case was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.  ")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of the case updates to be retrieved.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the callbacks to be retrieved.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseUpdatesResponse]:

        """Get case update response details for requests submitted within a specified time period.

        Retrieve case update requests that have been submitted within a specified time period. This endpoint returns a paginated list of case update statuses, allowing you to monitor the progress of your update requests. You can filter results by specific case ID, request status (IN_PROGRESS, COMPLETE, FAILURE, DELAYED), and time range (up to 30 days). Each response includes detailed status information, timestamps, and links to the associated case data. Use this endpoint to track bulk operations and ensure your case updates are proceeding as expected.
        :param case_id: The caseId value of the case for which updates should be retrieved.
        :type case_id: str
        :param last_n_days: Number of days to look back for case update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a case was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.  
        :type last_n_days: int
        :param status: Status of the case updates to be retrieved.
        :type status: str
        :param page_number: The page number of the callbacks to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseUpdateApi(api_client).get_case_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_n_days = last_n_days, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_updates_without_preload_content(
        case_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="The caseId value of the case for which updates should be retrieved.")] = None,
        last_n_days: Annotated[Optional[Annotated[int, Field(le=30, strict=True, ge=1)]], Field(description="Number of days to look back for case update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a case was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.  ")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of the case updates to be retrieved.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the callbacks to be retrieved.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get case update response details for requests submitted within a specified time period.

        Retrieve case update requests that have been submitted within a specified time period. This endpoint returns a paginated list of case update statuses, allowing you to monitor the progress of your update requests. You can filter results by specific case ID, request status (IN_PROGRESS, COMPLETE, FAILURE, DELAYED), and time range (up to 30 days). Each response includes detailed status information, timestamps, and links to the associated case data. Use this endpoint to track bulk operations and ensure your case updates are proceeding as expected.
        :param case_id: The caseId value of the case for which updates should be retrieved.
        :type case_id: str
        :param last_n_days: Number of days to look back for case update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a case was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.  
        :type last_n_days: int
        :param status: Status of the case updates to be retrieved.
        :type status: str
        :param page_number: The page number of the callbacks to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseUpdateApi(api_client).get_case_updates_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_n_days = last_n_days, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def update_case(
        case_update_request: Optional[CaseUpdateRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseUpdate]:

        """Submit a case update request to refresh case data from the court source.

        Request case updates for the specified case.   **Status Progression:**    **`IN_PROGRESS`**: The request is being processed, from the start until the defined timeout is reached.<br>   **`DELAYED`**: An intermittent source or internal issue has slowed down the process.<br>   **`FAILURE`**: The request could not be completed within the timeout period, or the process encountered an error due to source or internal issues.<br>   **`COMPLETE`**: The process was successfully completed.  The progress of this Case Update request is available via web socket messages documented on   <a href=\"/developers/enterpriseapi/api-alpha/async/UniCourt-Enterprise-Callback-Async-Alpha-API-Spec\">Alpha WebSocket Callbacks Documentation</a>. 
        :param case_update_request:
        :type case_update_request: CaseUpdateRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseUpdateApi(api_client).update_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_update_request = case_update_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def update_case_with_http_info(
        case_update_request: Optional[CaseUpdateRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseUpdate]:

        """Submit a case update request to refresh case data from the court source.

        Request case updates for the specified case.   **Status Progression:**    **`IN_PROGRESS`**: The request is being processed, from the start until the defined timeout is reached.<br>   **`DELAYED`**: An intermittent source or internal issue has slowed down the process.<br>   **`FAILURE`**: The request could not be completed within the timeout period, or the process encountered an error due to source or internal issues.<br>   **`COMPLETE`**: The process was successfully completed.  The progress of this Case Update request is available via web socket messages documented on   <a href=\"/developers/enterpriseapi/api-alpha/async/UniCourt-Enterprise-Callback-Async-Alpha-API-Spec\">Alpha WebSocket Callbacks Documentation</a>. 
        :param case_update_request:
        :type case_update_request: CaseUpdateRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseUpdateApi(api_client).update_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_update_request = case_update_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def update_case_without_preload_content(
        case_update_request: Optional[CaseUpdateRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Submit a case update request to refresh case data from the court source.

        Request case updates for the specified case.   **Status Progression:**    **`IN_PROGRESS`**: The request is being processed, from the start until the defined timeout is reached.<br>   **`DELAYED`**: An intermittent source or internal issue has slowed down the process.<br>   **`FAILURE`**: The request could not be completed within the timeout period, or the process encountered an error due to source or internal issues.<br>   **`COMPLETE`**: The process was successfully completed.  The progress of this Case Update request is available via web socket messages documented on   <a href=\"/developers/enterpriseapi/api-alpha/async/UniCourt-Enterprise-Callback-Async-Alpha-API-Spec\">Alpha WebSocket Callbacks Documentation</a>. 
        :param case_update_request:
        :type case_update_request: CaseUpdateRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseUpdateApi(api_client).update_case_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_update_request = case_update_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
