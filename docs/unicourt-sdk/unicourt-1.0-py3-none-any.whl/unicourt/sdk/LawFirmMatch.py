import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field, field_validator
from typing import List, Optional
from typing_extensions import Annotated
from unicourt.model.norm_law_firm_match_response import NormLawFirmMatchResponse
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.law_firm_match_api import LawFirmMatchApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class LawFirmMatch:

    @staticmethod
    def get_norm_law_firm_match(
        name: Annotated[str, Field(strict=True, max_length=1000, description="Lawfirm Name")],
        state: Annotated[Optional[Annotated[str, Field(strict=True, max_length=2)]], Field(description="state")] = None,
        email_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Lawfirm Email Addresses")] = None,
        address_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Lawfirm Addresses")] = None,
        phone_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Lawfirm Phone Numbers")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormLawFirmMatchResponse]:

        """Norm Lawfirm Results for a given lawfirm name

        Returns an array of Norm Lawfirm object. <br> Firm `name` is mandatory. <br><br> This API supports multiple use cases:   - Search for a lawfirm using name `LAW OFFICE OF LISA A. TAYLOR`.   - Search a lawfirm within particular state.   - Filter the lawfirm search results with additional attributes - `emailList` or  `phoneList` or `addressList`<br><br> ----- <br> ## Terms | Connector | Schema | Description  | Example | | ------| ------|------| ------| |**state** |Single Allowed | Indicates the state the firm is registered.| **CA** | |**name*** |Single Allowed | The name of the firm | **GORDON REES** | |**emailList** |Multiple Allowed | Indicates the email list for the lawfirm.| **[resources@grsm.com]** | |**addressList** |Multiple Allowed | Indicates the address list for the lawfirm.| **[275 BATTERY STREET]** | |**phoneList** |Multiple Allowed | Indicates the phone list for the lawfirm.| **[0987654321]** | 

        :param name: Lawfirm Name (required)
        :type name: str
        :param state: state
        :type state: str
        :param email_list: List of Lawfirm Email Addresses
        :type email_list: List[str]
        :param address_list: List of Lawfirm Addresses
        :type address_list: List[str]
        :param phone_list: List of Lawfirm Phone Numbers
        :type phone_list: List[str]
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmMatchApi(api_client).get_norm_law_firm_match_with_http_info(name = name, workspace_id = unicourt.WORKSPACE_ID, state = state, email_list = email_list, address_list = address_list, phone_list = phone_list, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_norm_law_firm_match_with_http_info(
        name: Annotated[str, Field(strict=True, max_length=1000, description="Lawfirm Name")],
        state: Annotated[Optional[Annotated[str, Field(strict=True, max_length=2)]], Field(description="state")] = None,
        email_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Lawfirm Email Addresses")] = None,
        address_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Lawfirm Addresses")] = None,
        phone_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Lawfirm Phone Numbers")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormLawFirmMatchResponse]:

        """Norm Lawfirm Results for a given lawfirm name

        Returns an array of Norm Lawfirm object. <br> Firm `name` is mandatory. <br><br> This API supports multiple use cases:   - Search for a lawfirm using name `LAW OFFICE OF LISA A. TAYLOR`.   - Search a lawfirm within particular state.   - Filter the lawfirm search results with additional attributes - `emailList` or  `phoneList` or `addressList`<br><br> ----- <br> ## Terms | Connector | Schema | Description  | Example | | ------| ------|------| ------| |**state** |Single Allowed | Indicates the state the firm is registered.| **CA** | |**name*** |Single Allowed | The name of the firm | **GORDON REES** | |**emailList** |Multiple Allowed | Indicates the email list for the lawfirm.| **[resources@grsm.com]** | |**addressList** |Multiple Allowed | Indicates the address list for the lawfirm.| **[275 BATTERY STREET]** | |**phoneList** |Multiple Allowed | Indicates the phone list for the lawfirm.| **[0987654321]** | 

        :param name: Lawfirm Name (required)
        :type name: str
        :param state: state
        :type state: str
        :param email_list: List of Lawfirm Email Addresses
        :type email_list: List[str]
        :param address_list: List of Lawfirm Addresses
        :type address_list: List[str]
        :param phone_list: List of Lawfirm Phone Numbers
        :type phone_list: List[str]
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return LawFirmMatchApi(api_client).get_norm_law_firm_match_with_http_info(name = name, workspace_id = unicourt.WORKSPACE_ID, state = state, email_list = email_list, address_list = address_list, phone_list = phone_list, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_norm_law_firm_match_without_preload_content(
        name: Annotated[str, Field(strict=True, max_length=1000, description="Lawfirm Name")],
        state: Annotated[Optional[Annotated[str, Field(strict=True, max_length=2)]], Field(description="state")] = None,
        email_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Lawfirm Email Addresses")] = None,
        address_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Lawfirm Addresses")] = None,
        phone_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Lawfirm Phone Numbers")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Norm Lawfirm Results for a given lawfirm name

        Returns an array of Norm Lawfirm object. <br> Firm `name` is mandatory. <br><br> This API supports multiple use cases:   - Search for a lawfirm using name `LAW OFFICE OF LISA A. TAYLOR`.   - Search a lawfirm within particular state.   - Filter the lawfirm search results with additional attributes - `emailList` or  `phoneList` or `addressList`<br><br> ----- <br> ## Terms | Connector | Schema | Description  | Example | | ------| ------|------| ------| |**state** |Single Allowed | Indicates the state the firm is registered.| **CA** | |**name*** |Single Allowed | The name of the firm | **GORDON REES** | |**emailList** |Multiple Allowed | Indicates the email list for the lawfirm.| **[resources@grsm.com]** | |**addressList** |Multiple Allowed | Indicates the address list for the lawfirm.| **[275 BATTERY STREET]** | |**phoneList** |Multiple Allowed | Indicates the phone list for the lawfirm.| **[0987654321]** | 

        :param name: Lawfirm Name (required)
        :type name: str
        :param state: state
        :type state: str
        :param email_list: List of Lawfirm Email Addresses
        :type email_list: List[str]
        :param address_list: List of Lawfirm Addresses
        :type address_list: List[str]
        :param phone_list: List of Lawfirm Phone Numbers
        :type phone_list: List[str]
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmMatchApi(api_client).get_norm_law_firm_match_without_preload_content_with_http_info(name = name, workspace_id = unicourt.WORKSPACE_ID, state = state, email_list = email_list, address_list = address_list, phone_list = phone_list, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
