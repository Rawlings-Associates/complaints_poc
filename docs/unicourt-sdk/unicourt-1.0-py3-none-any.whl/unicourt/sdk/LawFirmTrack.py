import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from datetime import datetime
from pydantic import Field, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.norm_law_firm_response import NormLawFirmResponse
from unicourt.model.norm_law_firm_track import NormLawFirmTrack
from unicourt.model.norm_law_firm_track_request import NormLawFirmTrackRequest
from unicourt.model.norm_law_firm_tracks_response import NormLawFirmTracksResponse
from unicourt.model.success import Success
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.law_firm_track_api import LawFirmTrackApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class LawFirmTrack:

    @staticmethod
    def get_law_firm_track_by_id(
        norm_law_firm_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The normLawFirmId for which normLawFirm tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormLawFirmTrack]:

        """Get LawFirm Track for a requested normLawFirmId.

        Retrieve LawFirm Tracking information for the specified normLawFirmId value. The normLawFirmId parameter specifies the law firm for which tracking information is to be retrieved.
        :param norm_law_firm_id: The normLawFirmId for which normLawFirm tracking operations are performed. (required)
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmTrackApi(api_client).get_law_firm_track_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_law_firm_track_by_id_with_http_info(
        norm_law_firm_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The normLawFirmId for which normLawFirm tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormLawFirmTrack]:

        """Get LawFirm Track for a requested normLawFirmId.

        Retrieve LawFirm Tracking information for the specified normLawFirmId value. The normLawFirmId parameter specifies the law firm for which tracking information is to be retrieved.
        :param norm_law_firm_id: The normLawFirmId for which normLawFirm tracking operations are performed. (required)
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return LawFirmTrackApi(api_client).get_law_firm_track_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_law_firm_track_by_id_without_preload_content(
        norm_law_firm_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The normLawFirmId for which normLawFirm tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get LawFirm Track for a requested normLawFirmId.

        Retrieve LawFirm Tracking information for the specified normLawFirmId value. The normLawFirmId parameter specifies the law firm for which tracking information is to be retrieved.
        :param norm_law_firm_id: The normLawFirmId for which normLawFirm tracking operations are performed. (required)
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmTrackApi(api_client).get_law_firm_track_by_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_law_firm_tracks(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the lawFirm was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked lawFirms regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the lawFirm information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked lawFirms, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        norm_law_firm_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="UniCourt's LawFirm Id to filter.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormLawFirmTracksResponse]:

        """Get LawFirm Track list.

        Retrieve a comprehensive list of all actively tracked law firms with their tracking configurations, schedules, and status information.  This endpoint provides detailed insights into tracking activity, including estimated monthly track counts, next refresh windows, and last update timestamps. Use optional query parameters to filter results by fetch dates, specific law firm IDs, or pagination preferences. Returns tracking metadata, schedule options, and current status for each monitored law firm in your account. 
        :param last_fetch_date: Specifies the timestamp of the last time the lawFirm was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked lawFirms regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the lawFirm information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked lawFirms, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param norm_law_firm_id: UniCourt's LawFirm Id to filter.
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmTrackApi(api_client).get_law_firm_tracks_with_http_info(workspace_id = unicourt.WORKSPACE_ID, last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_law_firm_tracks_with_http_info(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the lawFirm was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked lawFirms regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the lawFirm information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked lawFirms, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        norm_law_firm_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="UniCourt's LawFirm Id to filter.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormLawFirmTracksResponse]:

        """Get LawFirm Track list.

        Retrieve a comprehensive list of all actively tracked law firms with their tracking configurations, schedules, and status information.  This endpoint provides detailed insights into tracking activity, including estimated monthly track counts, next refresh windows, and last update timestamps. Use optional query parameters to filter results by fetch dates, specific law firm IDs, or pagination preferences. Returns tracking metadata, schedule options, and current status for each monitored law firm in your account. 
        :param last_fetch_date: Specifies the timestamp of the last time the lawFirm was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked lawFirms regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the lawFirm information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked lawFirms, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param norm_law_firm_id: UniCourt's LawFirm Id to filter.
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return LawFirmTrackApi(api_client).get_law_firm_tracks_with_http_info(workspace_id = unicourt.WORKSPACE_ID, last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_law_firm_tracks_without_preload_content(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the lawFirm was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked lawFirms regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the lawFirm information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked lawFirms, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        norm_law_firm_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="UniCourt's LawFirm Id to filter.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get LawFirm Track list.

        Retrieve a comprehensive list of all actively tracked law firms with their tracking configurations, schedules, and status information.  This endpoint provides detailed insights into tracking activity, including estimated monthly track counts, next refresh windows, and last update timestamps. Use optional query parameters to filter results by fetch dates, specific law firm IDs, or pagination preferences. Returns tracking metadata, schedule options, and current status for each monitored law firm in your account. 
        :param last_fetch_date: Specifies the timestamp of the last time the lawFirm was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked lawFirms regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the lawFirm information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked lawFirms, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param norm_law_firm_id: UniCourt's LawFirm Id to filter.
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmTrackApi(api_client).get_law_firm_tracks_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_law_firm_tracks_root(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the lawFirm was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked lawFirms regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the lawFirm information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked lawFirms, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        norm_law_firm_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="UniCourt's LawFirm Id to filter.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormLawFirmTracksResponse]:

        """Get LawFirm Track list.

        Retrieve a comprehensive list of all actively tracked law firms with their tracking configurations, schedules, and status information. This endpoint provides detailed insights into tracking activity, including estimated monthly track counts, next refresh windows, and last update timestamps. Use optional query parameters to filter results by fetch dates, specific law firm IDs, or pagination preferences. Returns tracking metadata, schedule options, and current status for each monitored law firm in your account. 

        :param last_fetch_date: Specifies the timestamp of the last time the lawFirm was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked lawFirms regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the lawFirm information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked lawFirms, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param norm_law_firm_id: UniCourt's LawFirm Id to filter.
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmTrackApi(api_client).get_law_firm_tracks_root_with_http_info(last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_law_firm_tracks_root_with_http_info(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the lawFirm was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked lawFirms regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the lawFirm information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked lawFirms, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        norm_law_firm_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="UniCourt's LawFirm Id to filter.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormLawFirmTracksResponse]:

        """Get LawFirm Track list.

        Retrieve a comprehensive list of all actively tracked law firms with their tracking configurations, schedules, and status information. This endpoint provides detailed insights into tracking activity, including estimated monthly track counts, next refresh windows, and last update timestamps. Use optional query parameters to filter results by fetch dates, specific law firm IDs, or pagination preferences. Returns tracking metadata, schedule options, and current status for each monitored law firm in your account. 

        :param last_fetch_date: Specifies the timestamp of the last time the lawFirm was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked lawFirms regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the lawFirm information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked lawFirms, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param norm_law_firm_id: UniCourt's LawFirm Id to filter.
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return LawFirmTrackApi(api_client).get_law_firm_tracks_root_with_http_info(last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_law_firm_tracks_root_without_preload_content(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the lawFirm was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked lawFirms regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the lawFirm information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked lawFirms, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        norm_law_firm_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="UniCourt's LawFirm Id to filter.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get LawFirm Track list.

        Retrieve a comprehensive list of all actively tracked law firms with their tracking configurations, schedules, and status information. This endpoint provides detailed insights into tracking activity, including estimated monthly track counts, next refresh windows, and last update timestamps. Use optional query parameters to filter results by fetch dates, specific law firm IDs, or pagination preferences. Returns tracking metadata, schedule options, and current status for each monitored law firm in your account. 

        :param last_fetch_date: Specifies the timestamp of the last time the lawFirm was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked lawFirms regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the lawFirm information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked lawFirms, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param norm_law_firm_id: UniCourt's LawFirm Id to filter.
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmTrackApi(api_client).get_law_firm_tracks_root_without_preload_content_with_http_info(last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def remove_law_firm_track_by_id(
        norm_law_firm_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The normLawFirmId for which normLawFirm tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[Success]:

        """Remove LawFirm Track for a specific LawFirm Id.

        Remove LawFirm Track for a specific LawFirm Id. The normLawFirmId parameter specifies the law firm for which tracking is to be deleted.
        :param norm_law_firm_id: The normLawFirmId for which normLawFirm tracking operations are performed. (required)
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmTrackApi(api_client).remove_law_firm_track_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def remove_law_firm_track_by_id_with_http_info(
        norm_law_firm_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The normLawFirmId for which normLawFirm tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[Success]:

        """Remove LawFirm Track for a specific LawFirm Id.

        Remove LawFirm Track for a specific LawFirm Id. The normLawFirmId parameter specifies the law firm for which tracking is to be deleted.
        :param norm_law_firm_id: The normLawFirmId for which normLawFirm tracking operations are performed. (required)
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return LawFirmTrackApi(api_client).remove_law_firm_track_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def remove_law_firm_track_by_id_without_preload_content(
        norm_law_firm_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The normLawFirmId for which normLawFirm tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Remove LawFirm Track for a specific LawFirm Id.

        Remove LawFirm Track for a specific LawFirm Id. The normLawFirmId parameter specifies the law firm for which tracking is to be deleted.
        :param norm_law_firm_id: The normLawFirmId for which normLawFirm tracking operations are performed. (required)
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmTrackApi(api_client).remove_law_firm_track_by_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def track_law_firm(
        norm_law_firm_track_request: Optional[NormLawFirmTrackRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormLawFirmResponse]:

        """Add LawFirm Track for the requested LawFirm Id with refresh Window set.

        Track the specified LawFirm with a configured refresh window to automatically monitor changes and updates. This endpoint allows you to set up automated tracking for a law firm's information at regular intervals.  **Key Features:** - **Flexible Scheduling**: Configure tracking frequency with weekly (1W), bi-weekly (2W), or monthly (1M) refresh windows - **Date Range Control**: Set optional start and end dates for tracking periods - **Update Detection**: Automatically detects and captures changes in law firm data  **Important Notes:** - The `start date` must be today's date or a future date (optional parameter) - If a track already exists for the law firm, this endpoint will update the existing tracking configuration - **The `notifyOnDelay` feature is not currently supported. Passing `notifyOnDelay` as `true` will result in a 400 Bad Request error.** 
        :param norm_law_firm_track_request:
        :type norm_law_firm_track_request: NormLawFirmTrackRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmTrackApi(api_client).track_law_firm_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_track_request = norm_law_firm_track_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def track_law_firm_with_http_info(
        norm_law_firm_track_request: Optional[NormLawFirmTrackRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormLawFirmResponse]:

        """Add LawFirm Track for the requested LawFirm Id with refresh Window set.

        Track the specified LawFirm with a configured refresh window to automatically monitor changes and updates. This endpoint allows you to set up automated tracking for a law firm's information at regular intervals.  **Key Features:** - **Flexible Scheduling**: Configure tracking frequency with weekly (1W), bi-weekly (2W), or monthly (1M) refresh windows - **Date Range Control**: Set optional start and end dates for tracking periods - **Update Detection**: Automatically detects and captures changes in law firm data  **Important Notes:** - The `start date` must be today's date or a future date (optional parameter) - If a track already exists for the law firm, this endpoint will update the existing tracking configuration - **The `notifyOnDelay` feature is not currently supported. Passing `notifyOnDelay` as `true` will result in a 400 Bad Request error.** 
        :param norm_law_firm_track_request:
        :type norm_law_firm_track_request: NormLawFirmTrackRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return LawFirmTrackApi(api_client).track_law_firm_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_track_request = norm_law_firm_track_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def track_law_firm_without_preload_content(
        norm_law_firm_track_request: Optional[NormLawFirmTrackRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Add LawFirm Track for the requested LawFirm Id with refresh Window set.

        Track the specified LawFirm with a configured refresh window to automatically monitor changes and updates. This endpoint allows you to set up automated tracking for a law firm's information at regular intervals.  **Key Features:** - **Flexible Scheduling**: Configure tracking frequency with weekly (1W), bi-weekly (2W), or monthly (1M) refresh windows - **Date Range Control**: Set optional start and end dates for tracking periods - **Update Detection**: Automatically detects and captures changes in law firm data  **Important Notes:** - The `start date` must be today's date or a future date (optional parameter) - If a track already exists for the law firm, this endpoint will update the existing tracking configuration - **The `notifyOnDelay` feature is not currently supported. Passing `notifyOnDelay` as `true` will result in a 400 Bad Request error.** 
        :param norm_law_firm_track_request:
        :type norm_law_firm_track_request: NormLawFirmTrackRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmTrackApi(api_client).track_law_firm_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_track_request = norm_law_firm_track_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
