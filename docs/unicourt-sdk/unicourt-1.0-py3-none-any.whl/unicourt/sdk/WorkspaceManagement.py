import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.archive_workspace_request import ArchiveWorkspaceRequest
from unicourt.model.archive_workspace_response import ArchiveWorkspaceResponse
from unicourt.model.create_workspace_request import CreateWorkspaceRequest
from unicourt.model.create_workspace_response import CreateWorkspaceResponse
from unicourt.model.update_workspace_request import UpdateWorkspaceRequest
from unicourt.model.update_workspace_response import UpdateWorkspaceResponse
from unicourt.model.workspace import Workspace
from unicourt.model.workspace_details_response import WorkspaceDetailsResponse
from unicourt.model.workspace_search_response import WorkspaceSearchResponse
from unicourt.model.workspace_template import WorkspaceTemplate
from unicourt.model.workspace_templates_response import WorkspaceTemplatesResponse
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.workspace_management_api import WorkspaceManagementApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class WorkspaceManagement:

    @staticmethod
    def archive_workspace_request(
        archive_workspace_request: Optional[ArchiveWorkspaceRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[ArchiveWorkspaceResponse]:

        """Archive an existing workspace

        API to archive a workspace from the account. When a workspace is archived, it will be moved to the workspace trash and remains for 30 days before being permanently archived.

        :param archive_workspace_request:
        :type archive_workspace_request: ArchiveWorkspaceRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).archive_workspace_request_with_http_info(archive_workspace_request = archive_workspace_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def archive_workspace_request_with_http_info(
        archive_workspace_request: Optional[ArchiveWorkspaceRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[ArchiveWorkspaceResponse]:

        """Archive an existing workspace

        API to archive a workspace from the account. When a workspace is archived, it will be moved to the workspace trash and remains for 30 days before being permanently archived.

        :param archive_workspace_request:
        :type archive_workspace_request: ArchiveWorkspaceRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return WorkspaceManagementApi(api_client).archive_workspace_request_with_http_info(archive_workspace_request = archive_workspace_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def archive_workspace_request_without_preload_content(
        archive_workspace_request: Optional[ArchiveWorkspaceRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Archive an existing workspace

        API to archive a workspace from the account. When a workspace is archived, it will be moved to the workspace trash and remains for 30 days before being permanently archived.

        :param archive_workspace_request:
        :type archive_workspace_request: ArchiveWorkspaceRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).archive_workspace_request_without_preload_content_with_http_info(archive_workspace_request = archive_workspace_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def create_workspace_request(
        create_workspace_request: Optional[CreateWorkspaceRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CreateWorkspaceResponse]:

        """Create a new workspace

        API to create a new workspace in the account. This endpoint allows users to set up a new workspace with the specified configuration.

        :param create_workspace_request:
        :type create_workspace_request: CreateWorkspaceRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).create_workspace_request_with_http_info(create_workspace_request = create_workspace_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def create_workspace_request_with_http_info(
        create_workspace_request: Optional[CreateWorkspaceRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CreateWorkspaceResponse]:

        """Create a new workspace

        API to create a new workspace in the account. This endpoint allows users to set up a new workspace with the specified configuration.

        :param create_workspace_request:
        :type create_workspace_request: CreateWorkspaceRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return WorkspaceManagementApi(api_client).create_workspace_request_with_http_info(create_workspace_request = create_workspace_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def create_workspace_request_without_preload_content(
        create_workspace_request: Optional[CreateWorkspaceRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Create a new workspace

        API to create a new workspace in the account. This endpoint allows users to set up a new workspace with the specified configuration.

        :param create_workspace_request:
        :type create_workspace_request: CreateWorkspaceRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).create_workspace_request_without_preload_content_with_http_info(create_workspace_request = create_workspace_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def search_workspaces_request(
        q: Annotated[str, Field(min_length=3, strict=True, max_length=2000, description="This endpoint retrieves workspaces according to keyword expressions you provide. Field names in expressions match `WorkspaceSearchQueryObject` (for example `workspaceId` refers to the workspace identifier in stored records). <br> Keyword expressions are constructed according to the rules described below. <br><br> This API supports multiple use cases:   - Search for multiple keywords.   - Search within particular attributes.   - Relational search using terms and connectors.   - And much more. ----  ## Allowed Connectors in Keyword Expressions | Connector | Description  | Example | | ------| ------|------| | **AND** |Find workspaces containing each of the terms joined by AND connectors.|**research AND legal**| | **OR**  |Find workspaces containing any of the terms joined by OR connectors.|**research OR development**| | **NOT** |Find workspaces that do not contain the specified term.|**research AND NOT personal**.  Find workspaces with the word \"research\" and not \"personal\".| | **\"[phrase]\"** |Find the exact phrase placed between the quotation marks.|**\"legal research\"**| | **( … )** |Specifies the order in which connectors are to be applied in a keyword expression.| **legal AND (research OR analysis)** - Find workspaces with the word legal research or legal analysis.|  <br><br> ## Fields and Connectors Searching | Field | Description  | Example | | ------| ------|------| |**workspaceId** |Find workspaces with the specified workspace ID.| **workspaceId:\"wk5381\"** - Find workspaces whose ID matches the given value.| |**workspaceName** |Find workspaces with the specified name.| **workspaceName:\"Legal Research Workspace\"** - Find workspaces whose name matches given terms.| |**description**|Find workspaces with the specified description.|**description:\"case analysis\"** - Find workspaces with description containing \"case analysis\".| |**workspaceTemplateId**|Find workspaces using the specified template.|**workspaceTemplateId:\"WTID729f18BZQX7Lm9\"** - Find workspaces using the specified template.| |**createdDate** | Find workspaces that were created on the specified date or within the specified date range. | **createdDate:[2025-03-15T00:00:00 TO 2025-12-01T00:00:00]** - Find workspaces created between March 15, 2025 and December 1, 2025 (inclusive). | |**WorkspaceTemplate**|Find workspaces using templates with specific properties.|**(WorkspaceTemplate:(workspaceTemplateName:\"Research Template\"))** - Find workspaces using templates with name \"Research Template\".| |**workspaceTemplateFields**|Find workspaces with specific template field configurations.|**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldName:\"Research Topic\")))** - Find workspaces with template fields named \"Research Topic\".| |**workspaceTemplateFieldValues**|Find workspaces with specific custom field values.|**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldValues:(workspaceTemplateFieldValue:\"Constitutional Law\"))))** - Find workspaces with custom field value \"Constitutional Law\".|  <br><br> --- ## Workspace Template Sub Filter Examples |Example |Explanation | |---|---| |**(WorkspaceTemplate:(workspaceTemplateName:\"Research Template\" AND (workspaceTemplateFields:(workspaceTemplateFieldName:\"Research Topic\"))))**|Find workspaces using \"Research Template\" that have a field named \"Research Topic\".| |**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldValues:(workspaceTemplateFieldValue:\"Legal Analysis\"))))**|Find workspaces with custom field values containing \"Legal Analysis\".|  --- All query parameters supported for this API can be found in below schema section. Schema --> SdkResponse[ WorkspaceSearchQueryObject ")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[WorkspaceSearchResponse]:

        """Search for workspaces with advanced filters

        API to search for workspaces in the account based on various filter criteria. Allows filtering by workspace name, status, creation date, and other attributes to find specific workspaces.

        :param q: This endpoint retrieves workspaces according to keyword expressions you provide. Field names in expressions match `WorkspaceSearchQueryObject` (for example `workspaceId` refers to the workspace identifier in stored records). <br> Keyword expressions are constructed according to the rules described below. <br><br> This API supports multiple use cases:   - Search for multiple keywords.   - Search within particular attributes.   - Relational search using terms and connectors.   - And much more. ----  ## Allowed Connectors in Keyword Expressions | Connector | Description  | Example | | ------| ------|------| | **AND** |Find workspaces containing each of the terms joined by AND connectors.|**research AND legal**| | **OR**  |Find workspaces containing any of the terms joined by OR connectors.|**research OR development**| | **NOT** |Find workspaces that do not contain the specified term.|**research AND NOT personal**.  Find workspaces with the word \"research\" and not \"personal\".| | **\"[phrase]\"** |Find the exact phrase placed between the quotation marks.|**\"legal research\"**| | **( … )** |Specifies the order in which connectors are to be applied in a keyword expression.| **legal AND (research OR analysis)** - Find workspaces with the word legal research or legal analysis.|  <br><br> ## Fields and Connectors Searching | Field | Description  | Example | | ------| ------|------| |**workspaceId** |Find workspaces with the specified workspace ID.| **workspaceId:\"wk5381\"** - Find workspaces whose ID matches the given value.| |**workspaceName** |Find workspaces with the specified name.| **workspaceName:\"Legal Research Workspace\"** - Find workspaces whose name matches given terms.| |**description**|Find workspaces with the specified description.|**description:\"case analysis\"** - Find workspaces with description containing \"case analysis\".| |**workspaceTemplateId**|Find workspaces using the specified template.|**workspaceTemplateId:\"WTID729f18BZQX7Lm9\"** - Find workspaces using the specified template.| |**createdDate** | Find workspaces that were created on the specified date or within the specified date range. | **createdDate:[2025-03-15T00:00:00 TO 2025-12-01T00:00:00]** - Find workspaces created between March 15, 2025 and December 1, 2025 (inclusive). | |**WorkspaceTemplate**|Find workspaces using templates with specific properties.|**(WorkspaceTemplate:(workspaceTemplateName:\"Research Template\"))** - Find workspaces using templates with name \"Research Template\".| |**workspaceTemplateFields**|Find workspaces with specific template field configurations.|**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldName:\"Research Topic\")))** - Find workspaces with template fields named \"Research Topic\".| |**workspaceTemplateFieldValues**|Find workspaces with specific custom field values.|**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldValues:(workspaceTemplateFieldValue:\"Constitutional Law\"))))** - Find workspaces with custom field value \"Constitutional Law\".|  <br><br> --- ## Workspace Template Sub Filter Examples |Example |Explanation | |---|---| |**(WorkspaceTemplate:(workspaceTemplateName:\"Research Template\" AND (workspaceTemplateFields:(workspaceTemplateFieldName:\"Research Topic\"))))**|Find workspaces using \"Research Template\" that have a field named \"Research Topic\".| |**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldValues:(workspaceTemplateFieldValue:\"Legal Analysis\"))))**|Find workspaces with custom field values containing \"Legal Analysis\".|  --- All query parameters supported for this API can be found in below schema section. Schema -->  WorkspaceSearchQueryObject  (required)
        :type q: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).search_workspaces_request_with_http_info(q = q, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def search_workspaces_request_with_http_info(
        q: Annotated[str, Field(min_length=3, strict=True, max_length=2000, description="This endpoint retrieves workspaces according to keyword expressions you provide. Field names in expressions match `WorkspaceSearchQueryObject` (for example `workspaceId` refers to the workspace identifier in stored records). <br> Keyword expressions are constructed according to the rules described below. <br><br> This API supports multiple use cases:   - Search for multiple keywords.   - Search within particular attributes.   - Relational search using terms and connectors.   - And much more. ----  ## Allowed Connectors in Keyword Expressions | Connector | Description  | Example | | ------| ------|------| | **AND** |Find workspaces containing each of the terms joined by AND connectors.|**research AND legal**| | **OR**  |Find workspaces containing any of the terms joined by OR connectors.|**research OR development**| | **NOT** |Find workspaces that do not contain the specified term.|**research AND NOT personal**.  Find workspaces with the word \"research\" and not \"personal\".| | **\"[phrase]\"** |Find the exact phrase placed between the quotation marks.|**\"legal research\"**| | **( … )** |Specifies the order in which connectors are to be applied in a keyword expression.| **legal AND (research OR analysis)** - Find workspaces with the word legal research or legal analysis.|  <br><br> ## Fields and Connectors Searching | Field | Description  | Example | | ------| ------|------| |**workspaceId** |Find workspaces with the specified workspace ID.| **workspaceId:\"wk5381\"** - Find workspaces whose ID matches the given value.| |**workspaceName** |Find workspaces with the specified name.| **workspaceName:\"Legal Research Workspace\"** - Find workspaces whose name matches given terms.| |**description**|Find workspaces with the specified description.|**description:\"case analysis\"** - Find workspaces with description containing \"case analysis\".| |**workspaceTemplateId**|Find workspaces using the specified template.|**workspaceTemplateId:\"WTID729f18BZQX7Lm9\"** - Find workspaces using the specified template.| |**createdDate** | Find workspaces that were created on the specified date or within the specified date range. | **createdDate:[2025-03-15T00:00:00 TO 2025-12-01T00:00:00]** - Find workspaces created between March 15, 2025 and December 1, 2025 (inclusive). | |**WorkspaceTemplate**|Find workspaces using templates with specific properties.|**(WorkspaceTemplate:(workspaceTemplateName:\"Research Template\"))** - Find workspaces using templates with name \"Research Template\".| |**workspaceTemplateFields**|Find workspaces with specific template field configurations.|**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldName:\"Research Topic\")))** - Find workspaces with template fields named \"Research Topic\".| |**workspaceTemplateFieldValues**|Find workspaces with specific custom field values.|**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldValues:(workspaceTemplateFieldValue:\"Constitutional Law\"))))** - Find workspaces with custom field value \"Constitutional Law\".|  <br><br> --- ## Workspace Template Sub Filter Examples |Example |Explanation | |---|---| |**(WorkspaceTemplate:(workspaceTemplateName:\"Research Template\" AND (workspaceTemplateFields:(workspaceTemplateFieldName:\"Research Topic\"))))**|Find workspaces using \"Research Template\" that have a field named \"Research Topic\".| |**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldValues:(workspaceTemplateFieldValue:\"Legal Analysis\"))))**|Find workspaces with custom field values containing \"Legal Analysis\".|  --- All query parameters supported for this API can be found in below schema section. Schema -->  WorkspaceSearchQueryObject ")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[WorkspaceSearchResponse]:

        """Search for workspaces with advanced filters

        API to search for workspaces in the account based on various filter criteria. Allows filtering by workspace name, status, creation date, and other attributes to find specific workspaces.

        :param q: This endpoint retrieves workspaces according to keyword expressions you provide. Field names in expressions match `WorkspaceSearchQueryObject` (for example `workspaceId` refers to the workspace identifier in stored records). <br> Keyword expressions are constructed according to the rules described below. <br><br> This API supports multiple use cases:   - Search for multiple keywords.   - Search within particular attributes.   - Relational search using terms and connectors.   - And much more. ----  ## Allowed Connectors in Keyword Expressions | Connector | Description  | Example | | ------| ------|------| | **AND** |Find workspaces containing each of the terms joined by AND connectors.|**research AND legal**| | **OR**  |Find workspaces containing any of the terms joined by OR connectors.|**research OR development**| | **NOT** |Find workspaces that do not contain the specified term.|**research AND NOT personal**.  Find workspaces with the word \"research\" and not \"personal\".| | **\"[phrase]\"** |Find the exact phrase placed between the quotation marks.|**\"legal research\"**| | **( … )** |Specifies the order in which connectors are to be applied in a keyword expression.| **legal AND (research OR analysis)** - Find workspaces with the word legal research or legal analysis.|  <br><br> ## Fields and Connectors Searching | Field | Description  | Example | | ------| ------|------| |**workspaceId** |Find workspaces with the specified workspace ID.| **workspaceId:\"wk5381\"** - Find workspaces whose ID matches the given value.| |**workspaceName** |Find workspaces with the specified name.| **workspaceName:\"Legal Research Workspace\"** - Find workspaces whose name matches given terms.| |**description**|Find workspaces with the specified description.|**description:\"case analysis\"** - Find workspaces with description containing \"case analysis\".| |**workspaceTemplateId**|Find workspaces using the specified template.|**workspaceTemplateId:\"WTID729f18BZQX7Lm9\"** - Find workspaces using the specified template.| |**createdDate** | Find workspaces that were created on the specified date or within the specified date range. | **createdDate:[2025-03-15T00:00:00 TO 2025-12-01T00:00:00]** - Find workspaces created between March 15, 2025 and December 1, 2025 (inclusive). | |**WorkspaceTemplate**|Find workspaces using templates with specific properties.|**(WorkspaceTemplate:(workspaceTemplateName:\"Research Template\"))** - Find workspaces using templates with name \"Research Template\".| |**workspaceTemplateFields**|Find workspaces with specific template field configurations.|**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldName:\"Research Topic\")))** - Find workspaces with template fields named \"Research Topic\".| |**workspaceTemplateFieldValues**|Find workspaces with specific custom field values.|**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldValues:(workspaceTemplateFieldValue:\"Constitutional Law\"))))** - Find workspaces with custom field value \"Constitutional Law\".|  <br><br> --- ## Workspace Template Sub Filter Examples |Example |Explanation | |---|---| |**(WorkspaceTemplate:(workspaceTemplateName:\"Research Template\" AND (workspaceTemplateFields:(workspaceTemplateFieldName:\"Research Topic\"))))**|Find workspaces using \"Research Template\" that have a field named \"Research Topic\".| |**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldValues:(workspaceTemplateFieldValue:\"Legal Analysis\"))))**|Find workspaces with custom field values containing \"Legal Analysis\".|  --- All query parameters supported for this API can be found in below schema section. Schema -->  WorkspaceSearchQueryObject  (required)
        :type q: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return WorkspaceManagementApi(api_client).search_workspaces_request_with_http_info(q = q, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def search_workspaces_request_without_preload_content(
        q: Annotated[str, Field(min_length=3, strict=True, max_length=2000, description="This endpoint retrieves workspaces according to keyword expressions you provide. Field names in expressions match `WorkspaceSearchQueryObject` (for example `workspaceId` refers to the workspace identifier in stored records). <br> Keyword expressions are constructed according to the rules described below. <br><br> This API supports multiple use cases:   - Search for multiple keywords.   - Search within particular attributes.   - Relational search using terms and connectors.   - And much more. ----  ## Allowed Connectors in Keyword Expressions | Connector | Description  | Example | | ------| ------|------| | **AND** |Find workspaces containing each of the terms joined by AND connectors.|**research AND legal**| | **OR**  |Find workspaces containing any of the terms joined by OR connectors.|**research OR development**| | **NOT** |Find workspaces that do not contain the specified term.|**research AND NOT personal**.  Find workspaces with the word \"research\" and not \"personal\".| | **\"[phrase]\"** |Find the exact phrase placed between the quotation marks.|**\"legal research\"**| | **( … )** |Specifies the order in which connectors are to be applied in a keyword expression.| **legal AND (research OR analysis)** - Find workspaces with the word legal research or legal analysis.|  <br><br> ## Fields and Connectors Searching | Field | Description  | Example | | ------| ------|------| |**workspaceId** |Find workspaces with the specified workspace ID.| **workspaceId:\"wk5381\"** - Find workspaces whose ID matches the given value.| |**workspaceName** |Find workspaces with the specified name.| **workspaceName:\"Legal Research Workspace\"** - Find workspaces whose name matches given terms.| |**description**|Find workspaces with the specified description.|**description:\"case analysis\"** - Find workspaces with description containing \"case analysis\".| |**workspaceTemplateId**|Find workspaces using the specified template.|**workspaceTemplateId:\"WTID729f18BZQX7Lm9\"** - Find workspaces using the specified template.| |**createdDate** | Find workspaces that were created on the specified date or within the specified date range. | **createdDate:[2025-03-15T00:00:00 TO 2025-12-01T00:00:00]** - Find workspaces created between March 15, 2025 and December 1, 2025 (inclusive). | |**WorkspaceTemplate**|Find workspaces using templates with specific properties.|**(WorkspaceTemplate:(workspaceTemplateName:\"Research Template\"))** - Find workspaces using templates with name \"Research Template\".| |**workspaceTemplateFields**|Find workspaces with specific template field configurations.|**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldName:\"Research Topic\")))** - Find workspaces with template fields named \"Research Topic\".| |**workspaceTemplateFieldValues**|Find workspaces with specific custom field values.|**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldValues:(workspaceTemplateFieldValue:\"Constitutional Law\"))))** - Find workspaces with custom field value \"Constitutional Law\".|  <br><br> --- ## Workspace Template Sub Filter Examples |Example |Explanation | |---|---| |**(WorkspaceTemplate:(workspaceTemplateName:\"Research Template\" AND (workspaceTemplateFields:(workspaceTemplateFieldName:\"Research Topic\"))))**|Find workspaces using \"Research Template\" that have a field named \"Research Topic\".| |**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldValues:(workspaceTemplateFieldValue:\"Legal Analysis\"))))**|Find workspaces with custom field values containing \"Legal Analysis\".|  --- All query parameters supported for this API can be found in below schema section. Schema --> SdkResponse[ WorkspaceSearchQueryObject ")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Search for workspaces with advanced filters

        API to search for workspaces in the account based on various filter criteria. Allows filtering by workspace name, status, creation date, and other attributes to find specific workspaces.

        :param q: This endpoint retrieves workspaces according to keyword expressions you provide. Field names in expressions match `WorkspaceSearchQueryObject` (for example `workspaceId` refers to the workspace identifier in stored records). <br> Keyword expressions are constructed according to the rules described below. <br><br> This API supports multiple use cases:   - Search for multiple keywords.   - Search within particular attributes.   - Relational search using terms and connectors.   - And much more. ----  ## Allowed Connectors in Keyword Expressions | Connector | Description  | Example | | ------| ------|------| | **AND** |Find workspaces containing each of the terms joined by AND connectors.|**research AND legal**| | **OR**  |Find workspaces containing any of the terms joined by OR connectors.|**research OR development**| | **NOT** |Find workspaces that do not contain the specified term.|**research AND NOT personal**.  Find workspaces with the word \"research\" and not \"personal\".| | **\"[phrase]\"** |Find the exact phrase placed between the quotation marks.|**\"legal research\"**| | **( … )** |Specifies the order in which connectors are to be applied in a keyword expression.| **legal AND (research OR analysis)** - Find workspaces with the word legal research or legal analysis.|  <br><br> ## Fields and Connectors Searching | Field | Description  | Example | | ------| ------|------| |**workspaceId** |Find workspaces with the specified workspace ID.| **workspaceId:\"wk5381\"** - Find workspaces whose ID matches the given value.| |**workspaceName** |Find workspaces with the specified name.| **workspaceName:\"Legal Research Workspace\"** - Find workspaces whose name matches given terms.| |**description**|Find workspaces with the specified description.|**description:\"case analysis\"** - Find workspaces with description containing \"case analysis\".| |**workspaceTemplateId**|Find workspaces using the specified template.|**workspaceTemplateId:\"WTID729f18BZQX7Lm9\"** - Find workspaces using the specified template.| |**createdDate** | Find workspaces that were created on the specified date or within the specified date range. | **createdDate:[2025-03-15T00:00:00 TO 2025-12-01T00:00:00]** - Find workspaces created between March 15, 2025 and December 1, 2025 (inclusive). | |**WorkspaceTemplate**|Find workspaces using templates with specific properties.|**(WorkspaceTemplate:(workspaceTemplateName:\"Research Template\"))** - Find workspaces using templates with name \"Research Template\".| |**workspaceTemplateFields**|Find workspaces with specific template field configurations.|**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldName:\"Research Topic\")))** - Find workspaces with template fields named \"Research Topic\".| |**workspaceTemplateFieldValues**|Find workspaces with specific custom field values.|**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldValues:(workspaceTemplateFieldValue:\"Constitutional Law\"))))** - Find workspaces with custom field value \"Constitutional Law\".|  <br><br> --- ## Workspace Template Sub Filter Examples |Example |Explanation | |---|---| |**(WorkspaceTemplate:(workspaceTemplateName:\"Research Template\" AND (workspaceTemplateFields:(workspaceTemplateFieldName:\"Research Topic\"))))**|Find workspaces using \"Research Template\" that have a field named \"Research Topic\".| |**(WorkspaceTemplate:(workspaceTemplateFields:(workspaceTemplateFieldValues:(workspaceTemplateFieldValue:\"Legal Analysis\"))))**|Find workspaces with custom field values containing \"Legal Analysis\".|  --- All query parameters supported for this API can be found in below schema section. Schema -->  WorkspaceSearchQueryObject  (required)
        :type q: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).search_workspaces_request_without_preload_content_with_http_info(q = q, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def update_workspace_request(
        update_workspace_request: Optional[UpdateWorkspaceRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[UpdateWorkspaceResponse]:

        """Update an existing workspace

        API to update an existing workspace's configuration and metadata. Allows modification of workspace settings, name, description, and other editable properties.

        :param update_workspace_request:
        :type update_workspace_request: UpdateWorkspaceRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).update_workspace_request_with_http_info(update_workspace_request = update_workspace_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def update_workspace_request_with_http_info(
        update_workspace_request: Optional[UpdateWorkspaceRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[UpdateWorkspaceResponse]:

        """Update an existing workspace

        API to update an existing workspace's configuration and metadata. Allows modification of workspace settings, name, description, and other editable properties.

        :param update_workspace_request:
        :type update_workspace_request: UpdateWorkspaceRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return WorkspaceManagementApi(api_client).update_workspace_request_with_http_info(update_workspace_request = update_workspace_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def update_workspace_request_without_preload_content(
        update_workspace_request: Optional[UpdateWorkspaceRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Update an existing workspace

        API to update an existing workspace's configuration and metadata. Allows modification of workspace settings, name, description, and other editable properties.

        :param update_workspace_request:
        :type update_workspace_request: UpdateWorkspaceRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).update_workspace_request_without_preload_content_with_http_info(update_workspace_request = update_workspace_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def workspace_detail_list_request(
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="Page number for pagination")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[WorkspaceDetailsResponse]:

        """Get list of workspaces

        API to retrieve a list of all workspaces associated with the account. Returns basic workspace information and metadata for each workspace.

        :param page_number: Page number for pagination
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).workspace_detail_list_request_with_http_info(page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def workspace_detail_list_request_with_http_info(
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="Page number for pagination")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[WorkspaceDetailsResponse]:

        """Get list of workspaces

        API to retrieve a list of all workspaces associated with the account. Returns basic workspace information and metadata for each workspace.

        :param page_number: Page number for pagination
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return WorkspaceManagementApi(api_client).workspace_detail_list_request_with_http_info(page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def workspace_detail_list_request_without_preload_content(
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="Page number for pagination")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get list of workspaces

        API to retrieve a list of all workspaces associated with the account. Returns basic workspace information and metadata for each workspace.

        :param page_number: Page number for pagination
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).workspace_detail_list_request_without_preload_content_with_http_info(page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def workspace_detail_request(
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[Workspace]:

        """Get details of a specific workspace

        API to retrieve detailed information about a specific workspace. Returns comprehensive workspace data including workspace name, description and the template field values if present.
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).workspace_detail_request_with_http_info(workspace_id = unicourt.WORKSPACE_ID, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def workspace_detail_request_with_http_info(
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[Workspace]:

        """Get details of a specific workspace

        API to retrieve detailed information about a specific workspace. Returns comprehensive workspace data including workspace name, description and the template field values if present.
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return WorkspaceManagementApi(api_client).workspace_detail_request_with_http_info(workspace_id = unicourt.WORKSPACE_ID, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def workspace_detail_request_without_preload_content(
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get details of a specific workspace

        API to retrieve detailed information about a specific workspace. Returns comprehensive workspace data including workspace name, description and the template field values if present.
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).workspace_detail_request_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def workspace_template_detail_request(
        workspace_template_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The unique identifier for the workspace template")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[WorkspaceTemplate]:

        """Get details of a specific workspace template

        API to retrieve detailed information about a specific workspace template. Returns information such as template name, description, and the fields available in the template.

        :param workspace_template_id: The unique identifier for the workspace template (required)
        :type workspace_template_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).workspace_template_detail_request_with_http_info(workspace_template_id = workspace_template_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def workspace_template_detail_request_with_http_info(
        workspace_template_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The unique identifier for the workspace template")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[WorkspaceTemplate]:

        """Get details of a specific workspace template

        API to retrieve detailed information about a specific workspace template. Returns information such as template name, description, and the fields available in the template.

        :param workspace_template_id: The unique identifier for the workspace template (required)
        :type workspace_template_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return WorkspaceManagementApi(api_client).workspace_template_detail_request_with_http_info(workspace_template_id = workspace_template_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def workspace_template_detail_request_without_preload_content(
        workspace_template_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The unique identifier for the workspace template")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get details of a specific workspace template

        API to retrieve detailed information about a specific workspace template. Returns information such as template name, description, and the fields available in the template.

        :param workspace_template_id: The unique identifier for the workspace template (required)
        :type workspace_template_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).workspace_template_detail_request_without_preload_content_with_http_info(workspace_template_id = workspace_template_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def workspace_templates_request(
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="Page number for pagination")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[WorkspaceTemplatesResponse]:

        """Get list of workspace templates

        API to retrieve a list of all available workspace templates. Returns template information that can be used to create new workspaces with predefined configurations.

        :param page_number: Page number for pagination
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).workspace_templates_request_with_http_info(page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def workspace_templates_request_with_http_info(
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="Page number for pagination")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[WorkspaceTemplatesResponse]:

        """Get list of workspace templates

        API to retrieve a list of all available workspace templates. Returns template information that can be used to create new workspaces with predefined configurations.

        :param page_number: Page number for pagination
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return WorkspaceManagementApi(api_client).workspace_templates_request_with_http_info(page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def workspace_templates_request_without_preload_content(
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="Page number for pagination")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get list of workspace templates

        API to retrieve a list of all available workspace templates. Returns template information that can be used to create new workspaces with predefined configurations.

        :param page_number: Page number for pagination
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceManagementApi(api_client).workspace_templates_request_without_preload_content_with_http_info(page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
