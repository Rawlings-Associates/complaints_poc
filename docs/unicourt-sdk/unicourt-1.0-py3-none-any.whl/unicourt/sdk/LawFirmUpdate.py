import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.norm_law_firm_update import NormLawFirmUpdate
from unicourt.model.norm_law_firm_update_request import NormLawFirmUpdateRequest
from unicourt.model.norm_law_firm_updates_response import NormLawFirmUpdatesResponse
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.law_firm_update_api import LawFirmUpdateApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class LawFirmUpdate:

    @staticmethod
    def get_norm_law_firm_update_by_norm_law_firm_id(
        norm_law_firm_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of law firm.      - minimum: 18     - maximum: 18 ")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormLawFirmUpdate]:

        """Get norm law firm updates for a requested norm law firm ID

        Retrieve norm law firm updates for the specified norm law firm object.
        :param norm_law_firm_id: Norm ID of law firm.      - minimum: 18     - maximum: 18  (required)
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmUpdateApi(api_client).get_norm_law_firm_update_by_norm_law_firm_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_norm_law_firm_update_by_norm_law_firm_id_with_http_info(
        norm_law_firm_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of law firm.      - minimum: 18     - maximum: 18 ")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormLawFirmUpdate]:

        """Get norm law firm updates for a requested norm law firm ID

        Retrieve norm law firm updates for the specified norm law firm object.
        :param norm_law_firm_id: Norm ID of law firm.      - minimum: 18     - maximum: 18  (required)
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return LawFirmUpdateApi(api_client).get_norm_law_firm_update_by_norm_law_firm_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_norm_law_firm_update_by_norm_law_firm_id_without_preload_content(
        norm_law_firm_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of law firm.      - minimum: 18     - maximum: 18 ")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get norm law firm updates for a requested norm law firm ID

        Retrieve norm law firm updates for the specified norm law firm object.
        :param norm_law_firm_id: Norm ID of law firm.      - minimum: 18     - maximum: 18  (required)
        :type norm_law_firm_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmUpdateApi(api_client).get_norm_law_firm_update_by_norm_law_firm_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_id = norm_law_firm_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_norm_law_firm_updates(
        norm_law_firm_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="The normLawFirmId for which updates should be retrieved.")] = None,
        last_n_days: Annotated[Optional[Annotated[int, Field(le=30, strict=True, ge=1)]], Field(description="Number of days to look back for Law Firm Update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a law firm was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of the norm law firm updates to be retrieved.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the desired page of results. - minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormLawFirmUpdatesResponse]:

        """Get the norm law firm list for the last N days.

        Retrieve law firm update requests that have been submitted within a specified time period. This endpoint returns a paginated list of law firm update statuses, allowing you to monitor the progress of your update requests. You can filter results by specific law firm ID, request status (IN_PROGRESS, COMPLETE, FAILURE), and time range (up to 30 days). Each response includes detailed status information, timestamps, and links to the associated law firm data. Use this endpoint to track bulk operations and ensure your law firm updates are proceeding as expected. 
        :param norm_law_firm_id: The normLawFirmId for which updates should be retrieved.
        :type norm_law_firm_id: str
        :param last_n_days: Number of days to look back for Law Firm Update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a law firm was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.
        :type last_n_days: int
        :param status: Status of the norm law firm updates to be retrieved.
        :type status: str
        :param page_number: The page number of the desired page of results. - minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmUpdateApi(api_client).get_norm_law_firm_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_id = norm_law_firm_id, last_n_days = last_n_days, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_norm_law_firm_updates_with_http_info(
        norm_law_firm_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="The normLawFirmId for which updates should be retrieved.")] = None,
        last_n_days: Annotated[Optional[Annotated[int, Field(le=30, strict=True, ge=1)]], Field(description="Number of days to look back for Law Firm Update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a law firm was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of the norm law firm updates to be retrieved.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the desired page of results. - minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormLawFirmUpdatesResponse]:

        """Get the norm law firm list for the last N days.

        Retrieve law firm update requests that have been submitted within a specified time period. This endpoint returns a paginated list of law firm update statuses, allowing you to monitor the progress of your update requests. You can filter results by specific law firm ID, request status (IN_PROGRESS, COMPLETE, FAILURE), and time range (up to 30 days). Each response includes detailed status information, timestamps, and links to the associated law firm data. Use this endpoint to track bulk operations and ensure your law firm updates are proceeding as expected. 
        :param norm_law_firm_id: The normLawFirmId for which updates should be retrieved.
        :type norm_law_firm_id: str
        :param last_n_days: Number of days to look back for Law Firm Update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a law firm was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.
        :type last_n_days: int
        :param status: Status of the norm law firm updates to be retrieved.
        :type status: str
        :param page_number: The page number of the desired page of results. - minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return LawFirmUpdateApi(api_client).get_norm_law_firm_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_id = norm_law_firm_id, last_n_days = last_n_days, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_norm_law_firm_updates_without_preload_content(
        norm_law_firm_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="The normLawFirmId for which updates should be retrieved.")] = None,
        last_n_days: Annotated[Optional[Annotated[int, Field(le=30, strict=True, ge=1)]], Field(description="Number of days to look back for Law Firm Update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a law firm was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of the norm law firm updates to be retrieved.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the desired page of results. - minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get the norm law firm list for the last N days.

        Retrieve law firm update requests that have been submitted within a specified time period. This endpoint returns a paginated list of law firm update statuses, allowing you to monitor the progress of your update requests. You can filter results by specific law firm ID, request status (IN_PROGRESS, COMPLETE, FAILURE), and time range (up to 30 days). Each response includes detailed status information, timestamps, and links to the associated law firm data. Use this endpoint to track bulk operations and ensure your law firm updates are proceeding as expected. 
        :param norm_law_firm_id: The normLawFirmId for which updates should be retrieved.
        :type norm_law_firm_id: str
        :param last_n_days: Number of days to look back for Law Firm Update requests. Returns requests that were submitted within the last N days, regardless of their current status. If a law firm was updated multiple times during this period, only the most recent status will be returned. Maximum value is 30 days, default is 1 day.
        :type last_n_days: int
        :param status: Status of the norm law firm updates to be retrieved.
        :type status: str
        :param page_number: The page number of the desired page of results. - minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmUpdateApi(api_client).get_norm_law_firm_updates_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_id = norm_law_firm_id, last_n_days = last_n_days, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def put_norm_law_firm_update(
        norm_law_firm_update_request: Annotated[Optional[NormLawFirmUpdateRequest], Field(description="The endpoint accepts law firm and state code as input.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormLawFirmUpdate]:

        """Add a law firm update for the requested norm law firm ID.

        Request Law Firm Update for the specified normLawFirmId. Once a request is made, the status will be marked as IN_PROGRESS. If the request is not completed within the expected timeframe or if there are any issues with the extraction process, it will be recorded as FAILURE.  Status Progression Based on Time Intervals:  - IN_PROGRESS: From the start of the request until the timeouts are reached. - FAILURE: If the request remains incomplete beyond the timeout period or if there are any issues with the extraction process.  **Note:** The `notifyOnDelay` feature is not currently supported. Even if `notifyOnDelay` is passed as `true`, the request will return a 400 Bad Request error. 
        :param norm_law_firm_update_request: The endpoint accepts law firm and state code as input.
        :type norm_law_firm_update_request: NormLawFirmUpdateRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmUpdateApi(api_client).put_norm_law_firm_update_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_update_request = norm_law_firm_update_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def put_norm_law_firm_update_with_http_info(
        norm_law_firm_update_request: Annotated[Optional[NormLawFirmUpdateRequest], Field(description="The endpoint accepts law firm and state code as input.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormLawFirmUpdate]:

        """Add a law firm update for the requested norm law firm ID.

        Request Law Firm Update for the specified normLawFirmId. Once a request is made, the status will be marked as IN_PROGRESS. If the request is not completed within the expected timeframe or if there are any issues with the extraction process, it will be recorded as FAILURE.  Status Progression Based on Time Intervals:  - IN_PROGRESS: From the start of the request until the timeouts are reached. - FAILURE: If the request remains incomplete beyond the timeout period or if there are any issues with the extraction process.  **Note:** The `notifyOnDelay` feature is not currently supported. Even if `notifyOnDelay` is passed as `true`, the request will return a 400 Bad Request error. 
        :param norm_law_firm_update_request: The endpoint accepts law firm and state code as input.
        :type norm_law_firm_update_request: NormLawFirmUpdateRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return LawFirmUpdateApi(api_client).put_norm_law_firm_update_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_update_request = norm_law_firm_update_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def put_norm_law_firm_update_without_preload_content(
        norm_law_firm_update_request: Annotated[Optional[NormLawFirmUpdateRequest], Field(description="The endpoint accepts law firm and state code as input.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Add a law firm update for the requested norm law firm ID.

        Request Law Firm Update for the specified normLawFirmId. Once a request is made, the status will be marked as IN_PROGRESS. If the request is not completed within the expected timeframe or if there are any issues with the extraction process, it will be recorded as FAILURE.  Status Progression Based on Time Intervals:  - IN_PROGRESS: From the start of the request until the timeouts are reached. - FAILURE: If the request remains incomplete beyond the timeout period or if there are any issues with the extraction process.  **Note:** The `notifyOnDelay` feature is not currently supported. Even if `notifyOnDelay` is passed as `true`, the request will return a 400 Bad Request error. 
        :param norm_law_firm_update_request: The endpoint accepts law firm and state code as input.
        :type norm_law_firm_update_request: NormLawFirmUpdateRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = LawFirmUpdateApi(api_client).put_norm_law_firm_update_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_law_firm_update_request = norm_law_firm_update_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
