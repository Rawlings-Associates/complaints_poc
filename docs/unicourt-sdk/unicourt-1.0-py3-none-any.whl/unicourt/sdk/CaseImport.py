import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from datetime import datetime
from pydantic import Field, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.case_import_callback import CaseImportCallback
from unicourt.model.case_import_callbacks_response import CaseImportCallbacksResponse
from unicourt.model.case_import_request import CaseImportRequest
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.case_import_api import CaseImportApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class CaseImport:

    @staticmethod
    def get_case_import_callback_by_id(
        case_import_callback_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Unique Id for the Case Import Callback.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseImportCallback]:

        """Get Case Import Callback for a requested Case Import Callback Id.

        Get Case Import Callback for a requested Case Import Callback Id.
        :param case_import_callback_id: Unique Id for the Case Import Callback. (required)
        :type case_import_callback_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseImportApi(api_client).get_case_import_callback_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_import_callback_id = case_import_callback_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_import_callback_by_id_with_http_info(
        case_import_callback_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Unique Id for the Case Import Callback.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseImportCallback]:

        """Get Case Import Callback for a requested Case Import Callback Id.

        Get Case Import Callback for a requested Case Import Callback Id.
        :param case_import_callback_id: Unique Id for the Case Import Callback. (required)
        :type case_import_callback_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseImportApi(api_client).get_case_import_callback_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_import_callback_id = case_import_callback_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_import_callback_by_id_without_preload_content(
        case_import_callback_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Unique Id for the Case Import Callback.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get Case Import Callback for a requested Case Import Callback Id.

        Get Case Import Callback for a requested Case Import Callback Id.
        :param case_import_callback_id: Unique Id for the Case Import Callback. (required)
        :type case_import_callback_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseImportApi(api_client).get_case_import_callback_by_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_import_callback_id = case_import_callback_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_import_callbacks(
        callback_generated_date: Annotated[Optional[datetime], Field(description="Timestamp of when the case was imported based on the callbackGeneratedDate, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current  date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests where callback was received from 05:00:00 to current date-time)")] = None,
        start_date: Annotated[Optional[datetime], Field(description="Timestamp of when the API was requested, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests from 05:00:00 to current date-time)")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of Case Import callbacks. Default status will fetch all callbacks.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="Page to fetch the Case Import Callbacks.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseImportCallbacksResponse]:

        """Get Case Import Callbacks for a requested Date.

        Get Case Import Callbacks for a requested Date.
        :param callback_generated_date: Timestamp of when the case was imported based on the callbackGeneratedDate, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current  date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests where callback was received from 05:00:00 to current date-time)
        :type callback_generated_date: datetime
        :param start_date: Timestamp of when the API was requested, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests from 05:00:00 to current date-time)
        :type start_date: datetime
        :param status: Status of Case Import callbacks. Default status will fetch all callbacks.
        :type status: str
        :param page_number: Page to fetch the Case Import Callbacks.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseImportApi(api_client).get_case_import_callbacks_with_http_info(workspace_id = unicourt.WORKSPACE_ID, callback_generated_date = callback_generated_date, start_date = start_date, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_import_callbacks_with_http_info(
        callback_generated_date: Annotated[Optional[datetime], Field(description="Timestamp of when the case was imported based on the callbackGeneratedDate, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current  date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests where callback was received from 05:00:00 to current date-time)")] = None,
        start_date: Annotated[Optional[datetime], Field(description="Timestamp of when the API was requested, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests from 05:00:00 to current date-time)")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of Case Import callbacks. Default status will fetch all callbacks.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="Page to fetch the Case Import Callbacks.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseImportCallbacksResponse]:

        """Get Case Import Callbacks for a requested Date.

        Get Case Import Callbacks for a requested Date.
        :param callback_generated_date: Timestamp of when the case was imported based on the callbackGeneratedDate, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current  date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests where callback was received from 05:00:00 to current date-time)
        :type callback_generated_date: datetime
        :param start_date: Timestamp of when the API was requested, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests from 05:00:00 to current date-time)
        :type start_date: datetime
        :param status: Status of Case Import callbacks. Default status will fetch all callbacks.
        :type status: str
        :param page_number: Page to fetch the Case Import Callbacks.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseImportApi(api_client).get_case_import_callbacks_with_http_info(workspace_id = unicourt.WORKSPACE_ID, callback_generated_date = callback_generated_date, start_date = start_date, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_import_callbacks_without_preload_content(
        callback_generated_date: Annotated[Optional[datetime], Field(description="Timestamp of when the case was imported based on the callbackGeneratedDate, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current  date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests where callback was received from 05:00:00 to current date-time)")] = None,
        start_date: Annotated[Optional[datetime], Field(description="Timestamp of when the API was requested, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests from 05:00:00 to current date-time)")] = None,
        status: Annotated[Optional[Annotated[str, Field(min_length=7, strict=True, max_length=11)]], Field(description="Status of Case Import callbacks. Default status will fetch all callbacks.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="Page to fetch the Case Import Callbacks.<br>   - Minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get Case Import Callbacks for a requested Date.

        Get Case Import Callbacks for a requested Date.
        :param callback_generated_date: Timestamp of when the case was imported based on the callbackGeneratedDate, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current  date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests where callback was received from 05:00:00 to current date-time)
        :type callback_generated_date: datetime
        :param start_date: Timestamp of when the API was requested, in YYYY-MM-DDTHH:MM:SS+ZZ:zz format. This date must be within the last 30 days; dates older than 30 days are not accepted. If null, defaults to current date 00:00 to current date-time. Fetches results from the specified time until the current time (e.g., 2025-10-01T05:00:00+00:00 will return all requests from 05:00:00 to current date-time)
        :type start_date: datetime
        :param status: Status of Case Import callbacks. Default status will fetch all callbacks.
        :type status: str
        :param page_number: Page to fetch the Case Import Callbacks.<br>   - Minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseImportApi(api_client).get_case_import_callbacks_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, callback_generated_date = callback_generated_date, start_date = start_date, status = status, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def import_case(
        case_import_request: Optional[CaseImportRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseImportCallback]:

        """Add Case Import for the requested Case Id.

        Request case import for the specified case.  **Status Progression:**  - **IN_PROGRESS**: The request is being processed, from the start until the defined timeout is reached. - **DELAYED**: An intermittent source or internal issue has slowed down the process. - **FAILURE**: The request could not be completed within the timeout period, or the process encountered an error due to source or internal issues. - **COMPLETE**: The process was successfully completed.  **Note:** If multiple cases are imported, the caseObject will not be included in the response. Instead, only the caseId and caseAPI fields will be returned for each imported case. You can use the caseAPI link to fetch the complete case object as needed.  
        :param case_import_request:
        :type case_import_request: CaseImportRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseImportApi(api_client).import_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_import_request = case_import_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def import_case_with_http_info(
        case_import_request: Optional[CaseImportRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseImportCallback]:

        """Add Case Import for the requested Case Id.

        Request case import for the specified case.  **Status Progression:**  - **IN_PROGRESS**: The request is being processed, from the start until the defined timeout is reached. - **DELAYED**: An intermittent source or internal issue has slowed down the process. - **FAILURE**: The request could not be completed within the timeout period, or the process encountered an error due to source or internal issues. - **COMPLETE**: The process was successfully completed.  **Note:** If multiple cases are imported, the caseObject will not be included in the response. Instead, only the caseId and caseAPI fields will be returned for each imported case. You can use the caseAPI link to fetch the complete case object as needed.  
        :param case_import_request:
        :type case_import_request: CaseImportRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseImportApi(api_client).import_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_import_request = case_import_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def import_case_without_preload_content(
        case_import_request: Optional[CaseImportRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Add Case Import for the requested Case Id.

        Request case import for the specified case.  **Status Progression:**  - **IN_PROGRESS**: The request is being processed, from the start until the defined timeout is reached. - **DELAYED**: An intermittent source or internal issue has slowed down the process. - **FAILURE**: The request could not be completed within the timeout period, or the process encountered an error due to source or internal issues. - **COMPLETE**: The process was successfully completed.  **Note:** If multiple cases are imported, the caseObject will not be included in the response. Instead, only the caseId and caseAPI fields will be returned for each imported case. You can use the caseAPI link to fetch the complete case object as needed.  
        :param case_import_request:
        :type case_import_request: CaseImportRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseImportApi(api_client).import_case_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_import_request = case_import_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
