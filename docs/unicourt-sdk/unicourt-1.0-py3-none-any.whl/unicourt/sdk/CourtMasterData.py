import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field, StrictStr, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.court import Court
from unicourt.model.court_location import CourtLocation
from unicourt.model.court_location_response import CourtLocationResponse
from unicourt.model.court_response import CourtResponse
from unicourt.model.court_source import CourtSource
from unicourt.model.court_source_response import CourtSourceResponse
from unicourt.model.court_system import CourtSystem
from unicourt.model.court_system_response import CourtSystemResponse
from unicourt.model.court_type import CourtType
from unicourt.model.court_type_response import CourtTypeResponse
from unicourt.model.jurisdiction_geo import JurisdictionGeo
from unicourt.model.jurisdiction_geo_response import JurisdictionGeoResponse
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.court_master_data_api import CourtMasterDataApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class CourtMasterData:

    @staticmethod
    def get_appeal_courts_for_court(
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the target court.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtResponse]:

        """Appeal Courts for the provided courtId.

        Fetch the appeal courts for the given courtId. 
        :param court_id: The courtId value of the target court. (required)
        :type court_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_appeal_courts_for_court_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_id = court_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_appeal_courts_for_court_with_http_info(
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the target court.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtResponse]:

        """Appeal Courts for the provided courtId.

        Fetch the appeal courts for the given courtId. 
        :param court_id: The courtId value of the target court. (required)
        :type court_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_appeal_courts_for_court_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_id = court_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_appeal_courts_for_court_without_preload_content(
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the target court.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Appeal Courts for the provided courtId.

        Fetch the appeal courts for the given courtId. 
        :param court_id: The courtId value of the target court. (required)
        :type court_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_appeal_courts_for_court_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_id = court_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court(
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the target court.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[Court]:

        """Court details for the provided courtId.

        Fetch the details of the specific court. 
        :param court_id: The courtId value of the target court. (required)
        :type court_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_id = court_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_with_http_info(
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the target court.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[Court]:

        """Court details for the provided courtId.

        Fetch the details of the specific court. 
        :param court_id: The courtId value of the target court. (required)
        :type court_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_court_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_id = court_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_court_without_preload_content(
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the target court.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Court details for the provided courtId.

        Fetch the details of the specific court. 
        :param court_id: The courtId value of the target court. (required)
        :type court_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_id = court_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_location(
        court_location_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="courtLocationId")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtLocation]:

        """Court Location details for the provided courtLocationId.

        Fetch the details of the specific court location. 
        :param court_location_id: courtLocationId (required)
        :type court_location_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_location_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_location_id = court_location_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_location_with_http_info(
        court_location_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="courtLocationId")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtLocation]:

        """Court Location details for the provided courtLocationId.

        Fetch the details of the specific court location. 
        :param court_location_id: courtLocationId (required)
        :type court_location_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_court_location_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_location_id = court_location_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_court_location_without_preload_content(
        court_location_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="courtLocationId")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Court Location details for the provided courtLocationId.

        Fetch the details of the specific court location. 
        :param court_location_id: courtLocationId (required)
        :type court_location_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_location_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_location_id = court_location_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_locations(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtLocationQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtLocationResponse]:

        """CourtLocation Object.

        Fetch the list of court locations supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.** <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Charlotte County Courthouse) AND courtLocationId:COLO9g3fhYM4bmxveA** | | **OR** | Returns results matching any specified condition. | **name:(Charlotte County Courthouse) OR name:(Dade County Court Facility)** | | **NOT** | Excludes results matching the specified condition. | **name:(Charlotte County Courthouse) NOT name:(Dade County Court)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Charlotte County Courthouse\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Charlotte County Courthouse\" OR name:\"Dade County Court\") AND courtLocationId:\"COLO9g3fhYM4bmxveA\"** |  <br>  ## Supported Filter Fields ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtLocationQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtLocationQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_locations_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_locations_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtLocationQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtLocationResponse]:

        """CourtLocation Object.

        Fetch the list of court locations supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.** <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Charlotte County Courthouse) AND courtLocationId:COLO9g3fhYM4bmxveA** | | **OR** | Returns results matching any specified condition. | **name:(Charlotte County Courthouse) OR name:(Dade County Court Facility)** | | **NOT** | Excludes results matching the specified condition. | **name:(Charlotte County Courthouse) NOT name:(Dade County Court)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Charlotte County Courthouse\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Charlotte County Courthouse\" OR name:\"Dade County Court\") AND courtLocationId:\"COLO9g3fhYM4bmxveA\"** |  <br>  ## Supported Filter Fields ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtLocationQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtLocationQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_court_locations_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_court_locations_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtLocationQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """CourtLocation Object.

        Fetch the list of court locations supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.** <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Charlotte County Courthouse) AND courtLocationId:COLO9g3fhYM4bmxveA** | | **OR** | Returns results matching any specified condition. | **name:(Charlotte County Courthouse) OR name:(Dade County Court Facility)** | | **NOT** | Excludes results matching the specified condition. | **name:(Charlotte County Courthouse) NOT name:(Dade County Court)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Charlotte County Courthouse\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Charlotte County Courthouse\" OR name:\"Dade County Court\") AND courtLocationId:\"COLO9g3fhYM4bmxveA\"** |  <br>  ## Supported Filter Fields ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtLocationQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtLocationQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_locations_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_locations_for_court(
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the target court.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtLocationResponse]:

        """Associated Court Location for the provided courtId.

        Retrieve the list of court locations associated with the specified court. 
        :param court_id: The courtId value of the target court. (required)
        :type court_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_locations_for_court_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_id = court_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_locations_for_court_with_http_info(
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the target court.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtLocationResponse]:

        """Associated Court Location for the provided courtId.

        Retrieve the list of court locations associated with the specified court. 
        :param court_id: The courtId value of the target court. (required)
        :type court_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_court_locations_for_court_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_id = court_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_court_locations_for_court_without_preload_content(
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the target court.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Associated Court Location for the provided courtId.

        Retrieve the list of court locations associated with the specified court. 
        :param court_id: The courtId value of the target court. (required)
        :type court_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_locations_for_court_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_id = court_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_source(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSourceQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtSourceResponse]:

        """Court Source Objects

        Fetch the list of court sources supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Charlotte County Court) AND courtId:\"CORThSxcef8eGUSkuC\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Charlotte County Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Charlotte County Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Charlotte County Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Charlotte County Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORThSxcef8eGUSkuC\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtSourceQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSourceQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_source_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_source_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSourceQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtSourceResponse]:

        """Court Source Objects

        Fetch the list of court sources supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Charlotte County Court) AND courtId:\"CORThSxcef8eGUSkuC\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Charlotte County Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Charlotte County Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Charlotte County Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Charlotte County Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORThSxcef8eGUSkuC\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtSourceQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSourceQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_court_source_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_court_source_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSourceQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Court Source Objects

        Fetch the list of court sources supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **(Court:(name:(Charlotte County Court) AND courtId:\"CORThSxcef8eGUSkuC\"))** | | **OR** | Returns results matching any specified condition. | **(Court:(name:(Charlotte County Court))) OR (Court:(name:(Merced County Superior Court)))** | | **NOT** | Excludes results matching the specified condition. | **(Court:(name:(Charlotte County Court))) NOT (Court:(name:(Merced County Superior Court)))** | | **\"[phrase]\"** | Searches for an exact phrase match. | **(Court:(name:\"Charlotte County Court\"))** | | **( ... )** | Groups multiple conditions together. | **(Court:(name:(Charlotte County Court) OR system:(Florida County Courts))) AND (Court:(courtId:\"CORThSxcef8eGUSkuC\"))** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtSourceQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSourceQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_source_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_source_by_id(
        court_source_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtSourceId of the court source to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtSource]:

        """Court Source details for the provided courtSourceId.

        Fetch the details of the specific court source. 
        :param court_source_id: The courtSourceId of the court source to be retrieved. (required)
        :type court_source_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_source_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_source_id = court_source_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_source_by_id_with_http_info(
        court_source_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtSourceId of the court source to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtSource]:

        """Court Source details for the provided courtSourceId.

        Fetch the details of the specific court source. 
        :param court_source_id: The courtSourceId of the court source to be retrieved. (required)
        :type court_source_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_court_source_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_source_id = court_source_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_court_source_by_id_without_preload_content(
        court_source_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtSourceId of the court source to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Court Source details for the provided courtSourceId.

        Fetch the details of the specific court source. 
        :param court_source_id: The courtSourceId of the court source to be retrieved. (required)
        :type court_source_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_source_by_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_source_id = court_source_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_system(
        court_system_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtSystemId value of the court system to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtSystem]:

        """Court System details for the provided courtSystemId.

        Fetch the details of the specific court system. 
        :param court_system_id: The courtSystemId value of the court system to be retrieved. (required)
        :type court_system_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_system_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_system_id = court_system_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_system_with_http_info(
        court_system_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtSystemId value of the court system to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtSystem]:

        """Court System details for the provided courtSystemId.

        Fetch the details of the specific court system. 
        :param court_system_id: The courtSystemId value of the court system to be retrieved. (required)
        :type court_system_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_court_system_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_system_id = court_system_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_court_system_without_preload_content(
        court_system_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtSystemId value of the court system to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Court System details for the provided courtSystemId.

        Fetch the details of the specific court system. 
        :param court_system_id: The courtSystemId value of the court system to be retrieved. (required)
        :type court_system_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_system_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_system_id = court_system_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_systems(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSystemQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtSystemResponse]:

        """Court System Objects.

        Fetch the list of court systems supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.** <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:California AND courtSystemId:COSYmiJJ6VFfuGDf2t** | | **OR** | Returns results matching any specified condition. | **name:California OR name:Florida** | | **NOT** | Excludes results matching the specified condition. | **name:California NOT name:Florida** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"California Courts of Appeal\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"California Courts of Appeal\" OR name:\"Florida Courts of Appeal\") AND courtSystemId:\"COSYmiJJ6VFfuGDf2t\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtSystemQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSystemQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_systems_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_systems_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSystemQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtSystemResponse]:

        """Court System Objects.

        Fetch the list of court systems supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.** <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:California AND courtSystemId:COSYmiJJ6VFfuGDf2t** | | **OR** | Returns results matching any specified condition. | **name:California OR name:Florida** | | **NOT** | Excludes results matching the specified condition. | **name:California NOT name:Florida** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"California Courts of Appeal\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"California Courts of Appeal\" OR name:\"Florida Courts of Appeal\") AND courtSystemId:\"COSYmiJJ6VFfuGDf2t\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtSystemQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSystemQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_court_systems_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_court_systems_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSystemQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Court System Objects.

        Fetch the list of court systems supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.** <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:California AND courtSystemId:COSYmiJJ6VFfuGDf2t** | | **OR** | Returns results matching any specified condition. | **name:California OR name:Florida** | | **NOT** | Excludes results matching the specified condition. | **name:California NOT name:Florida** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"California Courts of Appeal\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"California Courts of Appeal\" OR name:\"Florida Courts of Appeal\") AND courtSystemId:\"COSYmiJJ6VFfuGDf2t\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtSystemQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtSystemQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_systems_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_type(
        court_type_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtTypeId of the court type to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtType]:

        """Court Type details for the provided courtTypeId.

        Fetch the details of the specific court type. 
        :param court_type_id: The courtTypeId of the court type to be retrieved. (required)
        :type court_type_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_type_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_type_id = court_type_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_type_with_http_info(
        court_type_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtTypeId of the court type to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtType]:

        """Court Type details for the provided courtTypeId.

        Fetch the details of the specific court type. 
        :param court_type_id: The courtTypeId of the court type to be retrieved. (required)
        :type court_type_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_court_type_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_type_id = court_type_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_court_type_without_preload_content(
        court_type_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtTypeId of the court type to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Court Type details for the provided courtTypeId.

        Fetch the details of the specific court type. 
        :param court_type_id: The courtTypeId of the court type to be retrieved. (required)
        :type court_type_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_type_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_type_id = court_type_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_types(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtTypeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtTypeResponse]:

        """Court Type Objects.

        Fetch the list of court types supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:State AND courtTypeId:COTPm8jjc2PAydpFhq** | | **OR** | Returns results matching any specified condition. | **name:State OR name:Federal** | | **NOT** | Excludes results matching the specified condition. | **name:State NOT name:Probate** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"State\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"State\" OR name:\"Federal\") AND courtTypeId:\"COTPm8jjc2PAydpFhq\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtTypeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtTypeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_types_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_court_types_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtTypeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtTypeResponse]:

        """Court Type Objects.

        Fetch the list of court types supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:State AND courtTypeId:COTPm8jjc2PAydpFhq** | | **OR** | Returns results matching any specified condition. | **name:State OR name:Federal** | | **NOT** | Excludes results matching the specified condition. | **name:State NOT name:Probate** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"State\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"State\" OR name:\"Federal\") AND courtTypeId:\"COTPm8jjc2PAydpFhq\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtTypeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtTypeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_court_types_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_court_types_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtTypeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Court Type Objects.

        Fetch the list of court types supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:State AND courtTypeId:COTPm8jjc2PAydpFhq** | | **OR** | Returns results matching any specified condition. | **name:State OR name:Federal** | | **NOT** | Excludes results matching the specified condition. | **name:State NOT name:Probate** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"State\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"State\" OR name:\"Federal\") AND courtTypeId:\"COTPm8jjc2PAydpFhq\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtTypeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtTypeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_court_types_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_courts(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtResponse]:

        """Court Objects.

        Fetch the list of courts supported by UniCourt. <br><br> **Note: A maximum of 15 operators are allowed in a single query.** <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Charlotte County Court) AND courtId:CORThSxcef8eGUSkuC** | | **OR** | Returns results matching any specified condition. | **name:(Charlotte County Court) OR name:(Dade County Court)** | | **NOT** | Excludes results matching the specified condition. | **name:(Charlotte County Court) NOT name:(Dade County Court)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Charlotte County Court\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Charlotte County Court\" OR name:\"Dade County Court\") AND courtId:\"CORThSxcef8eGUSkuC\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_courts_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_courts_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtResponse]:

        """Court Objects.

        Fetch the list of courts supported by UniCourt. <br><br> **Note: A maximum of 15 operators are allowed in a single query.** <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Charlotte County Court) AND courtId:CORThSxcef8eGUSkuC** | | **OR** | Returns results matching any specified condition. | **name:(Charlotte County Court) OR name:(Dade County Court)** | | **NOT** | Excludes results matching the specified condition. | **name:(Charlotte County Court) NOT name:(Dade County Court)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Charlotte County Court\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Charlotte County Court\" OR name:\"Dade County Court\") AND courtId:\"CORThSxcef8eGUSkuC\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_courts_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_courts_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Court Objects.

        Fetch the list of courts supported by UniCourt. <br><br> **Note: A maximum of 15 operators are allowed in a single query.** <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Charlotte County Court) AND courtId:CORThSxcef8eGUSkuC** | | **OR** | Returns results matching any specified condition. | **name:(Charlotte County Court) OR name:(Dade County Court)** | | **NOT** | Excludes results matching the specified condition. | **name:(Charlotte County Court) NOT name:(Dade County Court)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Charlotte County Court\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Charlotte County Court\" OR name:\"Dade County Court\") AND courtId:\"CORThSxcef8eGUSkuC\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CourtQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CourtQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_courts_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_courts_for_court_location(
        court_location_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtLocationId value of the court location for which courts are to be retrieved.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtResponse]:

        """Associated Courts for provided Court Location.

        Fetch the courts associated with the specified court location. 
        :param court_location_id: The courtLocationId value of the court location for which courts are to be retrieved. (required)
        :type court_location_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_courts_for_court_location_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_location_id = court_location_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_courts_for_court_location_with_http_info(
        court_location_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtLocationId value of the court location for which courts are to be retrieved.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtResponse]:

        """Associated Courts for provided Court Location.

        Fetch the courts associated with the specified court location. 
        :param court_location_id: The courtLocationId value of the court location for which courts are to be retrieved. (required)
        :type court_location_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_courts_for_court_location_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_location_id = court_location_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_courts_for_court_location_without_preload_content(
        court_location_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtLocationId value of the court location for which courts are to be retrieved.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Associated Courts for provided Court Location.

        Fetch the courts associated with the specified court location. 
        :param court_location_id: The courtLocationId value of the court location for which courts are to be retrieved. (required)
        :type court_location_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_courts_for_court_location_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_location_id = court_location_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_courts_for_jurisdiction_geo(
        jurisdiction_geo_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="jurisdictionGeoId")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CourtResponse]:

        """Associated Court for given Jurisdiction Geo.

        Returns Associated Court for given Jurisdiction Geo. 
        :param jurisdiction_geo_id: jurisdictionGeoId (required)
        :type jurisdiction_geo_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_courts_for_jurisdiction_geo_with_http_info(workspace_id = unicourt.WORKSPACE_ID, jurisdiction_geo_id = jurisdiction_geo_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_courts_for_jurisdiction_geo_with_http_info(
        jurisdiction_geo_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="jurisdictionGeoId")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CourtResponse]:

        """Associated Court for given Jurisdiction Geo.

        Returns Associated Court for given Jurisdiction Geo. 
        :param jurisdiction_geo_id: jurisdictionGeoId (required)
        :type jurisdiction_geo_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_courts_for_jurisdiction_geo_with_http_info(workspace_id = unicourt.WORKSPACE_ID, jurisdiction_geo_id = jurisdiction_geo_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_courts_for_jurisdiction_geo_without_preload_content(
        jurisdiction_geo_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="jurisdictionGeoId")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Associated Court for given Jurisdiction Geo.

        Returns Associated Court for given Jurisdiction Geo. 
        :param jurisdiction_geo_id: jurisdictionGeoId (required)
        :type jurisdiction_geo_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_courts_for_jurisdiction_geo_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, jurisdiction_geo_id = jurisdiction_geo_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_jurisdiction_geo(
        jurisdiction_geo_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The jurisdictionGeoId value of the desired jurisdiction geography.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[JurisdictionGeo]:

        """Jurisdiction Geo details for the provided jurisdictionGeoId.

        Fetch the details of the specific jurisdiction geography. 
        :param jurisdiction_geo_id: The jurisdictionGeoId value of the desired jurisdiction geography. (required)
        :type jurisdiction_geo_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_jurisdiction_geo_with_http_info(workspace_id = unicourt.WORKSPACE_ID, jurisdiction_geo_id = jurisdiction_geo_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_jurisdiction_geo_with_http_info(
        jurisdiction_geo_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The jurisdictionGeoId value of the desired jurisdiction geography.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[JurisdictionGeo]:

        """Jurisdiction Geo details for the provided jurisdictionGeoId.

        Fetch the details of the specific jurisdiction geography. 
        :param jurisdiction_geo_id: The jurisdictionGeoId value of the desired jurisdiction geography. (required)
        :type jurisdiction_geo_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_jurisdiction_geo_with_http_info(workspace_id = unicourt.WORKSPACE_ID, jurisdiction_geo_id = jurisdiction_geo_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_jurisdiction_geo_without_preload_content(
        jurisdiction_geo_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The jurisdictionGeoId value of the desired jurisdiction geography.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Jurisdiction Geo details for the provided jurisdictionGeoId.

        Fetch the details of the specific jurisdiction geography. 
        :param jurisdiction_geo_id: The jurisdictionGeoId value of the desired jurisdiction geography. (required)
        :type jurisdiction_geo_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_jurisdiction_geo_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, jurisdiction_geo_id = jurisdiction_geo_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_jurisdiction_geo_for_court(
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the target court.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[StrictStr], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[JurisdictionGeoResponse]:

        """Jurisdiction Geo for the provided courtId.

        Fetch the jurisdiction geo object for the given courtId. 
        :param court_id: The courtId value of the target court. (required)
        :type court_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_jurisdiction_geo_for_court_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_id = court_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_jurisdiction_geo_for_court_with_http_info(
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the target court.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[StrictStr], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[JurisdictionGeoResponse]:

        """Jurisdiction Geo for the provided courtId.

        Fetch the jurisdiction geo object for the given courtId. 
        :param court_id: The courtId value of the target court. (required)
        :type court_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_jurisdiction_geo_for_court_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_id = court_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_jurisdiction_geo_for_court_without_preload_content(
        court_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The courtId value of the target court.")],
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[StrictStr], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Jurisdiction Geo for the provided courtId.

        Fetch the jurisdiction geo object for the given courtId. 
        :param court_id: The courtId value of the target court. (required)
        :type court_id: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_jurisdiction_geo_for_court_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, court_id = court_id, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_jurisdictions_geo(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `JurisdictionGeoQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[StrictStr], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[JurisdictionGeoResponse]:

        """Jurisdiction Geo Object.

        Fetch one or more jurisdiction geographies using a keyword expression. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.** <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** |Returns results matching all specified conditions.|**state:Florida AND jurisdictionGeoId:JUGO8s7HvM84dLvVMu**| | **OR**  |Returns results matching any specified condition.| **state:Florida OR state:California**| | **NOT** |Excludes results matching the specified condition.| **state:Florida NOT state:California**.| | **“[phrase]”** |Searches for an exact phrase match.| **state:\"Florida\"** | | **( … )** |Groups multiple conditions together.| **(state:Florida OR state:California) AND jurisdictionGeoId:JUGO8s7HvM84dLvVMu**|  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> JurisdictionGeoQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `JurisdictionGeoQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_jurisdictions_geo_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_jurisdictions_geo_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `JurisdictionGeoQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[StrictStr], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[JurisdictionGeoResponse]:

        """Jurisdiction Geo Object.

        Fetch one or more jurisdiction geographies using a keyword expression. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.** <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** |Returns results matching all specified conditions.|**state:Florida AND jurisdictionGeoId:JUGO8s7HvM84dLvVMu**| | **OR**  |Returns results matching any specified condition.| **state:Florida OR state:California**| | **NOT** |Excludes results matching the specified condition.| **state:Florida NOT state:California**.| | **“[phrase]”** |Searches for an exact phrase match.| **state:\"Florida\"** | | **( … )** |Groups multiple conditions together.| **(state:Florida OR state:California) AND jurisdictionGeoId:JUGO8s7HvM84dLvVMu**|  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> JurisdictionGeoQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `JurisdictionGeoQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CourtMasterDataApi(api_client).get_jurisdictions_geo_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_jurisdictions_geo_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `JurisdictionGeoQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[StrictStr], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Jurisdiction Geo Object.

        Fetch one or more jurisdiction geographies using a keyword expression. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.** <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** |Returns results matching all specified conditions.|**state:Florida AND jurisdictionGeoId:JUGO8s7HvM84dLvVMu**| | **OR**  |Returns results matching any specified condition.| **state:Florida OR state:California**| | **NOT** |Excludes results matching the specified condition.| **state:Florida NOT state:California**.| | **“[phrase]”** |Searches for an exact phrase match.| **state:\"Florida\"** | | **( … )** |Groups multiple conditions together.| **(state:Florida OR state:California) AND jurisdictionGeoId:JUGO8s7HvM84dLvVMu**|  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> JurisdictionGeoQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `JurisdictionGeoQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CourtMasterDataApi(api_client).get_jurisdictions_geo_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
