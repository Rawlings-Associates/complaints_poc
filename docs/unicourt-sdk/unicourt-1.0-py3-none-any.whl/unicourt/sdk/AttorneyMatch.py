import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field, field_validator
from typing import List, Optional
from typing_extensions import Annotated
from unicourt.model.norm_attorney_match_response import NormAttorneyMatchResponse
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.attorney_match_api import AttorneyMatchApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class AttorneyMatch:

    @staticmethod
    def get_norm_attorney_match(
        barred_state: Annotated[Optional[Annotated[str, Field(strict=True, max_length=5)]], Field(description="Barred State of the Attorney")] = None,
        full_name: Annotated[Optional[Annotated[str, Field(strict=True, max_length=250)]], Field(description="Attorney Full Name")] = None,
        first_name: Annotated[Optional[Annotated[str, Field(strict=True, max_length=250)]], Field(description="First Name of the Attorney")] = None,
        middle_name: Annotated[Optional[Annotated[str, Field(strict=True, max_length=250)]], Field(description="Middle Name of the Attorney")] = None,
        last_name: Annotated[Optional[Annotated[str, Field(strict=True, max_length=250)]], Field(description="Last Name of the Attorney")] = None,
        bar_number: Annotated[Optional[Annotated[str, Field(strict=True, max_length=50)]], Field(description="Bar Number of an Attorney")] = None,
        email_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Attorney Email Addresses")] = None,
        address_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Attorney Addresses")] = None,
        phone_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Attorney Phone Numbers")] = None,
        law_firm_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Attorney Firm Names")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormAttorneyMatchResponse]:

        """Norm Attorney Results for a given attorney name

        Returns an array of Norm Attorney object. <br> Either provide `fullName` or the combination of `firstName` and `lastName` (with `middleName` being optional).<br><br> This API supports multiple use cases:   - Search for an attorney name using fullname `MICHALE SCOTT HUNT`.   - Search an attorney within particular state.   - Search an attorney using the Bar Number.   - Filter the attorney search results with additional attributes - `emailList` or  `phoneList` or `addressList` or `lawFirmList`<br><br> ----- <br> ## Terms | Connector | Schema | Description  | Example | | ------| ------|------| ------| |**barredState** |Single Allowed | Indicates the state the attorney is barred.| **CA** | |**fullName** |Single Allowed | Full name of the attorney| **MICHAEL SCOTT HUNT** | |**firstName** |Single Allowed | First name of the attorney| **MICHAEL** | |**middleName** |Single Allowed | Middle name of the attorney| **SCOTT** | |**lastName** |Single Allowed | Last name of the attorney| **HUNT** | |**barNumber** |Single Allowed | Indicates the bar number of an attorney in a given state| **99804** | |**emailList** |Multiple Allowed | Indicates the email list for the attorney.| **[MSHUNT@HUNTHENRIQUES.COM]** | |**addressList** |Multiple Allowed | Indicates the address list for the attorney.| **[7017 REALM DR]** | |**phoneList** |Multiple Allowed | Indicates the phone list for the attorney.| **[408-362-2270]** | |**lawFirmList** |Multiple Allowed | Indicates the lawfirm list for the attorney.| **[HUNT & HENRIQUES LLP]** | 
        :param barred_state: Barred State of the Attorney
        :type barred_state: str
        :param full_name: Attorney Full Name
        :type full_name: str
        :param first_name: First Name of the Attorney
        :type first_name: str
        :param middle_name: Middle Name of the Attorney
        :type middle_name: str
        :param last_name: Last Name of the Attorney
        :type last_name: str
        :param bar_number: Bar Number of an Attorney
        :type bar_number: str
        :param email_list: List of Attorney Email Addresses
        :type email_list: List[str]
        :param address_list: List of Attorney Addresses
        :type address_list: List[str]
        :param phone_list: List of Attorney Phone Numbers
        :type phone_list: List[str]
        :param law_firm_list: List of Attorney Firm Names
        :type law_firm_list: List[str]
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyMatchApi(api_client).get_norm_attorney_match_with_http_info(workspace_id = unicourt.WORKSPACE_ID, barred_state = barred_state, full_name = full_name, first_name = first_name, middle_name = middle_name, last_name = last_name, bar_number = bar_number, email_list = email_list, address_list = address_list, phone_list = phone_list, law_firm_list = law_firm_list, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_norm_attorney_match_with_http_info(
        barred_state: Annotated[Optional[Annotated[str, Field(strict=True, max_length=5)]], Field(description="Barred State of the Attorney")] = None,
        full_name: Annotated[Optional[Annotated[str, Field(strict=True, max_length=250)]], Field(description="Attorney Full Name")] = None,
        first_name: Annotated[Optional[Annotated[str, Field(strict=True, max_length=250)]], Field(description="First Name of the Attorney")] = None,
        middle_name: Annotated[Optional[Annotated[str, Field(strict=True, max_length=250)]], Field(description="Middle Name of the Attorney")] = None,
        last_name: Annotated[Optional[Annotated[str, Field(strict=True, max_length=250)]], Field(description="Last Name of the Attorney")] = None,
        bar_number: Annotated[Optional[Annotated[str, Field(strict=True, max_length=50)]], Field(description="Bar Number of an Attorney")] = None,
        email_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Attorney Email Addresses")] = None,
        address_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Attorney Addresses")] = None,
        phone_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Attorney Phone Numbers")] = None,
        law_firm_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Attorney Firm Names")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormAttorneyMatchResponse]:

        """Norm Attorney Results for a given attorney name

        Returns an array of Norm Attorney object. <br> Either provide `fullName` or the combination of `firstName` and `lastName` (with `middleName` being optional).<br><br> This API supports multiple use cases:   - Search for an attorney name using fullname `MICHALE SCOTT HUNT`.   - Search an attorney within particular state.   - Search an attorney using the Bar Number.   - Filter the attorney search results with additional attributes - `emailList` or  `phoneList` or `addressList` or `lawFirmList`<br><br> ----- <br> ## Terms | Connector | Schema | Description  | Example | | ------| ------|------| ------| |**barredState** |Single Allowed | Indicates the state the attorney is barred.| **CA** | |**fullName** |Single Allowed | Full name of the attorney| **MICHAEL SCOTT HUNT** | |**firstName** |Single Allowed | First name of the attorney| **MICHAEL** | |**middleName** |Single Allowed | Middle name of the attorney| **SCOTT** | |**lastName** |Single Allowed | Last name of the attorney| **HUNT** | |**barNumber** |Single Allowed | Indicates the bar number of an attorney in a given state| **99804** | |**emailList** |Multiple Allowed | Indicates the email list for the attorney.| **[MSHUNT@HUNTHENRIQUES.COM]** | |**addressList** |Multiple Allowed | Indicates the address list for the attorney.| **[7017 REALM DR]** | |**phoneList** |Multiple Allowed | Indicates the phone list for the attorney.| **[408-362-2270]** | |**lawFirmList** |Multiple Allowed | Indicates the lawfirm list for the attorney.| **[HUNT & HENRIQUES LLP]** | 
        :param barred_state: Barred State of the Attorney
        :type barred_state: str
        :param full_name: Attorney Full Name
        :type full_name: str
        :param first_name: First Name of the Attorney
        :type first_name: str
        :param middle_name: Middle Name of the Attorney
        :type middle_name: str
        :param last_name: Last Name of the Attorney
        :type last_name: str
        :param bar_number: Bar Number of an Attorney
        :type bar_number: str
        :param email_list: List of Attorney Email Addresses
        :type email_list: List[str]
        :param address_list: List of Attorney Addresses
        :type address_list: List[str]
        :param phone_list: List of Attorney Phone Numbers
        :type phone_list: List[str]
        :param law_firm_list: List of Attorney Firm Names
        :type law_firm_list: List[str]
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneyMatchApi(api_client).get_norm_attorney_match_with_http_info(workspace_id = unicourt.WORKSPACE_ID, barred_state = barred_state, full_name = full_name, first_name = first_name, middle_name = middle_name, last_name = last_name, bar_number = bar_number, email_list = email_list, address_list = address_list, phone_list = phone_list, law_firm_list = law_firm_list, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_norm_attorney_match_without_preload_content(
        barred_state: Annotated[Optional[Annotated[str, Field(strict=True, max_length=5)]], Field(description="Barred State of the Attorney")] = None,
        full_name: Annotated[Optional[Annotated[str, Field(strict=True, max_length=250)]], Field(description="Attorney Full Name")] = None,
        first_name: Annotated[Optional[Annotated[str, Field(strict=True, max_length=250)]], Field(description="First Name of the Attorney")] = None,
        middle_name: Annotated[Optional[Annotated[str, Field(strict=True, max_length=250)]], Field(description="Middle Name of the Attorney")] = None,
        last_name: Annotated[Optional[Annotated[str, Field(strict=True, max_length=250)]], Field(description="Last Name of the Attorney")] = None,
        bar_number: Annotated[Optional[Annotated[str, Field(strict=True, max_length=50)]], Field(description="Bar Number of an Attorney")] = None,
        email_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Attorney Email Addresses")] = None,
        address_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Attorney Addresses")] = None,
        phone_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Attorney Phone Numbers")] = None,
        law_firm_list: Annotated[Optional[List[Annotated[str, Field(strict=True, max_length=5000)]]], Field(description="List of Attorney Firm Names")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Norm Attorney Results for a given attorney name

        Returns an array of Norm Attorney object. <br> Either provide `fullName` or the combination of `firstName` and `lastName` (with `middleName` being optional).<br><br> This API supports multiple use cases:   - Search for an attorney name using fullname `MICHALE SCOTT HUNT`.   - Search an attorney within particular state.   - Search an attorney using the Bar Number.   - Filter the attorney search results with additional attributes - `emailList` or  `phoneList` or `addressList` or `lawFirmList`<br><br> ----- <br> ## Terms | Connector | Schema | Description  | Example | | ------| ------|------| ------| |**barredState** |Single Allowed | Indicates the state the attorney is barred.| **CA** | |**fullName** |Single Allowed | Full name of the attorney| **MICHAEL SCOTT HUNT** | |**firstName** |Single Allowed | First name of the attorney| **MICHAEL** | |**middleName** |Single Allowed | Middle name of the attorney| **SCOTT** | |**lastName** |Single Allowed | Last name of the attorney| **HUNT** | |**barNumber** |Single Allowed | Indicates the bar number of an attorney in a given state| **99804** | |**emailList** |Multiple Allowed | Indicates the email list for the attorney.| **[MSHUNT@HUNTHENRIQUES.COM]** | |**addressList** |Multiple Allowed | Indicates the address list for the attorney.| **[7017 REALM DR]** | |**phoneList** |Multiple Allowed | Indicates the phone list for the attorney.| **[408-362-2270]** | |**lawFirmList** |Multiple Allowed | Indicates the lawfirm list for the attorney.| **[HUNT & HENRIQUES LLP]** | 
        :param barred_state: Barred State of the Attorney
        :type barred_state: str
        :param full_name: Attorney Full Name
        :type full_name: str
        :param first_name: First Name of the Attorney
        :type first_name: str
        :param middle_name: Middle Name of the Attorney
        :type middle_name: str
        :param last_name: Last Name of the Attorney
        :type last_name: str
        :param bar_number: Bar Number of an Attorney
        :type bar_number: str
        :param email_list: List of Attorney Email Addresses
        :type email_list: List[str]
        :param address_list: List of Attorney Addresses
        :type address_list: List[str]
        :param phone_list: List of Attorney Phone Numbers
        :type phone_list: List[str]
        :param law_firm_list: List of Attorney Firm Names
        :type law_firm_list: List[str]
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyMatchApi(api_client).get_norm_attorney_match_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, barred_state = barred_state, full_name = full_name, first_name = first_name, middle_name = middle_name, last_name = last_name, bar_number = bar_number, email_list = email_list, address_list = address_list, phone_list = phone_list, law_firm_list = law_firm_list, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
