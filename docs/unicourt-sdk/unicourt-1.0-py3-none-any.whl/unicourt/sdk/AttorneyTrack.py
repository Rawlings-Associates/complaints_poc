import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from datetime import datetime
from pydantic import Field, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.norm_attorney_response import NormAttorneyResponse
from unicourt.model.norm_attorney_track import NormAttorneyTrack
from unicourt.model.norm_attorney_track_request import NormAttorneyTrackRequest
from unicourt.model.norm_attorney_tracks_response import NormAttorneyTracksResponse
from unicourt.model.success import Success
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.attorney_track_api import AttorneyTrackApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class AttorneyTrack:

    @staticmethod
    def get_attorney_track_by_id(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The normAttorneyId for which normAttorney tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormAttorneyTrack]:

        """Get Attorney Track for a requested normAttorneyId.

        Retrieve Attorney Tracking information for the specified normAttorneyId value. The normAttorneyId parameter specifies the attorney for which tracking information is to be retrieved.
        :param norm_attorney_id: The normAttorneyId for which normAttorney tracking operations are performed. (required)
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyTrackApi(api_client).get_attorney_track_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_attorney_track_by_id_with_http_info(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The normAttorneyId for which normAttorney tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormAttorneyTrack]:

        """Get Attorney Track for a requested normAttorneyId.

        Retrieve Attorney Tracking information for the specified normAttorneyId value. The normAttorneyId parameter specifies the attorney for which tracking information is to be retrieved.
        :param norm_attorney_id: The normAttorneyId for which normAttorney tracking operations are performed. (required)
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneyTrackApi(api_client).get_attorney_track_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_attorney_track_by_id_without_preload_content(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The normAttorneyId for which normAttorney tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get Attorney Track for a requested normAttorneyId.

        Retrieve Attorney Tracking information for the specified normAttorneyId value. The normAttorneyId parameter specifies the attorney for which tracking information is to be retrieved.
        :param norm_attorney_id: The normAttorneyId for which normAttorney tracking operations are performed. (required)
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyTrackApi(api_client).get_attorney_track_by_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_attorney_tracks(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the attorney was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked attorneys regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the attorney information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked attorneys, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        norm_attorney_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="UniCourt's Attorney Id to filter.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormAttorneyTracksResponse]:

        """Get Attorney Track list.

        Retrieve a list of all tracked normAttorneys.
        :param last_fetch_date: Specifies the timestamp of the last time the attorney was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked attorneys regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the attorney information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked attorneys, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param norm_attorney_id: UniCourt's Attorney Id to filter.
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyTrackApi(api_client).get_attorney_tracks_with_http_info(workspace_id = unicourt.WORKSPACE_ID, last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_attorney_tracks_with_http_info(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the attorney was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked attorneys regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the attorney information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked attorneys, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        norm_attorney_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="UniCourt's Attorney Id to filter.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormAttorneyTracksResponse]:

        """Get Attorney Track list.

        Retrieve a list of all tracked normAttorneys.
        :param last_fetch_date: Specifies the timestamp of the last time the attorney was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked attorneys regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the attorney information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked attorneys, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param norm_attorney_id: UniCourt's Attorney Id to filter.
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneyTrackApi(api_client).get_attorney_tracks_with_http_info(workspace_id = unicourt.WORKSPACE_ID, last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_attorney_tracks_without_preload_content(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the attorney was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked attorneys regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the attorney information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked attorneys, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        norm_attorney_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="UniCourt's Attorney Id to filter.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get Attorney Track list.

        Retrieve a list of all tracked normAttorneys.
        :param last_fetch_date: Specifies the timestamp of the last time the attorney was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked attorneys regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the attorney information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked attorneys, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param norm_attorney_id: UniCourt's Attorney Id to filter.
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyTrackApi(api_client).get_attorney_tracks_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_attorney_tracks_root(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the attorney was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked attorneys regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the attorney information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked attorneys, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        norm_attorney_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="UniCourt's Attorney Id to filter.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormAttorneyTracksResponse]:

        """Get Attorney Track list.

        Retrieve a list of all tracked normAttorneys.

        :param last_fetch_date: Specifies the timestamp of the last time the attorney was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked attorneys regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the attorney information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked attorneys, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param norm_attorney_id: UniCourt's Attorney Id to filter.
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyTrackApi(api_client).get_attorney_tracks_root_with_http_info(last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_attorney_tracks_root_with_http_info(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the attorney was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked attorneys regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the attorney information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked attorneys, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        norm_attorney_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="UniCourt's Attorney Id to filter.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormAttorneyTracksResponse]:

        """Get Attorney Track list.

        Retrieve a list of all tracked normAttorneys.

        :param last_fetch_date: Specifies the timestamp of the last time the attorney was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked attorneys regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the attorney information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked attorneys, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param norm_attorney_id: UniCourt's Attorney Id to filter.
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneyTrackApi(api_client).get_attorney_tracks_root_with_http_info(last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_attorney_tracks_root_without_preload_content(
        last_fetch_date: Annotated[Optional[datetime], Field(description="Specifies the timestamp of the last time the attorney was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked attorneys regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        last_fetch_date_with_updates: Annotated[Optional[datetime], Field(description="Indicates the timestamp when the attorney information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked attorneys, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the results to be retrieved.<br>   - Minimum: 1 ")] = None,
        norm_attorney_id: Annotated[Optional[Annotated[str, Field(min_length=18, strict=True, max_length=18)]], Field(description="UniCourt's Attorney Id to filter.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Get Attorney Track list.

        Retrieve a list of all tracked normAttorneys.

        :param last_fetch_date: Specifies the timestamp of the last time the attorney was fetched. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDate is null, the system returns all tracked attorneys regardless of fetch time. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date: datetime
        :param last_fetch_date_with_updates: Indicates the timestamp when the attorney information was last updated with changes. Use the format YYYY-MM-DDTHH:MM:SS+ZZ:zz. If lastFetchDateWithUpdates is null, the response includes all tracked attorneys, whether or not they have updates. If a specific date is provided (e.g., 2025-08-01T02:00:00+00:00), it will fetch the requests from 2 AM to the end of the day. 
        :type last_fetch_date_with_updates: datetime
        :param page_number: The page number of the results to be retrieved.<br>   - Minimum: 1 
        :type page_number: int
        :param norm_attorney_id: UniCourt's Attorney Id to filter.
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyTrackApi(api_client).get_attorney_tracks_root_without_preload_content_with_http_info(last_fetch_date = last_fetch_date, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def remove_attorney_track_by_id(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The normAttorneyId for which normAttorney tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[Success]:

        """Remove Attorney Track for a specific Attorney Id.

        Remove Attorney Track for a specific Attorney Id. The normAttorneyId parameter specifies the attorney for which tracking is to be deleted.
        :param norm_attorney_id: The normAttorneyId for which normAttorney tracking operations are performed. (required)
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyTrackApi(api_client).remove_attorney_track_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def remove_attorney_track_by_id_with_http_info(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The normAttorneyId for which normAttorney tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[Success]:

        """Remove Attorney Track for a specific Attorney Id.

        Remove Attorney Track for a specific Attorney Id. The normAttorneyId parameter specifies the attorney for which tracking is to be deleted.
        :param norm_attorney_id: The normAttorneyId for which normAttorney tracking operations are performed. (required)
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneyTrackApi(api_client).remove_attorney_track_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def remove_attorney_track_by_id_without_preload_content(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The normAttorneyId for which normAttorney tracking operations are performed.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Remove Attorney Track for a specific Attorney Id.

        Remove Attorney Track for a specific Attorney Id. The normAttorneyId parameter specifies the attorney for which tracking is to be deleted.
        :param norm_attorney_id: The normAttorneyId for which normAttorney tracking operations are performed. (required)
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyTrackApi(api_client).remove_attorney_track_by_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_id = norm_attorney_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def track_attorney(
        norm_attorney_track_request: Optional[NormAttorneyTrackRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormAttorneyResponse]:

        """Add Attorney Track for the requested Attorney Id with refresh Window set.

        Track the specified Attorney with a configured refresh window to automatically monitor changes and updates. This endpoint allows you to set up automated tracking for an attorney's information at regular intervals.  Key Features:  - **Flexible Scheduling**: Configure tracking frequency with weekly (1W), bi-weekly (2W), or monthly (1M) refresh windows - **Date Range Control**: Set optional start and end dates for tracking periods   - **Update Detection**: Automatically detects and captures changes in attorney data - **State-Specific Tracking**: Option to track attorneys in specific states or all states where they are barred  Important Notes: - The `start date` must be today's date or a future date (optional parameter) - If a track already exists for the attorney, this endpoint will update the existing tracking configuration - The `notifyOnDelay` feature is not currently supported. Passing `notifyOnDelay` as `true` will result in a 400 Bad Request error. 
        :param norm_attorney_track_request:
        :type norm_attorney_track_request: NormAttorneyTrackRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyTrackApi(api_client).track_attorney_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_track_request = norm_attorney_track_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def track_attorney_with_http_info(
        norm_attorney_track_request: Optional[NormAttorneyTrackRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormAttorneyResponse]:

        """Add Attorney Track for the requested Attorney Id with refresh Window set.

        Track the specified Attorney with a configured refresh window to automatically monitor changes and updates. This endpoint allows you to set up automated tracking for an attorney's information at regular intervals.  Key Features:  - **Flexible Scheduling**: Configure tracking frequency with weekly (1W), bi-weekly (2W), or monthly (1M) refresh windows - **Date Range Control**: Set optional start and end dates for tracking periods   - **Update Detection**: Automatically detects and captures changes in attorney data - **State-Specific Tracking**: Option to track attorneys in specific states or all states where they are barred  Important Notes: - The `start date` must be today's date or a future date (optional parameter) - If a track already exists for the attorney, this endpoint will update the existing tracking configuration - The `notifyOnDelay` feature is not currently supported. Passing `notifyOnDelay` as `true` will result in a 400 Bad Request error. 
        :param norm_attorney_track_request:
        :type norm_attorney_track_request: NormAttorneyTrackRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneyTrackApi(api_client).track_attorney_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_track_request = norm_attorney_track_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def track_attorney_without_preload_content(
        norm_attorney_track_request: Optional[NormAttorneyTrackRequest] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Add Attorney Track for the requested Attorney Id with refresh Window set.

        Track the specified Attorney with a configured refresh window to automatically monitor changes and updates. This endpoint allows you to set up automated tracking for an attorney's information at regular intervals.  Key Features:  - **Flexible Scheduling**: Configure tracking frequency with weekly (1W), bi-weekly (2W), or monthly (1M) refresh windows - **Date Range Control**: Set optional start and end dates for tracking periods   - **Update Detection**: Automatically detects and captures changes in attorney data - **State-Specific Tracking**: Option to track attorneys in specific states or all states where they are barred  Important Notes: - The `start date` must be today's date or a future date (optional parameter) - If a track already exists for the attorney, this endpoint will update the existing tracking configuration - The `notifyOnDelay` feature is not currently supported. Passing `notifyOnDelay` as `true` will result in a 400 Bad Request error. 
        :param norm_attorney_track_request:
        :type norm_attorney_track_request: NormAttorneyTrackRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyTrackApi(api_client).track_attorney_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, norm_attorney_track_request = norm_attorney_track_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
