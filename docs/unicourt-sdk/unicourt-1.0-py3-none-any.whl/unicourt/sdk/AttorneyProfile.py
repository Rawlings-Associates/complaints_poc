import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from datetime import datetime
from pydantic import Field
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.norm_attorney import NormAttorney
from unicourt.model.norm_attorney_history_response import NormAttorneyHistoryResponse
from unicourt.model.norm_attorney_id_evolution_response import NormAttorneyIdEvolutionResponse
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.attorney_profile_api import AttorneyProfileApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class AttorneyProfile:

    @staticmethod
    def get_norm_attorney_by_id(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of Attorney.    - minimum: 18   - maximum: 18 ")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormAttorney]:

        """Attorney Profile

        This endpoint retrieves information on the attorney in our normalized attorney database which matches the normAttorneyId specified in the request.

        :param norm_attorney_id: Norm ID of Attorney.    - minimum: 18   - maximum: 18  (required)
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyProfileApi(api_client).get_norm_attorney_by_id_with_http_info(norm_attorney_id = norm_attorney_id, workspace_id = unicourt.WORKSPACE_ID, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_norm_attorney_by_id_with_http_info(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of Attorney.    - minimum: 18   - maximum: 18 ")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormAttorney]:

        """Attorney Profile

        This endpoint retrieves information on the attorney in our normalized attorney database which matches the normAttorneyId specified in the request.

        :param norm_attorney_id: Norm ID of Attorney.    - minimum: 18   - maximum: 18  (required)
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneyProfileApi(api_client).get_norm_attorney_by_id_with_http_info(norm_attorney_id = norm_attorney_id, workspace_id = unicourt.WORKSPACE_ID, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_norm_attorney_by_id_without_preload_content(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of Attorney.    - minimum: 18   - maximum: 18 ")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Attorney Profile

        This endpoint retrieves information on the attorney in our normalized attorney database which matches the normAttorneyId specified in the request.

        :param norm_attorney_id: Norm ID of Attorney.    - minimum: 18   - maximum: 18  (required)
        :type norm_attorney_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyProfileApi(api_client).get_norm_attorney_by_id_without_preload_content_with_http_info(norm_attorney_id = norm_attorney_id, workspace_id = unicourt.WORKSPACE_ID, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_norm_attorney_history_by_id(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of Attorney.    - minimum: 18   - maximum: 18 ")],
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the desired page of results.   - minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormAttorneyHistoryResponse]:

        """History of Norm Attorney.

        The Norm Attorney History API allows you to look up History of Attorney Details by normAttorneyId.

        :param norm_attorney_id: Norm ID of Attorney.    - minimum: 18   - maximum: 18  (required)
        :type norm_attorney_id: str
        :param page_number: The page number of the desired page of results.   - minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyProfileApi(api_client).get_norm_attorney_history_by_id_with_http_info(norm_attorney_id = norm_attorney_id, workspace_id = unicourt.WORKSPACE_ID, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_norm_attorney_history_by_id_with_http_info(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of Attorney.    - minimum: 18   - maximum: 18 ")],
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the desired page of results.   - minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormAttorneyHistoryResponse]:

        """History of Norm Attorney.

        The Norm Attorney History API allows you to look up History of Attorney Details by normAttorneyId.

        :param norm_attorney_id: Norm ID of Attorney.    - minimum: 18   - maximum: 18  (required)
        :type norm_attorney_id: str
        :param page_number: The page number of the desired page of results.   - minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneyProfileApi(api_client).get_norm_attorney_history_by_id_with_http_info(norm_attorney_id = norm_attorney_id, workspace_id = unicourt.WORKSPACE_ID, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_norm_attorney_history_by_id_without_preload_content(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of Attorney.    - minimum: 18   - maximum: 18 ")],
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the desired page of results.   - minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Norm Attorney.

        The Norm Attorney History API allows you to look up History of Attorney Details by normAttorneyId.

        :param norm_attorney_id: Norm ID of Attorney.    - minimum: 18   - maximum: 18  (required)
        :type norm_attorney_id: str
        :param page_number: The page number of the desired page of results.   - minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyProfileApi(api_client).get_norm_attorney_history_by_id_without_preload_content_with_http_info(norm_attorney_id = norm_attorney_id, workspace_id = unicourt.WORKSPACE_ID, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_norm_attorney_id_evolution_by_id(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of Attorney.    - minimum: 18   - maximum: 18 ")],
        id_evolution_date: Annotated[Optional[datetime], Field(description="If specified, the normAttorneyIdEvolutionByDateArray will contain normAttorneyIds that underwent an ID evolution on or more recently than the specified date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the desired page of results.   - minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[NormAttorneyIdEvolutionResponse]:

        """Id Evolution of Norm Attorney.

        The Norm Attorney ID Evolution API lets you look up the full history of ID changes for any normalized Attorney profile.

        :param norm_attorney_id: Norm ID of Attorney.    - minimum: 18   - maximum: 18  (required)
        :type norm_attorney_id: str
        :param id_evolution_date: If specified, the normAttorneyIdEvolutionByDateArray will contain normAttorneyIds that underwent an ID evolution on or more recently than the specified date.
        :type id_evolution_date: datetime
        :param page_number: The page number of the desired page of results.   - minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyProfileApi(api_client).get_norm_attorney_id_evolution_by_id_with_http_info(norm_attorney_id = norm_attorney_id, workspace_id = unicourt.WORKSPACE_ID, id_evolution_date = id_evolution_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_norm_attorney_id_evolution_by_id_with_http_info(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of Attorney.    - minimum: 18   - maximum: 18 ")],
        id_evolution_date: Annotated[Optional[datetime], Field(description="If specified, the normAttorneyIdEvolutionByDateArray will contain normAttorneyIds that underwent an ID evolution on or more recently than the specified date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the desired page of results.   - minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[NormAttorneyIdEvolutionResponse]:

        """Id Evolution of Norm Attorney.

        The Norm Attorney ID Evolution API lets you look up the full history of ID changes for any normalized Attorney profile.

        :param norm_attorney_id: Norm ID of Attorney.    - minimum: 18   - maximum: 18  (required)
        :type norm_attorney_id: str
        :param id_evolution_date: If specified, the normAttorneyIdEvolutionByDateArray will contain normAttorneyIds that underwent an ID evolution on or more recently than the specified date.
        :type id_evolution_date: datetime
        :param page_number: The page number of the desired page of results.   - minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return AttorneyProfileApi(api_client).get_norm_attorney_id_evolution_by_id_with_http_info(norm_attorney_id = norm_attorney_id, workspace_id = unicourt.WORKSPACE_ID, id_evolution_date = id_evolution_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_norm_attorney_id_evolution_by_id_without_preload_content(
        norm_attorney_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Norm ID of Attorney.    - minimum: 18   - maximum: 18 ")],
        id_evolution_date: Annotated[Optional[datetime], Field(description="If specified, the normAttorneyIdEvolutionByDateArray will contain normAttorneyIds that underwent an ID evolution on or more recently than the specified date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(strict=True, ge=1)]], Field(description="The page number of the desired page of results.   - minimum: 1 ")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Id Evolution of Norm Attorney.

        The Norm Attorney ID Evolution API lets you look up the full history of ID changes for any normalized Attorney profile.

        :param norm_attorney_id: Norm ID of Attorney.    - minimum: 18   - maximum: 18  (required)
        :type norm_attorney_id: str
        :param id_evolution_date: If specified, the normAttorneyIdEvolutionByDateArray will contain normAttorneyIds that underwent an ID evolution on or more recently than the specified date.
        :type id_evolution_date: datetime
        :param page_number: The page number of the desired page of results.   - minimum: 1 
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = AttorneyProfileApi(api_client).get_norm_attorney_id_evolution_by_id_without_preload_content_with_http_info(norm_attorney_id = norm_attorney_id, workspace_id = unicourt.WORKSPACE_ID, id_evolution_date = id_evolution_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
