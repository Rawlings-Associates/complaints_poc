import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.invalidate_workspace_access_token_request import InvalidateWorkspaceAccessTokenRequest
from unicourt.model.success import Success
from unicourt.model.workspace_access_token import WorkspaceAccessToken
from unicourt.model.workspace_access_token_ids_response import WorkspaceAccessTokenIdsResponse
from unicourt.model.workspace_access_token_request import WorkspaceAccessTokenRequest
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.workspace_token_management_api import WorkspaceTokenManagementApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class WorkspaceTokenManagement:

    @staticmethod
    def generate_new_workspace_token(
        workspace_access_token_request: Annotated[Optional[WorkspaceAccessTokenRequest], Field(description="The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[WorkspaceAccessToken]:

        """Generate new workspace token to access API.

        This endpoint allows you to generate a new workspace-scoped access token for a specific workspace. Provide your Client ID, Client Secret, and `workspaceId` in the request body. The generated token is required for accessing all UniCourt API endpoints within the specified workspace context, except for the Authentication API itself. Each workspace can have a maximum of 10 active access tokens at any time. The tokens are workspace-specific and never expire automatically. If you attempt to generate a token that would exceed the 10-token limit for a workspace, you will receive an error message.

        :param workspace_access_token_request: The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.
        :type workspace_access_token_request: WorkspaceAccessTokenRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceTokenManagementApi(api_client).generate_new_workspace_token_with_http_info(workspace_access_token_request = workspace_access_token_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def generate_new_workspace_token_with_http_info(
        workspace_access_token_request: Annotated[Optional[WorkspaceAccessTokenRequest], Field(description="The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[WorkspaceAccessToken]:

        """Generate new workspace token to access API.

        This endpoint allows you to generate a new workspace-scoped access token for a specific workspace. Provide your Client ID, Client Secret, and `workspaceId` in the request body. The generated token is required for accessing all UniCourt API endpoints within the specified workspace context, except for the Authentication API itself. Each workspace can have a maximum of 10 active access tokens at any time. The tokens are workspace-specific and never expire automatically. If you attempt to generate a token that would exceed the 10-token limit for a workspace, you will receive an error message.

        :param workspace_access_token_request: The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.
        :type workspace_access_token_request: WorkspaceAccessTokenRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return WorkspaceTokenManagementApi(api_client).generate_new_workspace_token_with_http_info(workspace_access_token_request = workspace_access_token_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def generate_new_workspace_token_without_preload_content(
        workspace_access_token_request: Annotated[Optional[WorkspaceAccessTokenRequest], Field(description="The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Generate new workspace token to access API.

        This endpoint allows you to generate a new workspace-scoped access token for a specific workspace. Provide your Client ID, Client Secret, and `workspaceId` in the request body. The generated token is required for accessing all UniCourt API endpoints within the specified workspace context, except for the Authentication API itself. Each workspace can have a maximum of 10 active access tokens at any time. The tokens are workspace-specific and never expire automatically. If you attempt to generate a token that would exceed the 10-token limit for a workspace, you will receive an error message.

        :param workspace_access_token_request: The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.
        :type workspace_access_token_request: WorkspaceAccessTokenRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceTokenManagementApi(api_client).generate_new_workspace_token_without_preload_content_with_http_info(workspace_access_token_request = workspace_access_token_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def invalidate_all_workspace_tokens(
        workspace_access_token_request: Annotated[Optional[WorkspaceAccessTokenRequest], Field(description="The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[Success]:

        """API to invalidate all workspace access tokens for a workspace.

        An endpoint which allows you to invalidate all workspace access tokens for the specified workspace. Provide your Client ID, Client Secret, and `workspaceId` in the request body.

        :param workspace_access_token_request: The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.
        :type workspace_access_token_request: WorkspaceAccessTokenRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceTokenManagementApi(api_client).invalidate_all_workspace_tokens_with_http_info(workspace_access_token_request = workspace_access_token_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def invalidate_all_workspace_tokens_with_http_info(
        workspace_access_token_request: Annotated[Optional[WorkspaceAccessTokenRequest], Field(description="The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[Success]:

        """API to invalidate all workspace access tokens for a workspace.

        An endpoint which allows you to invalidate all workspace access tokens for the specified workspace. Provide your Client ID, Client Secret, and `workspaceId` in the request body.

        :param workspace_access_token_request: The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.
        :type workspace_access_token_request: WorkspaceAccessTokenRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return WorkspaceTokenManagementApi(api_client).invalidate_all_workspace_tokens_with_http_info(workspace_access_token_request = workspace_access_token_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def invalidate_all_workspace_tokens_without_preload_content(
        workspace_access_token_request: Annotated[Optional[WorkspaceAccessTokenRequest], Field(description="The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """API to invalidate all workspace access tokens for a workspace.

        An endpoint which allows you to invalidate all workspace access tokens for the specified workspace. Provide your Client ID, Client Secret, and `workspaceId` in the request body.

        :param workspace_access_token_request: The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.
        :type workspace_access_token_request: WorkspaceAccessTokenRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceTokenManagementApi(api_client).invalidate_all_workspace_tokens_without_preload_content_with_http_info(workspace_access_token_request = workspace_access_token_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def invalidate_workspace_token(
        invalidate_workspace_access_token_request: Annotated[Optional[InvalidateWorkspaceAccessTokenRequest], Field(description="The endpoint accepts your Client ID, Client Secret, workspace ID, and the `workspaceTokenId` for the workspace access token you wish to invalidate as part of the request.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[Success]:

        """Invalidates the workspace access token.

        An endpoint that allows you to invalidate a specific workspace access token. Provide your Client ID, Client Secret, `workspaceId`, and `workspaceTokenId` in the request body. You can target individual tokens for revocation while leaving other tokens active. Token ids can be obtained from the /listAllWorkspaceTokenIds endpoint.

        :param invalidate_workspace_access_token_request: The endpoint accepts your Client ID, Client Secret, workspace ID, and the `workspaceTokenId` for the workspace access token you wish to invalidate as part of the request.
        :type invalidate_workspace_access_token_request: InvalidateWorkspaceAccessTokenRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceTokenManagementApi(api_client).invalidate_workspace_token_with_http_info(invalidate_workspace_access_token_request = invalidate_workspace_access_token_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def invalidate_workspace_token_with_http_info(
        invalidate_workspace_access_token_request: Annotated[Optional[InvalidateWorkspaceAccessTokenRequest], Field(description="The endpoint accepts your Client ID, Client Secret, workspace ID, and the `workspaceTokenId` for the workspace access token you wish to invalidate as part of the request.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[Success]:

        """Invalidates the workspace access token.

        An endpoint that allows you to invalidate a specific workspace access token. Provide your Client ID, Client Secret, `workspaceId`, and `workspaceTokenId` in the request body. You can target individual tokens for revocation while leaving other tokens active. Token ids can be obtained from the /listAllWorkspaceTokenIds endpoint.

        :param invalidate_workspace_access_token_request: The endpoint accepts your Client ID, Client Secret, workspace ID, and the `workspaceTokenId` for the workspace access token you wish to invalidate as part of the request.
        :type invalidate_workspace_access_token_request: InvalidateWorkspaceAccessTokenRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return WorkspaceTokenManagementApi(api_client).invalidate_workspace_token_with_http_info(invalidate_workspace_access_token_request = invalidate_workspace_access_token_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def invalidate_workspace_token_without_preload_content(
        invalidate_workspace_access_token_request: Annotated[Optional[InvalidateWorkspaceAccessTokenRequest], Field(description="The endpoint accepts your Client ID, Client Secret, workspace ID, and the `workspaceTokenId` for the workspace access token you wish to invalidate as part of the request.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Invalidates the workspace access token.

        An endpoint that allows you to invalidate a specific workspace access token. Provide your Client ID, Client Secret, `workspaceId`, and `workspaceTokenId` in the request body. You can target individual tokens for revocation while leaving other tokens active. Token ids can be obtained from the /listAllWorkspaceTokenIds endpoint.

        :param invalidate_workspace_access_token_request: The endpoint accepts your Client ID, Client Secret, workspace ID, and the `workspaceTokenId` for the workspace access token you wish to invalidate as part of the request.
        :type invalidate_workspace_access_token_request: InvalidateWorkspaceAccessTokenRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceTokenManagementApi(api_client).invalidate_workspace_token_without_preload_content_with_http_info(invalidate_workspace_access_token_request = invalidate_workspace_access_token_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def list_all_workspace_token_ids(
        workspace_access_token_request: Annotated[Optional[WorkspaceAccessTokenRequest], Field(description="The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[WorkspaceAccessTokenIdsResponse]:

        """Lists all the workspace access token Ids.

        An endpoint that allows you to view all active access tokens associated with your Client ID and Client Secret within a specific workspace context. Provide `workspaceId` in the request body. This provides visibility into all tokens currently active for the specified workspace, including their creation dates and issuing IP addresses.

        :param workspace_access_token_request: The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.
        :type workspace_access_token_request: WorkspaceAccessTokenRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceTokenManagementApi(api_client).list_all_workspace_token_ids_with_http_info(workspace_access_token_request = workspace_access_token_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def list_all_workspace_token_ids_with_http_info(
        workspace_access_token_request: Annotated[Optional[WorkspaceAccessTokenRequest], Field(description="The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[WorkspaceAccessTokenIdsResponse]:

        """Lists all the workspace access token Ids.

        An endpoint that allows you to view all active access tokens associated with your Client ID and Client Secret within a specific workspace context. Provide `workspaceId` in the request body. This provides visibility into all tokens currently active for the specified workspace, including their creation dates and issuing IP addresses.

        :param workspace_access_token_request: The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.
        :type workspace_access_token_request: WorkspaceAccessTokenRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return WorkspaceTokenManagementApi(api_client).list_all_workspace_token_ids_with_http_info(workspace_access_token_request = workspace_access_token_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def list_all_workspace_token_ids_without_preload_content(
        workspace_access_token_request: Annotated[Optional[WorkspaceAccessTokenRequest], Field(description="The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Lists all the workspace access token Ids.

        An endpoint that allows you to view all active access tokens associated with your Client ID and Client Secret within a specific workspace context. Provide `workspaceId` in the request body. This provides visibility into all tokens currently active for the specified workspace, including their creation dates and issuing IP addresses.

        :param workspace_access_token_request: The endpoint accepts your Client ID, Client Secret, and workspace ID as part of the request.
        :type workspace_access_token_request: WorkspaceAccessTokenRequest
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = WorkspaceTokenManagementApi(api_client).list_all_workspace_token_ids_without_preload_content_with_http_info(workspace_access_token_request = workspace_access_token_request, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
