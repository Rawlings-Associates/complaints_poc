import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.area_of_law import AreaOfLaw
from unicourt.model.area_of_law_response import AreaOfLawResponse
from unicourt.model.case_class import CaseClass
from unicourt.model.case_class_response import CaseClassResponse
from unicourt.model.case_disposition import CaseDisposition
from unicourt.model.case_disposition_group import CaseDispositionGroup
from unicourt.model.case_disposition_group_response import CaseDispositionGroupResponse
from unicourt.model.case_disposition_response import CaseDispositionResponse
from unicourt.model.case_event import CaseEvent
from unicourt.model.case_event_group import CaseEventGroup
from unicourt.model.case_event_group_response import CaseEventGroupResponse
from unicourt.model.case_event_response import CaseEventResponse
from unicourt.model.case_relationship_type import CaseRelationshipType
from unicourt.model.case_relationship_type_response import CaseRelationshipTypeResponse
from unicourt.model.case_status import CaseStatus
from unicourt.model.case_status_group import CaseStatusGroup
from unicourt.model.case_status_group_response import CaseStatusGroupResponse
from unicourt.model.case_status_response import CaseStatusResponse
from unicourt.model.case_type import CaseType
from unicourt.model.case_type_group import CaseTypeGroup
from unicourt.model.case_type_group_response import CaseTypeGroupResponse
from unicourt.model.case_type_response import CaseTypeResponse
from unicourt.model.counsel_role import CounselRole
from unicourt.model.counsel_role_response import CounselRoleResponse
from unicourt.model.judge_role import JudgeRole
from unicourt.model.judge_role_response import JudgeRoleResponse
from unicourt.model.motion_outcome import MotionOutcome
from unicourt.model.motion_outcome_group import MotionOutcomeGroup
from unicourt.model.motion_outcome_group_response import MotionOutcomeGroupResponse
from unicourt.model.motion_outcome_response import MotionOutcomeResponse
from unicourt.model.motion_type import MotionType
from unicourt.model.motion_type_category import MotionTypeCategory
from unicourt.model.motion_type_category_response import MotionTypeCategoryResponse
from unicourt.model.motion_type_group import MotionTypeGroup
from unicourt.model.motion_type_group_response import MotionTypeGroupResponse
from unicourt.model.motion_type_response import MotionTypeResponse
from unicourt.model.party_role import PartyRole
from unicourt.model.party_role_group import PartyRoleGroup
from unicourt.model.party_role_group_response import PartyRoleGroupResponse
from unicourt.model.party_role_response import PartyRoleResponse
from unicourt.model.procedural_activity import ProceduralActivity
from unicourt.model.procedural_activity_group import ProceduralActivityGroup
from unicourt.model.procedural_activity_group_response import ProceduralActivityGroupResponse
from unicourt.model.procedural_activity_response import ProceduralActivityResponse
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.case_master_data_api import CaseMasterDataApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class CaseMasterData:

    @staticmethod
    def get_area_of_law(
        area_of_law_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The areaOfLawId of the area of law to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[AreaOfLaw]:

        """AreaOfLaw details for the provided areaOfLawId.

        Fetch the details of the specific area of law. 
        :param area_of_law_id: The areaOfLawId of the area of law to be retrieved. (required)
        :type area_of_law_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_area_of_law_with_http_info(workspace_id = unicourt.WORKSPACE_ID, area_of_law_id = area_of_law_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_area_of_law_with_http_info(
        area_of_law_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The areaOfLawId of the area of law to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[AreaOfLaw]:

        """AreaOfLaw details for the provided areaOfLawId.

        Fetch the details of the specific area of law. 
        :param area_of_law_id: The areaOfLawId of the area of law to be retrieved. (required)
        :type area_of_law_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_area_of_law_with_http_info(workspace_id = unicourt.WORKSPACE_ID, area_of_law_id = area_of_law_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_area_of_law_without_preload_content(
        area_of_law_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The areaOfLawId of the area of law to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """AreaOfLaw details for the provided areaOfLawId.

        Fetch the details of the specific area of law. 
        :param area_of_law_id: The areaOfLawId of the area of law to be retrieved. (required)
        :type area_of_law_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_area_of_law_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, area_of_law_id = area_of_law_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_areas_of_law(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `AreaOfLawQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[AreaOfLawResponse]:

        """AreaOfLaw Object.

        Fetch the list of areas of law supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Probate) AND areaOfLawId:AOFLRLYttsKKbbhXQ5** | | **OR** | Returns results matching any specified condition. | **name:(Probate) OR name:(Energy)** | | **NOT** | Excludes results matching the specified condition. | **name:(Probate) NOT name:(Energy)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Probate\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Probate\" OR name:\"Energy\") AND areaOfLawId:\"AOFLRLYttsKKbbhXQ5\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> AreaOfLawQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `AreaOfLawQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_areas_of_law_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_areas_of_law_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `AreaOfLawQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[AreaOfLawResponse]:

        """AreaOfLaw Object.

        Fetch the list of areas of law supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Probate) AND areaOfLawId:AOFLRLYttsKKbbhXQ5** | | **OR** | Returns results matching any specified condition. | **name:(Probate) OR name:(Energy)** | | **NOT** | Excludes results matching the specified condition. | **name:(Probate) NOT name:(Energy)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Probate\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Probate\" OR name:\"Energy\") AND areaOfLawId:\"AOFLRLYttsKKbbhXQ5\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> AreaOfLawQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `AreaOfLawQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_areas_of_law_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_areas_of_law_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `AreaOfLawQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """AreaOfLaw Object.

        Fetch the list of areas of law supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Probate) AND areaOfLawId:AOFLRLYttsKKbbhXQ5** | | **OR** | Returns results matching any specified condition. | **name:(Probate) OR name:(Energy)** | | **NOT** | Excludes results matching the specified condition. | **name:(Probate) NOT name:(Energy)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Probate\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Probate\" OR name:\"Energy\") AND areaOfLawId:\"AOFLRLYttsKKbbhXQ5\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> AreaOfLawQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `AreaOfLawQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_areas_of_law_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_class(
        case_class_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseClassId of the case class to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseClass]:

        """Case Class details for the provided caseClassId.

        Fetch the details of the specific case class. 
        :param case_class_id: The caseClassId of the case class to be retrieved. (required)
        :type case_class_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_class_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_class_id = case_class_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_class_with_http_info(
        case_class_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseClassId of the case class to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseClass]:

        """Case Class details for the provided caseClassId.

        Fetch the details of the specific case class. 
        :param case_class_id: The caseClassId of the case class to be retrieved. (required)
        :type case_class_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_class_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_class_id = case_class_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_class_without_preload_content(
        case_class_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseClassId of the case class to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Class details for the provided caseClassId.

        Fetch the details of the specific case class. 
        :param case_class_id: The caseClassId of the case class to be retrieved. (required)
        :type case_class_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_class_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_class_id = case_class_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_disposition(
        case_disposition_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseDispositionId of the case disposition to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseDisposition]:

        """Case Disposition details for the provided caseDispositionId.

        Fetch the details of the specific case disposition. 
        :param case_disposition_id: The caseDispositionId of the case disposition to be retrieved. (required)
        :type case_disposition_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_disposition_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_disposition_id = case_disposition_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_disposition_with_http_info(
        case_disposition_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseDispositionId of the case disposition to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseDisposition]:

        """Case Disposition details for the provided caseDispositionId.

        Fetch the details of the specific case disposition. 
        :param case_disposition_id: The caseDispositionId of the case disposition to be retrieved. (required)
        :type case_disposition_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_disposition_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_disposition_id = case_disposition_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_disposition_without_preload_content(
        case_disposition_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseDispositionId of the case disposition to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Disposition details for the provided caseDispositionId.

        Fetch the details of the specific case disposition. 
        :param case_disposition_id: The caseDispositionId of the case disposition to be retrieved. (required)
        :type case_disposition_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_disposition_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_disposition_id = case_disposition_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_disposition_group(
        case_disposition_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseDispositionGroupId of the case disposition group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseDispositionGroup]:

        """Case Disposition Group details for the provided caseDispositionGroupId.

        Fetch the details of the specific case disposition group. 
        :param case_disposition_group_id: The caseDispositionGroupId of the case disposition group to be retrieved. (required)
        :type case_disposition_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_disposition_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_disposition_group_id = case_disposition_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_disposition_group_with_http_info(
        case_disposition_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseDispositionGroupId of the case disposition group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseDispositionGroup]:

        """Case Disposition Group details for the provided caseDispositionGroupId.

        Fetch the details of the specific case disposition group. 
        :param case_disposition_group_id: The caseDispositionGroupId of the case disposition group to be retrieved. (required)
        :type case_disposition_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_disposition_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_disposition_group_id = case_disposition_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_disposition_group_without_preload_content(
        case_disposition_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseDispositionGroupId of the case disposition group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Disposition Group details for the provided caseDispositionGroupId.

        Fetch the details of the specific case disposition group. 
        :param case_disposition_group_id: The caseDispositionGroupId of the case disposition group to be retrieved. (required)
        :type case_disposition_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_disposition_group_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_disposition_group_id = case_disposition_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_disposition_groups(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseDispositionGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseDispositionGroupResponse]:

        """Case Disposition Group Objects.

        Fetch the list of case disposition groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(ADR Resolution) AND caseDispositionGroupId:CDSGWoYnw8A3X6Urtj** | | **OR** | Returns results matching any specified condition. | **name:(Administrative Closure) OR name:(ADR Resolution)** | | **NOT** | Excludes results matching the specified condition. | **name:(ADR Resolution) NOT name:(Administrative Closure)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"ADR Resolution\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Administrative Closure\" OR name:\"ADR Resolution\") AND caseDispositionGroupId:\"CDSGWoYnw8A3X6Urtj\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseDispositionGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseDispositionGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_disposition_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_disposition_groups_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseDispositionGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseDispositionGroupResponse]:

        """Case Disposition Group Objects.

        Fetch the list of case disposition groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(ADR Resolution) AND caseDispositionGroupId:CDSGWoYnw8A3X6Urtj** | | **OR** | Returns results matching any specified condition. | **name:(Administrative Closure) OR name:(ADR Resolution)** | | **NOT** | Excludes results matching the specified condition. | **name:(ADR Resolution) NOT name:(Administrative Closure)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"ADR Resolution\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Administrative Closure\" OR name:\"ADR Resolution\") AND caseDispositionGroupId:\"CDSGWoYnw8A3X6Urtj\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseDispositionGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseDispositionGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_disposition_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_disposition_groups_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseDispositionGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Disposition Group Objects.

        Fetch the list of case disposition groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(ADR Resolution) AND caseDispositionGroupId:CDSGWoYnw8A3X6Urtj** | | **OR** | Returns results matching any specified condition. | **name:(Administrative Closure) OR name:(ADR Resolution)** | | **NOT** | Excludes results matching the specified condition. | **name:(ADR Resolution) NOT name:(Administrative Closure)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"ADR Resolution\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Administrative Closure\" OR name:\"ADR Resolution\") AND caseDispositionGroupId:\"CDSGWoYnw8A3X6Urtj\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseDispositionGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseDispositionGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_disposition_groups_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_dispositions(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseDispositionQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseDispositionResponse]:

        """Case Disposition Objects.

        Fetch the list of case dispositions supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Amended Judgment) AND caseDispositionId:CDSN49sf3WGFb4v4Lr** | | **OR** | Returns results matching any specified condition. | **name:(Case Reopened) OR name:(Amended Judgment)** | | **NOT** | Excludes results matching the specified condition. | **name:(Amended Judgment) NOT name:(Case Reopened)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Amended Judgment\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Case Reopened\" OR name:\"Amended Judgment\") AND caseDispositionId:\"CDSN49sf3WGFb4v4Lr\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseDispositionQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseDispositionQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_dispositions_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_dispositions_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseDispositionQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseDispositionResponse]:

        """Case Disposition Objects.

        Fetch the list of case dispositions supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Amended Judgment) AND caseDispositionId:CDSN49sf3WGFb4v4Lr** | | **OR** | Returns results matching any specified condition. | **name:(Case Reopened) OR name:(Amended Judgment)** | | **NOT** | Excludes results matching the specified condition. | **name:(Amended Judgment) NOT name:(Case Reopened)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Amended Judgment\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Case Reopened\" OR name:\"Amended Judgment\") AND caseDispositionId:\"CDSN49sf3WGFb4v4Lr\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseDispositionQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseDispositionQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_dispositions_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_dispositions_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseDispositionQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Disposition Objects.

        Fetch the list of case dispositions supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Amended Judgment) AND caseDispositionId:CDSN49sf3WGFb4v4Lr** | | **OR** | Returns results matching any specified condition. | **name:(Case Reopened) OR name:(Amended Judgment)** | | **NOT** | Excludes results matching the specified condition. | **name:(Amended Judgment) NOT name:(Case Reopened)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Amended Judgment\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Case Reopened\" OR name:\"Amended Judgment\") AND caseDispositionId:\"CDSN49sf3WGFb4v4Lr\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseDispositionQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseDispositionQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_dispositions_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_event(
        case_event_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseEventId of the case event to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseEvent]:

        """Case Event details for the provided caseEventId.

        Fetch the details of the specific case event. 
        :param case_event_id: The caseEventId of the case event to be retrieved. (required)
        :type case_event_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_event_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_event_id = case_event_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_event_with_http_info(
        case_event_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseEventId of the case event to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseEvent]:

        """Case Event details for the provided caseEventId.

        Fetch the details of the specific case event. 
        :param case_event_id: The caseEventId of the case event to be retrieved. (required)
        :type case_event_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_event_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_event_id = case_event_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_event_without_preload_content(
        case_event_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseEventId of the case event to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Event details for the provided caseEventId.

        Fetch the details of the specific case event. 
        :param case_event_id: The caseEventId of the case event to be retrieved. (required)
        :type case_event_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_event_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_event_id = case_event_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_event_group(
        case_event_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseEventGroupId of the case event group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseEventGroup]:

        """Case Event Group details for the provided caseEventGroupId.

        Fetch the details of the specific case event group. 
        :param case_event_group_id: The caseEventGroupId of the case event group to be retrieved. (required)
        :type case_event_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_event_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_event_group_id = case_event_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_event_group_with_http_info(
        case_event_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseEventGroupId of the case event group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseEventGroup]:

        """Case Event Group details for the provided caseEventGroupId.

        Fetch the details of the specific case event group. 
        :param case_event_group_id: The caseEventGroupId of the case event group to be retrieved. (required)
        :type case_event_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_event_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_event_group_id = case_event_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_event_group_without_preload_content(
        case_event_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseEventGroupId of the case event group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Event Group details for the provided caseEventGroupId.

        Fetch the details of the specific case event group. 
        :param case_event_group_id: The caseEventGroupId of the case event group to be retrieved. (required)
        :type case_event_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_event_group_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_event_group_id = case_event_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_event_groups(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseEventGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseEventGroupResponse]:

        """Case Event Group Objects.

        Fetch the list of case event groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Verdict) AND caseEventGroupId:CAEGfKqiKzPasJ3MKr** | | **OR** | Returns results matching any specified condition. | **name:(Supporting Materials) OR name:(Verdict)** | | **NOT** | Excludes results matching the specified condition. | **name:(Verdict) NOT name:(Supporting Materials)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Verdict\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Supporting Materials\" OR name:\"Verdict\") AND caseEventGroupId:\"CAEGfKqiKzPasJ3MKr\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseEventGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseEventGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_event_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_event_groups_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseEventGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseEventGroupResponse]:

        """Case Event Group Objects.

        Fetch the list of case event groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Verdict) AND caseEventGroupId:CAEGfKqiKzPasJ3MKr** | | **OR** | Returns results matching any specified condition. | **name:(Supporting Materials) OR name:(Verdict)** | | **NOT** | Excludes results matching the specified condition. | **name:(Verdict) NOT name:(Supporting Materials)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Verdict\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Supporting Materials\" OR name:\"Verdict\") AND caseEventGroupId:\"CAEGfKqiKzPasJ3MKr\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseEventGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseEventGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_event_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_event_groups_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseEventGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Event Group Objects.

        Fetch the list of case event groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Verdict) AND caseEventGroupId:CAEGfKqiKzPasJ3MKr** | | **OR** | Returns results matching any specified condition. | **name:(Supporting Materials) OR name:(Verdict)** | | **NOT** | Excludes results matching the specified condition. | **name:(Verdict) NOT name:(Supporting Materials)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Verdict\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Supporting Materials\" OR name:\"Verdict\") AND caseEventGroupId:\"CAEGfKqiKzPasJ3MKr\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseEventGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseEventGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_event_groups_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_events(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseEventQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseEventResponse]:

        """Case Event Objects.

        Fetch the list of case events supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Abstract of Judgment) AND caseEventId:CAETdk8wEjBHBqhfJK** | | **OR** | Returns results matching any specified condition. | **name:(Administrative judgment) OR name:(Abstract of Judgment)** | | **NOT** | Excludes results matching the specified condition. | **name:(Abstract of Judgment) NOT name:(Administrative judgment)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Abstract of Judgment\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Administrative judgment\" OR name:\"Abstract of Judgment\") AND caseEventId:\"CAETdk8wEjBHBqhfJK\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseEventQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseEventQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_events_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_events_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseEventQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseEventResponse]:

        """Case Event Objects.

        Fetch the list of case events supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Abstract of Judgment) AND caseEventId:CAETdk8wEjBHBqhfJK** | | **OR** | Returns results matching any specified condition. | **name:(Administrative judgment) OR name:(Abstract of Judgment)** | | **NOT** | Excludes results matching the specified condition. | **name:(Abstract of Judgment) NOT name:(Administrative judgment)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Abstract of Judgment\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Administrative judgment\" OR name:\"Abstract of Judgment\") AND caseEventId:\"CAETdk8wEjBHBqhfJK\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseEventQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseEventQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_events_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_events_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseEventQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Event Objects.

        Fetch the list of case events supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Abstract of Judgment) AND caseEventId:CAETdk8wEjBHBqhfJK** | | **OR** | Returns results matching any specified condition. | **name:(Administrative judgment) OR name:(Abstract of Judgment)** | | **NOT** | Excludes results matching the specified condition. | **name:(Abstract of Judgment) NOT name:(Administrative judgment)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Abstract of Judgment\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Administrative judgment\" OR name:\"Abstract of Judgment\") AND caseEventId:\"CAETdk8wEjBHBqhfJK\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseEventQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseEventQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_events_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_relationship_type(
        case_relationship_type_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseRelationshipTypeId of the case relationship type to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseRelationshipType]:

        """Case Relationship Type Object for the provided caseRelationshipTypeId.

        Fetch the details of the specific case relationship type. 
        :param case_relationship_type_id: The caseRelationshipTypeId of the case relationship type to be retrieved. (required)
        :type case_relationship_type_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_relationship_type_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_relationship_type_id = case_relationship_type_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_relationship_type_with_http_info(
        case_relationship_type_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseRelationshipTypeId of the case relationship type to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseRelationshipType]:

        """Case Relationship Type Object for the provided caseRelationshipTypeId.

        Fetch the details of the specific case relationship type. 
        :param case_relationship_type_id: The caseRelationshipTypeId of the case relationship type to be retrieved. (required)
        :type case_relationship_type_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_relationship_type_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_relationship_type_id = case_relationship_type_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_relationship_type_without_preload_content(
        case_relationship_type_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseRelationshipTypeId of the case relationship type to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Relationship Type Object for the provided caseRelationshipTypeId.

        Fetch the details of the specific case relationship type. 
        :param case_relationship_type_id: The caseRelationshipTypeId of the case relationship type to be retrieved. (required)
        :type case_relationship_type_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_relationship_type_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_relationship_type_id = case_relationship_type_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_relationship_types(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseRelationshipTypeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseRelationshipTypeResponse]:

        """Case Relationship Type Object.

        Fetch the list of case relationship types supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Child Case) AND caseRelationshipTypeId:CRTPgkmnzpiBXstT3s** | | **OR** | Returns results matching any specified condition. | **name:(Inferred Case) OR name:(Child Case)** | | **NOT** | Excludes results matching the specified condition. | **name:(Inferred Case) NOT name:(Child Case)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Child Case\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Inferred Case\" OR name:\"Child Case\") AND caseRelationshipTypeId:\"CRTPgkmnzpiBXstT3s\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseRelationshipTypeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseRelationshipTypeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_relationship_types_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_relationship_types_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseRelationshipTypeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseRelationshipTypeResponse]:

        """Case Relationship Type Object.

        Fetch the list of case relationship types supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Child Case) AND caseRelationshipTypeId:CRTPgkmnzpiBXstT3s** | | **OR** | Returns results matching any specified condition. | **name:(Inferred Case) OR name:(Child Case)** | | **NOT** | Excludes results matching the specified condition. | **name:(Inferred Case) NOT name:(Child Case)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Child Case\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Inferred Case\" OR name:\"Child Case\") AND caseRelationshipTypeId:\"CRTPgkmnzpiBXstT3s\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseRelationshipTypeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseRelationshipTypeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_relationship_types_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_relationship_types_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseRelationshipTypeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Relationship Type Object.

        Fetch the list of case relationship types supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Child Case) AND caseRelationshipTypeId:CRTPgkmnzpiBXstT3s** | | **OR** | Returns results matching any specified condition. | **name:(Inferred Case) OR name:(Child Case)** | | **NOT** | Excludes results matching the specified condition. | **name:(Inferred Case) NOT name:(Child Case)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Child Case\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Inferred Case\" OR name:\"Child Case\") AND caseRelationshipTypeId:\"CRTPgkmnzpiBXstT3s\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseRelationshipTypeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseRelationshipTypeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_relationship_types_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_status(
        case_status_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseStatusId of the case status to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseStatus]:

        """Case Status details for the provided caseStatusId.

        Fetch the details of the specific case status. 
        :param case_status_id: The caseStatusId of the case status to be retrieved. (required)
        :type case_status_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_status_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_status_id = case_status_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_status_with_http_info(
        case_status_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseStatusId of the case status to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseStatus]:

        """Case Status details for the provided caseStatusId.

        Fetch the details of the specific case status. 
        :param case_status_id: The caseStatusId of the case status to be retrieved. (required)
        :type case_status_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_status_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_status_id = case_status_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_status_without_preload_content(
        case_status_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseStatusId of the case status to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Status details for the provided caseStatusId.

        Fetch the details of the specific case status. 
        :param case_status_id: The caseStatusId of the case status to be retrieved. (required)
        :type case_status_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_status_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_status_id = case_status_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_status_group(
        case_status_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseStatusGroupId of the case status group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseStatusGroup]:

        """Case Status Group details for the provided caseStatusGroupId.

        Fetch the details of the specific case status group. 
        :param case_status_group_id: The caseStatusGroupId of the case status group to be retrieved. (required)
        :type case_status_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_status_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_status_group_id = case_status_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_status_group_with_http_info(
        case_status_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseStatusGroupId of the case status group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseStatusGroup]:

        """Case Status Group details for the provided caseStatusGroupId.

        Fetch the details of the specific case status group. 
        :param case_status_group_id: The caseStatusGroupId of the case status group to be retrieved. (required)
        :type case_status_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_status_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_status_group_id = case_status_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_status_group_without_preload_content(
        case_status_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseStatusGroupId of the case status group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Status Group details for the provided caseStatusGroupId.

        Fetch the details of the specific case status group. 
        :param case_status_group_id: The caseStatusGroupId of the case status group to be retrieved. (required)
        :type case_status_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_status_group_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_status_group_id = case_status_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_status_groups(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseStatusGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseStatusGroupResponse]:

        """Case Status Group Object.

        Fetch the list of case status groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Open) AND caseStatusGroupId:CSSGCYoBCJ3A8j4MX4** | | **OR** | Returns results matching any specified condition. | **name:(Closed) OR name:(Open)** | | **NOT** | Excludes results matching the specified condition. | **name:(Closed) NOT name:(Open)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Open\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Closed\" OR name:\"Open\") AND caseStatusGroupId:\"CSSGCYoBCJ3A8j4MX4\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseStatusGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseStatusGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_status_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_status_groups_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseStatusGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseStatusGroupResponse]:

        """Case Status Group Object.

        Fetch the list of case status groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Open) AND caseStatusGroupId:CSSGCYoBCJ3A8j4MX4** | | **OR** | Returns results matching any specified condition. | **name:(Closed) OR name:(Open)** | | **NOT** | Excludes results matching the specified condition. | **name:(Closed) NOT name:(Open)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Open\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Closed\" OR name:\"Open\") AND caseStatusGroupId:\"CSSGCYoBCJ3A8j4MX4\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseStatusGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseStatusGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_status_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_status_groups_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseStatusGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Status Group Object.

        Fetch the list of case status groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Open) AND caseStatusGroupId:CSSGCYoBCJ3A8j4MX4** | | **OR** | Returns results matching any specified condition. | **name:(Closed) OR name:(Open)** | | **NOT** | Excludes results matching the specified condition. | **name:(Closed) NOT name:(Open)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Open\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Closed\" OR name:\"Open\") AND caseStatusGroupId:\"CSSGCYoBCJ3A8j4MX4\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseStatusGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseStatusGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_status_groups_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_type(
        case_type_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseTypeId of the case type to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseType]:

        """Case Type details for the provided caseTypeId.

        Fetch the details of the specific case type. 
        :param case_type_id: The caseTypeId of the case type to be retrieved. (required)
        :type case_type_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_type_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_type_id = case_type_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_type_with_http_info(
        case_type_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseTypeId of the case type to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseType]:

        """Case Type details for the provided caseTypeId.

        Fetch the details of the specific case type. 
        :param case_type_id: The caseTypeId of the case type to be retrieved. (required)
        :type case_type_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_type_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_type_id = case_type_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_type_without_preload_content(
        case_type_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseTypeId of the case type to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Type details for the provided caseTypeId.

        Fetch the details of the specific case type. 
        :param case_type_id: The caseTypeId of the case type to be retrieved. (required)
        :type case_type_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_type_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_type_id = case_type_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_type_group(
        case_type_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseTypeGroupId of the case type group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseTypeGroup]:

        """Case Type Group details for the provided caseTypeGroupId.

        Fetch the details of the specific case type group. 
        :param case_type_group_id: The caseTypeGroupId of the case type group to be retrieved. (required)
        :type case_type_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_type_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_type_group_id = case_type_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_type_group_with_http_info(
        case_type_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseTypeGroupId of the case type group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseTypeGroup]:

        """Case Type Group details for the provided caseTypeGroupId.

        Fetch the details of the specific case type group. 
        :param case_type_group_id: The caseTypeGroupId of the case type group to be retrieved. (required)
        :type case_type_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_type_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_type_group_id = case_type_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_type_group_without_preload_content(
        case_type_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The caseTypeGroupId of the case type group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Type Group details for the provided caseTypeGroupId.

        Fetch the details of the specific case type group. 
        :param case_type_group_id: The caseTypeGroupId of the case type group to be retrieved. (required)
        :type case_type_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_type_group_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_type_group_id = case_type_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_type_groups(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseTypeGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseTypeGroupResponse]:

        """Case Type Group Objects.

        Fetch the list of case type groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Tax and Revenue) AND caseTypeGroupId:CTYGSpWaVityBQndsv** | | **OR** | Returns results matching any specified condition. | **name:(Civil Procedure) OR name:(Tax and Revenue)** | | **NOT** | Excludes results matching the specified condition. | **name:(Civil Procedure) NOT name:(Tax and Revenue)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Tax and Revenue\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Civil Procedure\" OR name:\"Tax and Revenue\") AND caseTypeGroupId:\"CTYGSpWaVityBQndsv\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseTypeGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseTypeGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_type_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_type_groups_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseTypeGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseTypeGroupResponse]:

        """Case Type Group Objects.

        Fetch the list of case type groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Tax and Revenue) AND caseTypeGroupId:CTYGSpWaVityBQndsv** | | **OR** | Returns results matching any specified condition. | **name:(Civil Procedure) OR name:(Tax and Revenue)** | | **NOT** | Excludes results matching the specified condition. | **name:(Civil Procedure) NOT name:(Tax and Revenue)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Tax and Revenue\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Civil Procedure\" OR name:\"Tax and Revenue\") AND caseTypeGroupId:\"CTYGSpWaVityBQndsv\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseTypeGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseTypeGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_type_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_type_groups_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseTypeGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Type Group Objects.

        Fetch the list of case type groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Tax and Revenue) AND caseTypeGroupId:CTYGSpWaVityBQndsv** | | **OR** | Returns results matching any specified condition. | **name:(Civil Procedure) OR name:(Tax and Revenue)** | | **NOT** | Excludes results matching the specified condition. | **name:(Civil Procedure) NOT name:(Tax and Revenue)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Tax and Revenue\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Civil Procedure\" OR name:\"Tax and Revenue\") AND caseTypeGroupId:\"CTYGSpWaVityBQndsv\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseTypeGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseTypeGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_type_groups_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_types(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseTypeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseTypeResponse]:

        """Case Type Object.

        Fetch the list of case types supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Tax Claim) AND caseTypeId:CTYPoLU7sWaGjWtkBx** | | **OR** | Returns results matching any specified condition. | **name:(Wage Claim) OR name:(Tax Claim)** | | **NOT** | Excludes results matching the specified condition. | **name:(Wage Claim) NOT name:(Tax Claim)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Tax Claim\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Wage Claim\" OR name:\"Tax Claim\") AND caseTypeId:\"CTYPoLU7sWaGjWtkBx\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseTypeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseTypeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_types_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_types_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseTypeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseTypeResponse]:

        """Case Type Object.

        Fetch the list of case types supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Tax Claim) AND caseTypeId:CTYPoLU7sWaGjWtkBx** | | **OR** | Returns results matching any specified condition. | **name:(Wage Claim) OR name:(Tax Claim)** | | **NOT** | Excludes results matching the specified condition. | **name:(Wage Claim) NOT name:(Tax Claim)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Tax Claim\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Wage Claim\" OR name:\"Tax Claim\") AND caseTypeId:\"CTYPoLU7sWaGjWtkBx\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseTypeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseTypeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_case_types_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_types_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseTypeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Type Object.

        Fetch the list of case types supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Tax Claim) AND caseTypeId:CTYPoLU7sWaGjWtkBx** | | **OR** | Returns results matching any specified condition. | **name:(Wage Claim) OR name:(Tax Claim)** | | **NOT** | Excludes results matching the specified condition. | **name:(Wage Claim) NOT name:(Tax Claim)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Tax Claim\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Wage Claim\" OR name:\"Tax Claim\") AND caseTypeId:\"CTYPoLU7sWaGjWtkBx\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseTypeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseTypeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_case_types_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_cases_class(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseClassQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseClassResponse]:

        """Case Class Objects.

        Fetch the list of case classes supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Civil) AND caseClassId:CSCLNjbKTN7Yfo2wdb** | | **OR** | Returns results matching any specified condition. | **name:(Civil) OR name:(Criminal)** | | **NOT** | Excludes results matching the specified condition. | **name:(Civil) NOT name:(Criminal)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Civil\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Civil\" OR name:\"Criminal\") AND caseClassId:\"CSCLNjbKTN7Yfo2wdb\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseClassQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseClassQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_cases_class_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_cases_class_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseClassQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseClassResponse]:

        """Case Class Objects.

        Fetch the list of case classes supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Civil) AND caseClassId:CSCLNjbKTN7Yfo2wdb** | | **OR** | Returns results matching any specified condition. | **name:(Civil) OR name:(Criminal)** | | **NOT** | Excludes results matching the specified condition. | **name:(Civil) NOT name:(Criminal)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Civil\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Civil\" OR name:\"Criminal\") AND caseClassId:\"CSCLNjbKTN7Yfo2wdb\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseClassQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseClassQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_cases_class_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_cases_class_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseClassQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Class Objects.

        Fetch the list of case classes supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Civil) AND caseClassId:CSCLNjbKTN7Yfo2wdb** | | **OR** | Returns results matching any specified condition. | **name:(Civil) OR name:(Criminal)** | | **NOT** | Excludes results matching the specified condition. | **name:(Civil) NOT name:(Criminal)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Civil\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Civil\" OR name:\"Criminal\") AND caseClassId:\"CSCLNjbKTN7Yfo2wdb\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseClassQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseClassQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_cases_class_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_cases_status(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseStatusResponse]:

        """Case Status Object.

        Fetch the list of case status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Reopened) AND caseStatusId:CSSTWv7ZhQv5kEW5rW** | | **OR** | Returns results matching any specified condition. | **name:(Pending) OR name:(Reopened)** | | **NOT** | Excludes results matching the specified condition. | **name:(Pending) NOT name:(Reopened)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Reopened\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Pending\" OR name:\"Reopened\") AND caseStatusId:\"CSSTWv7ZhQv5kEW5rW\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_cases_status_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_cases_status_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseStatusResponse]:

        """Case Status Object.

        Fetch the list of case status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Reopened) AND caseStatusId:CSSTWv7ZhQv5kEW5rW** | | **OR** | Returns results matching any specified condition. | **name:(Pending) OR name:(Reopened)** | | **NOT** | Excludes results matching the specified condition. | **name:(Pending) NOT name:(Reopened)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Reopened\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Pending\" OR name:\"Reopened\") AND caseStatusId:\"CSSTWv7ZhQv5kEW5rW\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_cases_status_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_cases_status_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseStatusQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Case Status Object.

        Fetch the list of case status supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Reopened) AND caseStatusId:CSSTWv7ZhQv5kEW5rW** | | **OR** | Returns results matching any specified condition. | **name:(Pending) OR name:(Reopened)** | | **NOT** | Excludes results matching the specified condition. | **name:(Pending) NOT name:(Reopened)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Reopened\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Pending\" OR name:\"Reopened\") AND caseStatusId:\"CSSTWv7ZhQv5kEW5rW\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CaseStatusQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CaseStatusQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_cases_status_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_counsel_role(
        counsel_role_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The counselRoleId value of the desired counsel role.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CounselRole]:

        """Counsel Role Object for given Counsel Role Id.

        Fetch the details of the specific counsel role. 
        :param counsel_role_id: The counselRoleId value of the desired counsel role. (required)
        :type counsel_role_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_counsel_role_with_http_info(workspace_id = unicourt.WORKSPACE_ID, counsel_role_id = counsel_role_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_counsel_role_with_http_info(
        counsel_role_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The counselRoleId value of the desired counsel role.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CounselRole]:

        """Counsel Role Object for given Counsel Role Id.

        Fetch the details of the specific counsel role. 
        :param counsel_role_id: The counselRoleId value of the desired counsel role. (required)
        :type counsel_role_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_counsel_role_with_http_info(workspace_id = unicourt.WORKSPACE_ID, counsel_role_id = counsel_role_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_counsel_role_without_preload_content(
        counsel_role_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The counselRoleId value of the desired counsel role.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Counsel Role Object for given Counsel Role Id.

        Fetch the details of the specific counsel role. 
        :param counsel_role_id: The counselRoleId value of the desired counsel role. (required)
        :type counsel_role_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_counsel_role_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, counsel_role_id = counsel_role_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_counsel_roles(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CounselRoleQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CounselRoleResponse]:

        """Counsel Role Object.

        Fetch the list of counsel roles supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Lead Counsel) AND counselRoleId:CNRLCux89DCXMWrm9y** | | **OR** | Returns results matching any specified condition. | **name:(Lead Counsel) OR name:(Pro Hac Vice)** | | **NOT** | Excludes results matching the specified condition. | **name:(Lead Counsel) NOT name:(Pro Hac Vice)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Lead Counsel\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Lead Counsel\" OR name:\"Pro Hac Vice\") AND counselRoleId:\"CNRLCux89DCXMWrm9y\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CounselRoleQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CounselRoleQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_counsel_roles_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_counsel_roles_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CounselRoleQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CounselRoleResponse]:

        """Counsel Role Object.

        Fetch the list of counsel roles supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Lead Counsel) AND counselRoleId:CNRLCux89DCXMWrm9y** | | **OR** | Returns results matching any specified condition. | **name:(Lead Counsel) OR name:(Pro Hac Vice)** | | **NOT** | Excludes results matching the specified condition. | **name:(Lead Counsel) NOT name:(Pro Hac Vice)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Lead Counsel\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Lead Counsel\" OR name:\"Pro Hac Vice\") AND counselRoleId:\"CNRLCux89DCXMWrm9y\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CounselRoleQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CounselRoleQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_counsel_roles_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_counsel_roles_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `CounselRoleQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Counsel Role Object.

        Fetch the list of counsel roles supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Lead Counsel) AND counselRoleId:CNRLCux89DCXMWrm9y** | | **OR** | Returns results matching any specified condition. | **name:(Lead Counsel) OR name:(Pro Hac Vice)** | | **NOT** | Excludes results matching the specified condition. | **name:(Lead Counsel) NOT name:(Pro Hac Vice)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Lead Counsel\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Lead Counsel\" OR name:\"Pro Hac Vice\") AND counselRoleId:\"CNRLCux89DCXMWrm9y\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> CounselRoleQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `CounselRoleQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_counsel_roles_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_judge_role(
        judge_role_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The judgeRoleId of the judge role to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[JudgeRole]:

        """Judge Role Object for the provided judgeRoleId.

        Fetch the details of the specific judge role. 
        :param judge_role_id: The judgeRoleId of the judge role to be retrieved. (required)
        :type judge_role_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_judge_role_with_http_info(workspace_id = unicourt.WORKSPACE_ID, judge_role_id = judge_role_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_judge_role_with_http_info(
        judge_role_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The judgeRoleId of the judge role to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[JudgeRole]:

        """Judge Role Object for the provided judgeRoleId.

        Fetch the details of the specific judge role. 
        :param judge_role_id: The judgeRoleId of the judge role to be retrieved. (required)
        :type judge_role_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_judge_role_with_http_info(workspace_id = unicourt.WORKSPACE_ID, judge_role_id = judge_role_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_judge_role_without_preload_content(
        judge_role_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The judgeRoleId of the judge role to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Judge Role Object for the provided judgeRoleId.

        Fetch the details of the specific judge role. 
        :param judge_role_id: The judgeRoleId of the judge role to be retrieved. (required)
        :type judge_role_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_judge_role_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, judge_role_id = judge_role_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_judge_roles(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `JudgeRoleQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[JudgeRoleResponse]:

        """Judge Role Object.

        Fetch the list of judge roles supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Judge) AND judgeRoleId:JDRLkwrfzkDJUvxpN9** | | **OR** | Returns results matching any specified condition. | **name:(Referral Judge) OR name:(Judge)** | | **NOT** | Excludes results matching the specified condition. | **name:(Referral Judge) NOT name:(Judge)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Judge\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Referral Judge\" OR name:\"Judge\") AND judgeRoleId:\"JDRLkwrfzkDJUvxpN9\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> JudgeRoleQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `JudgeRoleQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_judge_roles_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_judge_roles_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `JudgeRoleQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[JudgeRoleResponse]:

        """Judge Role Object.

        Fetch the list of judge roles supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Judge) AND judgeRoleId:JDRLkwrfzkDJUvxpN9** | | **OR** | Returns results matching any specified condition. | **name:(Referral Judge) OR name:(Judge)** | | **NOT** | Excludes results matching the specified condition. | **name:(Referral Judge) NOT name:(Judge)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Judge\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Referral Judge\" OR name:\"Judge\") AND judgeRoleId:\"JDRLkwrfzkDJUvxpN9\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> JudgeRoleQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `JudgeRoleQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_judge_roles_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_judge_roles_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `JudgeRoleQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Judge Role Object.

        Fetch the list of judge roles supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Judge) AND judgeRoleId:JDRLkwrfzkDJUvxpN9** | | **OR** | Returns results matching any specified condition. | **name:(Referral Judge) OR name:(Judge)** | | **NOT** | Excludes results matching the specified condition. | **name:(Referral Judge) NOT name:(Judge)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Judge\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Referral Judge\" OR name:\"Judge\") AND judgeRoleId:\"JDRLkwrfzkDJUvxpN9\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> JudgeRoleQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `JudgeRoleQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_judge_roles_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_outcome(
        motion_outcome_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionOutcomeId of the motion outcome to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[MotionOutcome]:

        """Motion Outcome details for the provided motionOutcomeId.

        Fetch the details of the specific motion outcome. 
        :param motion_outcome_id: The motionOutcomeId of the motion outcome to be retrieved. (required)
        :type motion_outcome_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_outcome_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_outcome_id = motion_outcome_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_outcome_with_http_info(
        motion_outcome_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionOutcomeId of the motion outcome to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[MotionOutcome]:

        """Motion Outcome details for the provided motionOutcomeId.

        Fetch the details of the specific motion outcome. 
        :param motion_outcome_id: The motionOutcomeId of the motion outcome to be retrieved. (required)
        :type motion_outcome_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_motion_outcome_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_outcome_id = motion_outcome_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_motion_outcome_without_preload_content(
        motion_outcome_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionOutcomeId of the motion outcome to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Motion Outcome details for the provided motionOutcomeId.

        Fetch the details of the specific motion outcome. 
        :param motion_outcome_id: The motionOutcomeId of the motion outcome to be retrieved. (required)
        :type motion_outcome_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_outcome_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_outcome_id = motion_outcome_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_outcome_group(
        motion_outcome_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionOutcomeGroupId of the motion outcome group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[MotionOutcomeGroup]:

        """Motion Outcome Group details for the provided motionOutcomeGroupId.

        Fetch the details of the specific motion outcome group. 
        :param motion_outcome_group_id: The motionOutcomeGroupId of the motion outcome group to be retrieved. (required)
        :type motion_outcome_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_outcome_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_outcome_group_id = motion_outcome_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_outcome_group_with_http_info(
        motion_outcome_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionOutcomeGroupId of the motion outcome group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[MotionOutcomeGroup]:

        """Motion Outcome Group details for the provided motionOutcomeGroupId.

        Fetch the details of the specific motion outcome group. 
        :param motion_outcome_group_id: The motionOutcomeGroupId of the motion outcome group to be retrieved. (required)
        :type motion_outcome_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_motion_outcome_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_outcome_group_id = motion_outcome_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_motion_outcome_group_without_preload_content(
        motion_outcome_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionOutcomeGroupId of the motion outcome group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Motion Outcome Group details for the provided motionOutcomeGroupId.

        Fetch the details of the specific motion outcome group. 
        :param motion_outcome_group_id: The motionOutcomeGroupId of the motion outcome group to be retrieved. (required)
        :type motion_outcome_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_outcome_group_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_outcome_group_id = motion_outcome_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_outcome_groups(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionOutcomeGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[MotionOutcomeGroupResponse]:

        """Motion Outcome Group Objects.

        Fetch the list of motion outcome groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:Outcome AND motionOutcomeGroupId:MOCGLHZaLDqjM4wxDg** | | **OR** | Returns results matching any specified condition. | **name:Outcome OR name:Domain** | | **NOT** | Excludes results matching the specified condition. | **name:Outcome NOT name:Domain** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Outcome\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Outcome\" OR name:\"Domain\") AND motionOutcomeGroupId:\"MOCGLHZaLDqjM4wxDg\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionOutcomeGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionOutcomeGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_outcome_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_outcome_groups_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionOutcomeGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[MotionOutcomeGroupResponse]:

        """Motion Outcome Group Objects.

        Fetch the list of motion outcome groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:Outcome AND motionOutcomeGroupId:MOCGLHZaLDqjM4wxDg** | | **OR** | Returns results matching any specified condition. | **name:Outcome OR name:Domain** | | **NOT** | Excludes results matching the specified condition. | **name:Outcome NOT name:Domain** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Outcome\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Outcome\" OR name:\"Domain\") AND motionOutcomeGroupId:\"MOCGLHZaLDqjM4wxDg\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionOutcomeGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionOutcomeGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_motion_outcome_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_motion_outcome_groups_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionOutcomeGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Motion Outcome Group Objects.

        Fetch the list of motion outcome groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:Outcome AND motionOutcomeGroupId:MOCGLHZaLDqjM4wxDg** | | **OR** | Returns results matching any specified condition. | **name:Outcome OR name:Domain** | | **NOT** | Excludes results matching the specified condition. | **name:Outcome NOT name:Domain** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Outcome\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Outcome\" OR name:\"Domain\") AND motionOutcomeGroupId:\"MOCGLHZaLDqjM4wxDg\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionOutcomeGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionOutcomeGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_outcome_groups_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_outcomes(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionOutcomeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[MotionOutcomeResponse]:

        """Motion Outcome Objects.

        Fetch the list of motion outcomes supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:Granted AND motionOutcomeId:MOCN335wQFJp3M6nzD** | | **OR** | Returns results matching any specified condition. | **name:Granted OR name:Enforced** | | **NOT** | Excludes results matching the specified condition. | **name:Granted NOT name:Enforced** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Granted\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Granted\" OR name:\"Enforced\") AND motionOutcomeId:\"MOCN335wQFJp3M6nzD\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionOutcomeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionOutcomeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_outcomes_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_outcomes_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionOutcomeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[MotionOutcomeResponse]:

        """Motion Outcome Objects.

        Fetch the list of motion outcomes supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:Granted AND motionOutcomeId:MOCN335wQFJp3M6nzD** | | **OR** | Returns results matching any specified condition. | **name:Granted OR name:Enforced** | | **NOT** | Excludes results matching the specified condition. | **name:Granted NOT name:Enforced** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Granted\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Granted\" OR name:\"Enforced\") AND motionOutcomeId:\"MOCN335wQFJp3M6nzD\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionOutcomeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionOutcomeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_motion_outcomes_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_motion_outcomes_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionOutcomeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Motion Outcome Objects.

        Fetch the list of motion outcomes supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:Granted AND motionOutcomeId:MOCN335wQFJp3M6nzD** | | **OR** | Returns results matching any specified condition. | **name:Granted OR name:Enforced** | | **NOT** | Excludes results matching the specified condition. | **name:Granted NOT name:Enforced** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Granted\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Granted\" OR name:\"Enforced\") AND motionOutcomeId:\"MOCN335wQFJp3M6nzD\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionOutcomeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionOutcomeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_outcomes_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_type(
        motion_type_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionTypeId of the motion type to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[MotionType]:

        """Motion Type details for the provided motionTypeId.

        Fetch the details of the specific motion type. 
        :param motion_type_id: The motionTypeId of the motion type to be retrieved. (required)
        :type motion_type_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_type_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_type_id = motion_type_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_type_with_http_info(
        motion_type_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionTypeId of the motion type to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[MotionType]:

        """Motion Type details for the provided motionTypeId.

        Fetch the details of the specific motion type. 
        :param motion_type_id: The motionTypeId of the motion type to be retrieved. (required)
        :type motion_type_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_motion_type_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_type_id = motion_type_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_motion_type_without_preload_content(
        motion_type_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionTypeId of the motion type to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Motion Type details for the provided motionTypeId.

        Fetch the details of the specific motion type. 
        :param motion_type_id: The motionTypeId of the motion type to be retrieved. (required)
        :type motion_type_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_type_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_type_id = motion_type_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_type_categories(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeCategoryQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[MotionTypeCategoryResponse]:

        """Motion Type Category Objects.

        Fetch the list of motion type categories supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Case Management Motions) AND motionTypeCategoryId:MTNCZN3DHeV9eKveSn** | | **OR** | Returns results matching any specified condition. | **name:(Case Management Motions) OR name:(Case Scheduling)** | | **NOT** | Excludes results matching the specified condition. | **name:(Case Management Motions) NOT name:(Case Scheduling)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Case Scheduling\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Case Management Motions\" OR name:\"Case Scheduling\") AND motionTypeCategoryId:\"MTNCZN3DHeV9eKveSn\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionTypeCategoryQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeCategoryQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_type_categories_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_type_categories_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeCategoryQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[MotionTypeCategoryResponse]:

        """Motion Type Category Objects.

        Fetch the list of motion type categories supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Case Management Motions) AND motionTypeCategoryId:MTNCZN3DHeV9eKveSn** | | **OR** | Returns results matching any specified condition. | **name:(Case Management Motions) OR name:(Case Scheduling)** | | **NOT** | Excludes results matching the specified condition. | **name:(Case Management Motions) NOT name:(Case Scheduling)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Case Scheduling\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Case Management Motions\" OR name:\"Case Scheduling\") AND motionTypeCategoryId:\"MTNCZN3DHeV9eKveSn\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionTypeCategoryQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeCategoryQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_motion_type_categories_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_motion_type_categories_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeCategoryQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Motion Type Category Objects.

        Fetch the list of motion type categories supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Case Management Motions) AND motionTypeCategoryId:MTNCZN3DHeV9eKveSn** | | **OR** | Returns results matching any specified condition. | **name:(Case Management Motions) OR name:(Case Scheduling)** | | **NOT** | Excludes results matching the specified condition. | **name:(Case Management Motions) NOT name:(Case Scheduling)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Case Scheduling\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Case Management Motions\" OR name:\"Case Scheduling\") AND motionTypeCategoryId:\"MTNCZN3DHeV9eKveSn\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionTypeCategoryQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeCategoryQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_type_categories_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_type_category(
        motion_type_category_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionTypeCategoryId of the motion type category to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[MotionTypeCategory]:

        """Motion Type Category details for the provided motionTypeCategoryId.

        Fetch the details of the specific motion type category. 
        :param motion_type_category_id: The motionTypeCategoryId of the motion type category to be retrieved. (required)
        :type motion_type_category_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_type_category_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_type_category_id = motion_type_category_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_type_category_with_http_info(
        motion_type_category_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionTypeCategoryId of the motion type category to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[MotionTypeCategory]:

        """Motion Type Category details for the provided motionTypeCategoryId.

        Fetch the details of the specific motion type category. 
        :param motion_type_category_id: The motionTypeCategoryId of the motion type category to be retrieved. (required)
        :type motion_type_category_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_motion_type_category_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_type_category_id = motion_type_category_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_motion_type_category_without_preload_content(
        motion_type_category_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionTypeCategoryId of the motion type category to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Motion Type Category details for the provided motionTypeCategoryId.

        Fetch the details of the specific motion type category. 
        :param motion_type_category_id: The motionTypeCategoryId of the motion type category to be retrieved. (required)
        :type motion_type_category_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_type_category_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_type_category_id = motion_type_category_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_type_group(
        motion_type_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionTypeGroupId of the motion type group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[MotionTypeGroup]:

        """Motion Type Group details for the provided motionTypeGroupId.

        Fetch the details of the specific motion type group. 
        :param motion_type_group_id: The motionTypeGroupId of the motion type group to be retrieved. (required)
        :type motion_type_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_type_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_type_group_id = motion_type_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_type_group_with_http_info(
        motion_type_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionTypeGroupId of the motion type group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[MotionTypeGroup]:

        """Motion Type Group details for the provided motionTypeGroupId.

        Fetch the details of the specific motion type group. 
        :param motion_type_group_id: The motionTypeGroupId of the motion type group to be retrieved. (required)
        :type motion_type_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_motion_type_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_type_group_id = motion_type_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_motion_type_group_without_preload_content(
        motion_type_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The motionTypeGroupId of the motion type group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Motion Type Group details for the provided motionTypeGroupId.

        Fetch the details of the specific motion type group. 
        :param motion_type_group_id: The motionTypeGroupId of the motion type group to be retrieved. (required)
        :type motion_type_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_type_group_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, motion_type_group_id = motion_type_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_type_groups(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[MotionTypeGroupResponse]:

        """Motion Type Group Objects.

        Fetch the list of motion type groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Motion for Default) AND motionTypeGroupId:MTNG7pdrTidQ9pF7Qz** | | **OR** | Returns results matching any specified condition. | **name:(Motion for Contempt) OR name:(Motion for Default)** | | **NOT** | Excludes results matching the specified condition. | **name:(Motion for Contempt) NOT name:(Motion for Default)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Motion for Contempt\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Motion for Contempt\" OR name:\"Motion for Default\") AND motionTypeGroupId:\"MTNG7pdrTidQ9pF7Qz\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionTypeGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_type_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_type_groups_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[MotionTypeGroupResponse]:

        """Motion Type Group Objects.

        Fetch the list of motion type groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Motion for Default) AND motionTypeGroupId:MTNG7pdrTidQ9pF7Qz** | | **OR** | Returns results matching any specified condition. | **name:(Motion for Contempt) OR name:(Motion for Default)** | | **NOT** | Excludes results matching the specified condition. | **name:(Motion for Contempt) NOT name:(Motion for Default)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Motion for Contempt\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Motion for Contempt\" OR name:\"Motion for Default\") AND motionTypeGroupId:\"MTNG7pdrTidQ9pF7Qz\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionTypeGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_motion_type_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_motion_type_groups_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Motion Type Group Objects.

        Fetch the list of motion type groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Motion for Default) AND motionTypeGroupId:MTNG7pdrTidQ9pF7Qz** | | **OR** | Returns results matching any specified condition. | **name:(Motion for Contempt) OR name:(Motion for Default)** | | **NOT** | Excludes results matching the specified condition. | **name:(Motion for Contempt) NOT name:(Motion for Default)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Motion for Contempt\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Motion for Contempt\" OR name:\"Motion for Default\") AND motionTypeGroupId:\"MTNG7pdrTidQ9pF7Qz\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionTypeGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_type_groups_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_types(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[MotionTypeResponse]:

        """Motion Type Objects.

        Fetch the list of motion types supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Motion for Reargument) AND motionTypeId:MTNSnzafeycMQZenij** | | **OR** | Returns results matching any specified condition. | **name:(Motion for Reargument) OR name:(Motion for Service by Publication)** | | **NOT** | Excludes results matching the specified condition. | **name:(Motion for Reargument) NOT name:(Motion for Service by Publication)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Motion for Reargument\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Motion for Reargument\" OR name:\"Motion for Service by Publication\") AND motionTypeId:\"MTNSnzafeycMQZenij\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionTypeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_types_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_motion_types_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[MotionTypeResponse]:

        """Motion Type Objects.

        Fetch the list of motion types supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Motion for Reargument) AND motionTypeId:MTNSnzafeycMQZenij** | | **OR** | Returns results matching any specified condition. | **name:(Motion for Reargument) OR name:(Motion for Service by Publication)** | | **NOT** | Excludes results matching the specified condition. | **name:(Motion for Reargument) NOT name:(Motion for Service by Publication)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Motion for Reargument\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Motion for Reargument\" OR name:\"Motion for Service by Publication\") AND motionTypeId:\"MTNSnzafeycMQZenij\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionTypeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_motion_types_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_motion_types_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Motion Type Objects.

        Fetch the list of motion types supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Motion for Reargument) AND motionTypeId:MTNSnzafeycMQZenij** | | **OR** | Returns results matching any specified condition. | **name:(Motion for Reargument) OR name:(Motion for Service by Publication)** | | **NOT** | Excludes results matching the specified condition. | **name:(Motion for Reargument) NOT name:(Motion for Service by Publication)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Motion for Reargument\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Motion for Reargument\" OR name:\"Motion for Service by Publication\") AND motionTypeId:\"MTNSnzafeycMQZenij\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> MotionTypeQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `MotionTypeQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_motion_types_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_party_role(
        party_role_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The partyRoleId of the party role to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[PartyRole]:

        """Party Role Object.

        Fetch the details of the specific party role. 
        :param party_role_id: The partyRoleId of the party role to be retrieved. (required)
        :type party_role_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_party_role_with_http_info(workspace_id = unicourt.WORKSPACE_ID, party_role_id = party_role_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_party_role_with_http_info(
        party_role_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The partyRoleId of the party role to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[PartyRole]:

        """Party Role Object.

        Fetch the details of the specific party role. 
        :param party_role_id: The partyRoleId of the party role to be retrieved. (required)
        :type party_role_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_party_role_with_http_info(workspace_id = unicourt.WORKSPACE_ID, party_role_id = party_role_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_party_role_without_preload_content(
        party_role_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The partyRoleId of the party role to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Party Role Object.

        Fetch the details of the specific party role. 
        :param party_role_id: The partyRoleId of the party role to be retrieved. (required)
        :type party_role_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_party_role_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, party_role_id = party_role_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_party_role_group(
        party_role_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The partyRoleGroupId of the party role group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[PartyRoleGroup]:

        """Party Role Group Object.

        Fetch the details of the specific party role group. 
        :param party_role_group_id: The partyRoleGroupId of the party role group to be retrieved. (required)
        :type party_role_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_party_role_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, party_role_group_id = party_role_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_party_role_group_with_http_info(
        party_role_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The partyRoleGroupId of the party role group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[PartyRoleGroup]:

        """Party Role Group Object.

        Fetch the details of the specific party role group. 
        :param party_role_group_id: The partyRoleGroupId of the party role group to be retrieved. (required)
        :type party_role_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_party_role_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, party_role_group_id = party_role_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_party_role_group_without_preload_content(
        party_role_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The partyRoleGroupId of the party role group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Party Role Group Object.

        Fetch the details of the specific party role group. 
        :param party_role_group_id: The partyRoleGroupId of the party role group to be retrieved. (required)
        :type party_role_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_party_role_group_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, party_role_group_id = party_role_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_party_role_groups(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `PartyRoleGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[PartyRoleGroupResponse]:

        """Party Role Group Object.

        Fetch the list of party role groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Party Offensive) AND partyRoleGroupId:PTYGBnjxbx6tKNfVEP** | | **OR** | Returns results matching any specified condition. | **name:(Party Defensive) OR name:(Party Offensive)** | | **NOT** | Excludes results matching the specified condition. | **name:(Party Defensive) NOT name:(Party Offensive)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Party Offensive\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Party Defensive\" OR name:\"Party Offensive\") AND partyRoleGroupId:\"PTYGBnjxbx6tKNfVEP\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> PartyRoleGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `PartyRoleGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_party_role_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_party_role_groups_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `PartyRoleGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[PartyRoleGroupResponse]:

        """Party Role Group Object.

        Fetch the list of party role groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Party Offensive) AND partyRoleGroupId:PTYGBnjxbx6tKNfVEP** | | **OR** | Returns results matching any specified condition. | **name:(Party Defensive) OR name:(Party Offensive)** | | **NOT** | Excludes results matching the specified condition. | **name:(Party Defensive) NOT name:(Party Offensive)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Party Offensive\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Party Defensive\" OR name:\"Party Offensive\") AND partyRoleGroupId:\"PTYGBnjxbx6tKNfVEP\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> PartyRoleGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `PartyRoleGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_party_role_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_party_role_groups_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `PartyRoleGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Party Role Group Object.

        Fetch the list of party role groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Party Offensive) AND partyRoleGroupId:PTYGBnjxbx6tKNfVEP** | | **OR** | Returns results matching any specified condition. | **name:(Party Defensive) OR name:(Party Offensive)** | | **NOT** | Excludes results matching the specified condition. | **name:(Party Defensive) NOT name:(Party Offensive)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Party Offensive\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Party Defensive\" OR name:\"Party Offensive\") AND partyRoleGroupId:\"PTYGBnjxbx6tKNfVEP\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> PartyRoleGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `PartyRoleGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_party_role_groups_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_party_roles(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `PartyRoleQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[PartyRoleResponse]:

        """Party Role Object.

        Fetch the list of party roles supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Administrator) AND partyRoleId:PTYRVRgMKueGmhnxRN** | | **OR** | Returns results matching any specified condition. | **name:(Requestor) OR name:(Administrator)** | | **NOT** | Excludes results matching the specified condition. | **name:(Requestor) NOT name:(Administrator)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Administrator\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Requestor\" OR name:\"Administrator\") AND partyRoleId:\"PTYRVRgMKueGmhnxRN\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> PartyRoleQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `PartyRoleQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_party_roles_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_party_roles_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `PartyRoleQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[PartyRoleResponse]:

        """Party Role Object.

        Fetch the list of party roles supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Administrator) AND partyRoleId:PTYRVRgMKueGmhnxRN** | | **OR** | Returns results matching any specified condition. | **name:(Requestor) OR name:(Administrator)** | | **NOT** | Excludes results matching the specified condition. | **name:(Requestor) NOT name:(Administrator)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Administrator\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Requestor\" OR name:\"Administrator\") AND partyRoleId:\"PTYRVRgMKueGmhnxRN\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> PartyRoleQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `PartyRoleQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_party_roles_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_party_roles_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `PartyRoleQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Party Role Object.

        Fetch the list of party roles supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Administrator) AND partyRoleId:PTYRVRgMKueGmhnxRN** | | **OR** | Returns results matching any specified condition. | **name:(Requestor) OR name:(Administrator)** | | **NOT** | Excludes results matching the specified condition. | **name:(Requestor) NOT name:(Administrator)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Administrator\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Requestor\" OR name:\"Administrator\") AND partyRoleId:\"PTYRVRgMKueGmhnxRN\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> PartyRoleQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `PartyRoleQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_party_roles_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_procedural_activities(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `ProceduralActivityQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[ProceduralActivityResponse]:

        """Procedural Activity Objects.

        Fetch the list of procedural activities supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Advanced) AND proceduralActivityId:PACTPqJT2QiDhgZQvc** | | **OR** | Returns results matching any specified condition. | **name:(Advanced) OR name:(Continued)** | | **NOT** | Excludes results matching the specified condition. | **name:(Advanced) NOT name:(Continued)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Advanced\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Advanced\" OR name:\"Continued\") AND proceduralActivityId:\"PACTPqJT2QiDhgZQvc\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> ProceduralActivityQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `ProceduralActivityQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_procedural_activities_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_procedural_activities_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `ProceduralActivityQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[ProceduralActivityResponse]:

        """Procedural Activity Objects.

        Fetch the list of procedural activities supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Advanced) AND proceduralActivityId:PACTPqJT2QiDhgZQvc** | | **OR** | Returns results matching any specified condition. | **name:(Advanced) OR name:(Continued)** | | **NOT** | Excludes results matching the specified condition. | **name:(Advanced) NOT name:(Continued)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Advanced\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Advanced\" OR name:\"Continued\") AND proceduralActivityId:\"PACTPqJT2QiDhgZQvc\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> ProceduralActivityQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `ProceduralActivityQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_procedural_activities_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_procedural_activities_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `ProceduralActivityQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Procedural Activity Objects.

        Fetch the list of procedural activities supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Advanced) AND proceduralActivityId:PACTPqJT2QiDhgZQvc** | | **OR** | Returns results matching any specified condition. | **name:(Advanced) OR name:(Continued)** | | **NOT** | Excludes results matching the specified condition. | **name:(Advanced) NOT name:(Continued)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Advanced\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Advanced\" OR name:\"Continued\") AND proceduralActivityId:\"PACTPqJT2QiDhgZQvc\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> ProceduralActivityQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `ProceduralActivityQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_procedural_activities_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_procedural_activity(
        procedural_activity_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The proceduralActivityId of the procedural activity to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[ProceduralActivity]:

        """Procedural Activity details for the provided proceduralActivityId.

        Fetch the details of the specific procedural activity. 
        :param procedural_activity_id: The proceduralActivityId of the procedural activity to be retrieved. (required)
        :type procedural_activity_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_procedural_activity_with_http_info(workspace_id = unicourt.WORKSPACE_ID, procedural_activity_id = procedural_activity_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_procedural_activity_with_http_info(
        procedural_activity_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The proceduralActivityId of the procedural activity to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[ProceduralActivity]:

        """Procedural Activity details for the provided proceduralActivityId.

        Fetch the details of the specific procedural activity. 
        :param procedural_activity_id: The proceduralActivityId of the procedural activity to be retrieved. (required)
        :type procedural_activity_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_procedural_activity_with_http_info(workspace_id = unicourt.WORKSPACE_ID, procedural_activity_id = procedural_activity_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_procedural_activity_without_preload_content(
        procedural_activity_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The proceduralActivityId of the procedural activity to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Procedural Activity details for the provided proceduralActivityId.

        Fetch the details of the specific procedural activity. 
        :param procedural_activity_id: The proceduralActivityId of the procedural activity to be retrieved. (required)
        :type procedural_activity_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_procedural_activity_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, procedural_activity_id = procedural_activity_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_procedural_activity_group(
        procedural_activity_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The proceduralActivityGroupId of the procedural activity group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[ProceduralActivityGroup]:

        """Procedural Activity Group details for the provided proceduralActivityGroupId.

        Fetch the details of the specific procedural activity group. 
        :param procedural_activity_group_id: The proceduralActivityGroupId of the procedural activity group to be retrieved. (required)
        :type procedural_activity_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_procedural_activity_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, procedural_activity_group_id = procedural_activity_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_procedural_activity_group_with_http_info(
        procedural_activity_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The proceduralActivityGroupId of the procedural activity group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[ProceduralActivityGroup]:

        """Procedural Activity Group details for the provided proceduralActivityGroupId.

        Fetch the details of the specific procedural activity group. 
        :param procedural_activity_group_id: The proceduralActivityGroupId of the procedural activity group to be retrieved. (required)
        :type procedural_activity_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_procedural_activity_group_with_http_info(workspace_id = unicourt.WORKSPACE_ID, procedural_activity_group_id = procedural_activity_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_procedural_activity_group_without_preload_content(
        procedural_activity_group_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="The proceduralActivityGroupId of the procedural activity group to be retrieved.")],
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Procedural Activity Group details for the provided proceduralActivityGroupId.

        Fetch the details of the specific procedural activity group. 
        :param procedural_activity_group_id: The proceduralActivityGroupId of the procedural activity group to be retrieved. (required)
        :type procedural_activity_group_id: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_procedural_activity_group_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, procedural_activity_group_id = procedural_activity_group_id, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_procedural_activity_groups(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `ProceduralActivityGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[ProceduralActivityGroupResponse]:

        """Procedural Activity Group Objects.

        Fetch the list of procedural activity groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Case Administration) AND proceduralActivityGroupId:PACGQma6a9b3xwpWzs** | | **OR** | Returns results matching any specified condition. | **name:(Case Administration) OR name:(Proceeding)** | | **NOT** | Excludes results matching the specified condition. | **name:(Case Administration) NOT name:(Proceeding)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Case Administration\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Case Administration\" OR name:\"Proceeding\") AND proceduralActivityGroupId:\"PACGQma6a9b3xwpWzs\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> ProceduralActivityGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `ProceduralActivityGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_procedural_activity_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_procedural_activity_groups_with_http_info(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `ProceduralActivityGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[ProceduralActivityGroupResponse]:

        """Procedural Activity Group Objects.

        Fetch the list of procedural activity groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Case Administration) AND proceduralActivityGroupId:PACGQma6a9b3xwpWzs** | | **OR** | Returns results matching any specified condition. | **name:(Case Administration) OR name:(Proceeding)** | | **NOT** | Excludes results matching the specified condition. | **name:(Case Administration) NOT name:(Proceeding)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Case Administration\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Case Administration\" OR name:\"Proceeding\") AND proceduralActivityGroupId:\"PACGQma6a9b3xwpWzs\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> ProceduralActivityGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `ProceduralActivityGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseMasterDataApi(api_client).get_procedural_activity_groups_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_procedural_activity_groups_without_preload_content(
        q: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=2000)]], Field(description="Query expressions must follow the logical operator rules described above and use only fields supported by the `ProceduralActivityGroupQueryObject` schema. ")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=100, strict=True, ge=1)]], Field(description="The page number of the results to be retrieved. - minimum: 1 - maximum: 100 ")] = None,
        sort: Annotated[Optional[Annotated[str, Field(min_length=4, strict=True, max_length=4)]], Field(description="The field according to which search results are to be sorted.")] = None,
        order: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=4)]], Field(description="Whether search results are to be shown in ascending or descending order.")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """Procedural Activity Group Objects.

        Fetch the list of procedural activity groups supported by UniCourt. <br><br>  **Note: A maximum of 15 operators are allowed in a single query.**  <br>  ## Supported Logical Operators | Operator | Description  | Example | | ------| ------|------| | **AND** | Returns results matching all specified conditions. | **name:(Case Administration) AND proceduralActivityGroupId:PACGQma6a9b3xwpWzs** | | **OR** | Returns results matching any specified condition. | **name:(Case Administration) OR name:(Proceeding)** | | **NOT** | Excludes results matching the specified condition. | **name:(Case Administration) NOT name:(Proceeding)** | | **\"[phrase]\"** | Searches for an exact phrase match. | **name:\"Case Administration\"** | | **( ... )** | Groups multiple conditions together. | **(name:\"Case Administration\" OR name:\"Proceeding\") AND proceduralActivityGroupId:\"PACGQma6a9b3xwpWzs\"** |  <br>  ## Supported Filter Fields  ### All supported filter query parameters for this API are defined in below schema section. Schema --> ProceduralActivityGroupQueryObject 
        :param q: Query expressions must follow the logical operator rules described above and use only fields supported by the `ProceduralActivityGroupQueryObject` schema. 
        :type q: str
        :param page_number: The page number of the results to be retrieved. - minimum: 1 - maximum: 100 
        :type page_number: int
        :param sort: The field according to which search results are to be sorted.
        :type sort: str
        :param order: Whether search results are to be shown in ascending or descending order.
        :type order: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseMasterDataApi(api_client).get_procedural_activity_groups_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, q = q, page_number = page_number, sort = sort, order = order, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
