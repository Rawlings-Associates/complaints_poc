import warnings
from pydantic import validate_call, Field, StrictFloat, StrictStr, StrictInt
from typing import Any, Dict, List, Optional, Tuple, Union
from typing_extensions import Annotated
from pydantic import Field, field_validator
from typing import Optional
from typing_extensions import Annotated
from unicourt.model.case_documents_histories import CaseDocumentsHistories
from unicourt.model.case_documents_history import CaseDocumentsHistory
from unicourt.model.case_histories import CaseHistories
from unicourt.model.counsel_associations_histories import CounselAssociationsHistories
from unicourt.model.counsel_associations_history import CounselAssociationsHistory
from unicourt.model.counsel_histories import CounselHistories
from unicourt.model.counsel_history import CounselHistory
from unicourt.model.docket_entries_histories import DocketEntriesHistories
from unicourt.model.docket_entries_history import DocketEntriesHistory
from unicourt.model.hearings_histories import HearingsHistories
from unicourt.model.hearings_history import HearingsHistory
from unicourt.model.judges_histories import JudgesHistories
from unicourt.model.judges_history import JudgesHistory
from unicourt.model.parties_histories import PartiesHistories
from unicourt.model.parties_history import PartiesHistory
from unicourt.model.party_counsel_associations_histories import PartyCounselAssociationsHistories
from unicourt.model.party_counsel_associations_history import PartyCounselAssociationsHistory
from unicourt.model.related_cases_histories import RelatedCasesHistories
from unicourt.model.related_cases_history import RelatedCasesHistory
from unicourt.model.tentative_rulings_histories import TentativeRulingsHistories
from unicourt.model.tentative_rulings_history import TentativeRulingsHistory
from unicourt.api_client import ApiClient, RequestSerialized
from unicourt.api_response import ApiResponse
from unicourt.rest import RESTResponseType
from unicourt.api.case_history_api import CaseHistoryApi
from unicourt.sdk_response import SdkResponse
import unicourt
from unicourt import utils
class CaseHistory:

    @staticmethod
    def get_case_documents_history_for_case(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseDocumentsHistories]:

        """History of CaseDocuments.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_case_documents_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_documents_history_for_case_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseDocumentsHistories]:

        """History of CaseDocuments.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_case_documents_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_documents_history_for_case_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of CaseDocuments.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_case_documents_history_for_case_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_documents_history_for_case_bylast_fetch_date_with_updates(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseDocumentsHistory]:

        """History of CaseDocuments By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_case_documents_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_documents_history_for_case_bylast_fetch_date_with_updates_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseDocumentsHistory]:

        """History of CaseDocuments By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_case_documents_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_documents_history_for_case_bylast_fetch_date_with_updates_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of CaseDocuments By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_case_documents_history_for_case_bylast_fetch_date_with_updates_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_history_by_id(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.    - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CaseHistories]:

        """History of Case parameters.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.    - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_case_history_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_case_history_by_id_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.    - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CaseHistories]:

        """History of Case parameters.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.    - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_case_history_by_id_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_case_history_by_id_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.    - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Case parameters.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.    - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_case_history_by_id_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_counsel_associations_history_for_case(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CounselAssociationsHistories]:

        """History of Counsel Associations.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_counsel_associations_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_counsel_associations_history_for_case_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CounselAssociationsHistories]:

        """History of Counsel Associations.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_counsel_associations_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_counsel_associations_history_for_case_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Counsel Associations.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_counsel_associations_history_for_case_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_counsel_associations_history_for_case_bylast_fetch_date_with_updates(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CounselAssociationsHistory]:

        """History of Counsel Associations by date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_counsel_associations_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_counsel_associations_history_for_case_bylast_fetch_date_with_updates_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CounselAssociationsHistory]:

        """History of Counsel Associations by date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_counsel_associations_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_counsel_associations_history_for_case_bylast_fetch_date_with_updates_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Counsel Associations by date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_counsel_associations_history_for_case_bylast_fetch_date_with_updates_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_counsel_history_for_case(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CounselHistories]:

        """History of Counsel.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_counsel_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_counsel_history_for_case_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CounselHistories]:

        """History of Counsel.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_counsel_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_counsel_history_for_case_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Counsel.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_counsel_history_for_case_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_counsel_history_for_case_bylast_fetch_date_with_updates(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[CounselHistory]:

        """History of Counsel By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_counsel_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_counsel_history_for_case_bylast_fetch_date_with_updates_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[CounselHistory]:

        """History of Counsel By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_counsel_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_counsel_history_for_case_bylast_fetch_date_with_updates_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Counsel By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_counsel_history_for_case_bylast_fetch_date_with_updates_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_docket_entries_history_for_case(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[DocketEntriesHistories]:

        """History of DocketEntries.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_docket_entries_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_docket_entries_history_for_case_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[DocketEntriesHistories]:

        """History of DocketEntries.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_docket_entries_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_docket_entries_history_for_case_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of DocketEntries.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_docket_entries_history_for_case_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_docket_entries_history_for_case_bylast_fetch_date_with_updates(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[DocketEntriesHistory]:

        """History of DocketEntries By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_docket_entries_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_docket_entries_history_for_case_bylast_fetch_date_with_updates_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[DocketEntriesHistory]:

        """History of DocketEntries By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_docket_entries_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_docket_entries_history_for_case_bylast_fetch_date_with_updates_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of DocketEntries By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_docket_entries_history_for_case_bylast_fetch_date_with_updates_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_hearing_history_for_case(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[HearingsHistories]:

        """History of Hearings.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_hearing_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_hearing_history_for_case_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[HearingsHistories]:

        """History of Hearings.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_hearing_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_hearing_history_for_case_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Hearings.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_hearing_history_for_case_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_hearing_history_for_case_bylast_fetch_date_with_updates(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[HearingsHistory]:

        """History of Hearings By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_hearing_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_hearing_history_for_case_bylast_fetch_date_with_updates_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[HearingsHistory]:

        """History of Hearings By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_hearing_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_hearing_history_for_case_bylast_fetch_date_with_updates_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Hearings By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_hearing_history_for_case_bylast_fetch_date_with_updates_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_judges_history_for_case(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[JudgesHistories]:

        """History of Judges.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_judges_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_judges_history_for_case_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[JudgesHistories]:

        """History of Judges.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_judges_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_judges_history_for_case_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Judges.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_judges_history_for_case_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_judges_history_for_case_bylast_fetch_date_with_updates(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[JudgesHistory]:

        """History of Judges By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_judges_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_judges_history_for_case_bylast_fetch_date_with_updates_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[JudgesHistory]:

        """History of Judges By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_judges_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_judges_history_for_case_bylast_fetch_date_with_updates_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Judges By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_judges_history_for_case_bylast_fetch_date_with_updates_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_parties_history_for_case(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[PartiesHistories]:

        """History of Parties.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_parties_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_parties_history_for_case_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[PartiesHistories]:

        """History of Parties.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_parties_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_parties_history_for_case_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Parties.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_parties_history_for_case_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_parties_history_for_case_bylast_fetch_date_with_updates(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[PartiesHistory]:

        """History of Parties By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_parties_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_parties_history_for_case_bylast_fetch_date_with_updates_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[PartiesHistory]:

        """History of Parties By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_parties_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_parties_history_for_case_bylast_fetch_date_with_updates_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Parties By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_parties_history_for_case_bylast_fetch_date_with_updates_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_party_counsel_associations_history_for_case(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[PartyCounselAssociationsHistories]:

        """History of PartyCounselAssociations.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_party_counsel_associations_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_party_counsel_associations_history_for_case_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[PartyCounselAssociationsHistories]:

        """History of PartyCounselAssociations.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_party_counsel_associations_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_party_counsel_associations_history_for_case_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of PartyCounselAssociations.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_party_counsel_associations_history_for_case_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_party_counsel_associations_history_for_case_bylast_fetch_date_with_updates(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[PartyCounselAssociationsHistory]:

        """History of PartyCounselAssociations By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_party_counsel_associations_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_party_counsel_associations_history_for_case_bylast_fetch_date_with_updates_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[PartyCounselAssociationsHistory]:

        """History of PartyCounselAssociations By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_party_counsel_associations_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_party_counsel_associations_history_for_case_bylast_fetch_date_with_updates_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which class")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of PartyCounselAssociations By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which class
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_party_counsel_associations_history_for_case_bylast_fetch_date_with_updates_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_related_case_history_for_case(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RelatedCasesHistories]:

        """History of RelatedCases.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_related_case_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_related_case_history_for_case_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[RelatedCasesHistories]:

        """History of RelatedCases.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_related_case_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_related_case_history_for_case_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of RelatedCases.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_related_case_history_for_case_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_related_case_history_for_case_bylast_fetch_date_with_updates(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which type")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RelatedCasesHistory]:

        """History of RelatedCases By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which type
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_related_case_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_related_case_history_for_case_bylast_fetch_date_with_updates_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which type")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[RelatedCasesHistory]:

        """History of RelatedCases By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which type
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_related_case_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_related_case_history_for_case_bylast_fetch_date_with_updates_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which type")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of RelatedCases By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which type
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_related_case_history_for_case_bylast_fetch_date_with_updates_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_tentative_rulings_history_for_case(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[TentativeRulingsHistories]:

        """History of Tentative Rulings.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_tentative_rulings_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_tentative_rulings_history_for_case_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[TentativeRulingsHistories]:

        """History of Tentative Rulings.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_tentative_rulings_history_for_case_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_tentative_rulings_history_for_case_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        from_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects from this date.")] = None,
        to_date: Annotated[Optional[Annotated[str, Field(min_length=25, strict=True, max_length=25)]], Field(description="If specified, The caseHistoryByDateArray will contain Case history objects upto this date.")] = None,
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Tentative Rulings.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param from_date: If specified, The caseHistoryByDateArray will contain Case history objects from this date.
        :type from_date: str
        :param to_date: If specified, The caseHistoryByDateArray will contain Case history objects upto this date.
        :type to_date: str
        :param page_number: Page number
        :type page_number: int
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_tentative_rulings_history_for_case_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, from_date = from_date, to_date = to_date, page_number = page_number, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_tentative_rulings_history_for_case_bylast_fetch_date_with_updates(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which type")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[TentativeRulingsHistory]:

        """History of Tentative Rulings By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which type
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_tentative_rulings_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)

    @staticmethod
    def get_tentative_rulings_history_for_case_bylast_fetch_date_with_updates_with_http_info(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which type")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> ApiResponse[TentativeRulingsHistory]:

        """History of Tentative Rulings By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which type
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            return CaseHistoryApi(api_client).get_tentative_rulings_history_for_case_bylast_fetch_date_with_updates_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)

    @staticmethod
    def get_tentative_rulings_history_for_case_bylast_fetch_date_with_updates_without_preload_content(
        case_id: Annotated[str, Field(min_length=18, strict=True, max_length=18, description="Case ID.   - minimum: 18   - maximum: 18 ")],
        last_fetch_date_with_updates: Annotated[str, Field(min_length=25, strict=True, max_length=25, description="History for which date")],
        page_number: Annotated[Optional[Annotated[int, Field(le=99999, strict=True, ge=0)]], Field(description="Page number")] = None,
        history_class: Annotated[Optional[Annotated[str, Field(min_length=3, strict=True, max_length=7)]], Field(description="History of which type")] = None,
        _request_timeout: Union[
            None,
            Annotated[StrictFloat, Field(gt=0)],
            Tuple[
                Annotated[StrictFloat, Field(gt=0)],
                Annotated[StrictFloat, Field(gt=0)]
            ]
        ] = None,
        _request_auth: Optional[Dict[StrictStr, Any]] = None,
        _content_type: Optional[StrictStr] = None,
        _headers: Optional[Dict[StrictStr, Any]] = None,
        _host_index: Annotated[StrictInt, Field(ge=0, le=0)] = 0,
    ) -> SdkResponse[RESTResponseType]:

        """History of Tentative Rulings By Date.

        The Case History API allows you to look up History of Case Parameters by caseId.
        :param case_id: Case ID.   - minimum: 18   - maximum: 18  (required)
        :type case_id: str
        :param last_fetch_date_with_updates: History for which date (required)
        :type last_fetch_date_with_updates: str
        :param page_number: Page number
        :type page_number: int
        :param history_class: History of which type
        :type history_class: str
        :param _request_timeout: timeout setting for this request. If one
                                 number provided, it will be total request
                                 timeout. It can also be a pair (tuple) of
                                 (connection, read) timeouts.
        :type _request_timeout: int, tuple(int, int), optional
        :param _request_auth: set to override the auth_settings for an a single
                              request; this effectively ignores the
                              authentication in the spec for a single request.
        :type _request_auth: dict, optional
        :param _content_type: force content-type for the request.
        :type _content_type: str, Optional
        :param _headers: set to override the headers for a single
                         request; this effectively ignores the headers
                         in the spec for a single request.
        :type _headers: dict, optional
        :param _host_index: set to override the host_index for a single
                            request; this effectively ignores the host_index
                            in the spec for a single request.
        :type _host_index: int, optional
        :return: Returns the result object.
        """
        with utils.api_client() as api_client:
            response = CaseHistoryApi(api_client).get_tentative_rulings_history_for_case_bylast_fetch_date_with_updates_without_preload_content_with_http_info(workspace_id = unicourt.WORKSPACE_ID, case_id = case_id, last_fetch_date_with_updates = last_fetch_date_with_updates, page_number = page_number, history_class = history_class, _request_timeout = _request_timeout, _request_auth = _request_auth, _content_type = _content_type, _headers = _headers, _host_index = _host_index)
            return (response.data, response.status_code)
